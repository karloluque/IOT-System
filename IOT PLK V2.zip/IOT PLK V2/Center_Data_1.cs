﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using PLK_IIOT_V2.Controllers;
using ScottPlot;
using PLK_IIOT_V2.Models;
using System.Linq;
using Color = System.Windows.Media.Color;
using LiveCharts;
using System.Windows.Media;
using LiveCharts.Wpf;
using System.Windows;

using System.Drawing.Imaging;

namespace PLK_IIOT_V2
{
    public partial class Center_Data_1 : Form
    {
        String Hour = DateTime.Now.ToString("HH");
        string Minutes = DateTime.Now.ToString("mm");
        string Seconds = DateTime.Now.ToString("ss");
        String DateHHMM = DateTime.Now.ToString("H:mm");
        String DateDDMMYY = DateTime.Now.ToString("MM/dd/yy");

        public IOT_Tags_1 PLC = new IOT_Tags_1();
        int t;
        public int changesmachine=0;
        int secondcond1, secondcond2;
       
        int[] temptodayshifts = new int[3] { 0,0,0};
        int[] tempydayshifts = new int[3] { 0,0,0};

        string[] emails = new string[5];
        EmailController e_mail = new EmailController();
        NotepadController Notepad = new NotepadController();
        bool reportdone;
        public Center_Data_1()
        {
            InitializeComponent();

            //var d = PLC.Ydays_Shifts.Select(x => (double)x).ToArray();
            //plot1_refresh(d, formsPlot1);

            //var e = PLC.Todays_Shifts.Select(x => (double)x).ToArray();
            //plot2_refresh(e, formsPlot2);

        }
        public void Data_Refresh(IOT_Tags_1 data_in)
        {
            Seconds = DateTime.Now.ToString("ss"); ;
            Hour = DateTime.Now.ToString("HH");
            Minutes = DateTime.Now.ToString("mm");
            DateHHMM = DateTime.Now.ToString("H:mm");
            DateDDMMYY = DateTime.Now.ToString("MM/dd/yy");

            PLC = data_in;

            //var  f=PLC.Todays_Shifts.Where(x => x !=0).Count()==0 ? true:false ;


            //  // status.Where(x => x.StatusCode != 0).Count() == 0 ? true : false;
            var d = PLC.Todays_Shifts.Where(x => temptodayshifts.Contains(x)).Count() != temptodayshifts.Length ? true : false;

            var r= PLC.Todays_Shifts.Where(x => x != 0).Count() != 0 ? true : false;

            if (d == true && r == true)
            {
                var e = PLC.Todays_Shifts.Select(x => (double)x).ToArray();
                plot_refresh(e, formsPlot2);
                temptodayshifts = PLC.Todays_Shifts;
                secondcond1 = 0;
            }
            else
            {
                if (((PLC.Todays_Shifts.Where(x => x != 0).Count() == 0 ? true : false) == false && secondcond1 < 1))
                {
                    var e = PLC.Todays_Shifts.Select(x => (double)x).ToArray();
                    plot_refresh(e, formsPlot2);

                }
                secondcond1 = 1;
            }



            var dd = PLC.Ydays_Shifts.Where(x => tempydayshifts.Contains(x)).Count() != tempydayshifts.Length ? true : false;

            var rr = PLC.Ydays_Shifts.Where(x => x != 0).Count() != 0 ? true : false;

            if (dd == true && rr == true)
            {
                var ee = PLC.Ydays_Shifts.Select(x => (double)x).ToArray();
                plot_refresh2(ee, formsPlot1);
                tempydayshifts = PLC.Ydays_Shifts;
                secondcond2 = 0;
            }
            else
            {
                if (((PLC.Ydays_Shifts.Where(x => x != 0).Count() == 0 ? true : false) == false && secondcond1 < 1))
                {
                    var e = PLC.Ydays_Shifts.Select(x => (double)x).ToArray();
                    plot_refresh2(e, formsPlot1);

                }
                secondcond2 = 1;
            }

            plot5_refresh(PLC.Todays_Total);
            lbl_shift_record.Text = PLC.Linerecord.ToString();
            lbl_ydaytotal.Text = PLC.Ydays_Total.ToString();

        }
        private static bool ComapreLists(string[] arr2, string[] arr3)
        {
            bool _areEqual = false;
            if (arr3.Length == arr2.Length)
            {
                var filteredSequence = arr3.Where(x => arr2.Contains(x));
                if (filteredSequence.Count() == arr3.Length)
                {
                    _areEqual = true;
                }
            }
            return _areEqual;
        }

        public void plot1_refresh(double[] values,FormsPlot formsPlot)
        {

            //formsPlot.Reset();
            //// var plt2 = new ScottPlot.Plot(500, 300);         
            //string[] labels = { "Shift 1", "Shift 2", "Shift 3" };
            //labels = Enumerable.Range(0, values.Length)
            //       .Select(i => $"{labels[i]}\n({values[i]})")
            //       .ToArray();

            //var plot2 = formsPlot.Plot.AddPie(values);
            //plot2.SliceLabels = labels;
            //plot2.ShowLabels = true;
            //plot2.ShowPercentages = true;
            //plot2.Explode = true;
            //formsPlot1.Plot.Style(System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(43)))), ((int)(((byte)(87))))), System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(43)))), ((int)(((byte)(87))))), System.Drawing.Color.White, System.Drawing.Color.White, System.Drawing.Color.White);


            ////formsPlot2.Plot.XLabel(label: "Today's Shifts  ");

            //formsPlot.Plot.Legend(true);

            //formsPlot.Render();

            //formsPlot.Refresh();

        } 
        public void plot_refresh(double[] values, FormsPlot formsPlot)
        {
            formsPlot.Reset();
            // var plt2 = new ScottPlot.Plot(500, 300);         
            string[] labels = { "Shift 1", "Shift 2", "Shift 3" };
            labels = Enumerable.Range(0, values.Length)
                   .Select(i => $"{labels[i]}\n({values[i]})")
                   .ToArray();

           var plot2 = formsPlot.Plot.AddPie(values);
            plot2.SliceLabels = labels;
           plot2.ShowLabels = true;
            plot2.ShowPercentages = true;

           plot2.SliceFont.Size = 18;
            plot2.Explode = true;
            plot2.Explode = true;
          plot2.DonutSize = .5;
            plot2.CenterFont.Color = System.Drawing.Color.White;
            //plot2.DonutLabel = PLC.Todays_Shifts[PLC.Current_Shift].ToString()+ $"\n Shift {PLC.Current_Shift+1}";
            plot2.DonutLabel = PLC.Todays_Total.ToString();
            
            formsPlot.Plot.Style(System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(43)))), ((int)(((byte)(87))))), System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(43)))), ((int)(((byte)(87))))), System.Drawing.Color.White, System.Drawing.Color.White, System.Drawing.Color.White);


            //formsPlot2.Plot.XLabel(label: "Today's Shifts  ");
            //pie.SliceLabels = labels;
           // plt.Legend();
            formsPlot.Plot.Legend(true);

            formsPlot.Render();

            formsPlot.Refresh();

        }
        public void plot_refresh2(double[] values, FormsPlot formsPlot)
        {
            formsPlot.Reset();
            // var plt2 = new ScottPlot.Plot(500, 300);         
            string[] labels = { "Shift 1", "Shift 2", "Shift 3" };
            labels = Enumerable.Range(0, values.Length)
                   .Select(i => $"{labels[i]}\n({values[i]})")
                   .ToArray();

            var plot2 = formsPlot.Plot.AddPie(values);
            plot2.SliceLabels = labels;
            plot2.ShowLabels = true;
            plot2.ShowPercentages = true;
            plot2.Explode = true;
            plot2.Explode = true;
           
            formsPlot.Plot.Style(System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(43)))), ((int)(((byte)(87))))), System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(43)))), ((int)(((byte)(87))))), System.Drawing.Color.White, System.Drawing.Color.White, System.Drawing.Color.White);


            //formsPlot2.Plot.XLabel(label: "Today's Shifts  ");

            formsPlot.Plot.Legend(true);

            formsPlot.Render();

            formsPlot.Refresh();

        }

        private void picbx_logo_Click(object sender, EventArgs e)
        {
            changesmachine = 1;
            //var t = Notepad.Read_Notepad("emails");
            //for (int i = 0; i < emails.Length; i++)
            //{
            //    if (t.Count > 0 || t.Count > i)
            //    {
            //        emails[i] = t[i];
            //    }
            //    else
            //    {
            //        emails[i] = "";
            //    }
            //}


            //e_mail.Emailsender(emails[0], emails[1], emails[2], emails[3], emails[4], e_mail.PLC1_Settings.Machine_Name + $" Production Report ", null, null);

        }

        public void plot5_refresh(double value)
        {


            solidGauge1.Value = value;
            solidGauge1.From = 0;
            solidGauge1.To = 2000;
            solidGauge1.Base.Foreground = new SolidColorBrush(Color.FromRgb(255, 255, 255));
            solidGauge1.HighFontSize = 50;
            solidGauge1.FontSize = 25;
            //solidGauge1.FontStyle();
            solidGauge1.Tag = "Today Total";

            solidGauge1.FromColor = Colors.Yellow;
            solidGauge1.ToColor = Colors.Green;




        }

        
        
     
    }
    
}
