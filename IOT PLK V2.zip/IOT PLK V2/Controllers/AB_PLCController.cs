﻿using System;
using System.Collections.Generic;
using System.Text;
using PLK_IIOT_V2.Models;
using Corsinvest.AllenBradley.PLC.Api;
using System.Threading.Tasks;
using System.Threading;
using System.Linq;
using System.Windows.Forms;
using System.Net.NetworkInformation;

namespace PLK_IIOT_V2.Controllers
{
    class AB_PLCController
    {
        EmailController Emailsend = new EmailController();
        public bool connected;
        Controller cpu;
        TagGroup g1;
        public string tag = null;
        public string tag2 = null;
        string ip_address;
        bool enabled;
        //public Tag<Model_PLC_1>[] Nest = new Tag<Model_PLC_1>[2];

        public IOT_Tags_1 Datareaded_out = new IOT_Tags_1();
        public IOT_Tags_1 Datareaded_out_temp = new IOT_Tags_1();

        public int attempt2connect = 0, attempting = 0, attempting_not_read = 0, attemptemail1 = 0, attemptemail2 = 0;
        public bool plc_disable, pinging_ip1, pinging_ip2, reset_done = false;
        string path;
        bool testingmode = false;
        int plc_no = new int();
        public int j;
        //Nest 0 = Flex Line
        //Nest 1 = Main Line
        public PLC_settings PLC1_Settings = new PLC_settings();
        public PLC_settings PLC2_Settings = new PLC_settings();
        NotepadController Notepad = new NotepadController();
        string ip_address2;

        int currentPLC = new int();

        bool plc1enabled = new bool();
        bool plc2enabled = new bool();
        public AB_PLCController(string enabled, string ip, string path, string tag_in, string tag_in2, int plc_no)
        {

           

            if (enabled == "1")
            {
                this.path = path;
                this.enabled = true;
                this.plc_no = plc_no;
                //cpu = new Controller(ip, path, CPUType.LGX);
                //g1 = cpu.CreateGroup();
                tag = tag_in;
                tag2 = tag_in2;
                ip_address = ip;

              

                if (true)
                {
                    Task.Run(Thread1);

                }

            }
           





        }
    
       

         
void Thread1()
        {
            while (true)
            {

                var ping = pinging(ip_address);
                pinging_ip1 = ping;
             
                if (ping == true)
                {
               //RESTORE COMUNICATION
                    if ((attempting_not_read > 1 || attempting > 1) && ping == true)
                    {

                        Emailsend.SimpleEmailSender($"{PLC1_Settings.Machine_Name} IOT: Comunication Restablished and restarted {ip_address}", $"\n After Attemp Read No: { attempting_not_read} \n\n After Attemp Ping No: { attempting} \n");

                        attempting_not_read = 0;
                        attempting = 0;
                        


                    }

                    var PLC = PLCReading(Datareaded_out, ip_address, path, tag);
                    Datareaded_out = PLC;
                    var g = 0;
                    Datareaded_out_temp = Datareaded_out;
                }
                else
                {
                    
                    attempting++;
                    attemptemail2++;

                    if (attemptemail2 > 600000 || attempting == 1)
                    {
                        attemptemail2 = 0;
                        Emailsend.SimpleEmailSender($"{PLC1_Settings.Machine_Name} IOT: No Pinging, No Connection PLC {ip_address}", $"\n Attemp No: {attempting} \n Check Ethernet Connection or PLC\n");
                        Datareaded_out_temp = Datareaded_out;
                    }
                    Datareaded_out = Datareaded_out_temp;
                    Thread.Sleep(1000);
                }

               
                
            }
            



        }
        public IOT_Tags_1 PLCReading(IOT_Tags_1 value, string ipaddress, string path, string tagplc)
        {
            IOT_Tags_1 PLC_return = new IOT_Tags_1();

            using (var controller = new Controller(ipaddress, path, CPUType.LGX))
            {

              
                //ping controller
                controller.Timeout = 5000;
                // Console.Out.WriteLine("Ping " + controller.Ping(true));
                bool ping = controller.Ping();


                try
                {
                    //create group tag
                    var grp = controller.CreateGroup();
                    //add tag from Class
                    var tag1 = grp.CreateTagType<IOT_Tags_1>(tagplc);
                    var status = grp.Read();
                    PLC_return = tag1.Value;

                    connected = status.Where(x => x.StatusCode != 0).Count() == 0 ? true : false;

                }
                catch (Exception e)
                {
                    PLC_return = value;
                    attempting_not_read++;
                    attemptemail1++;
                    if (attemptemail1 > 6000000 || attempting_not_read == 1)
                    {
                        attemptemail1 = 0;
                        Emailsend.SimpleEmailSender($" {PLC1_Settings.Machine_Name} IOT: Not Reading, No Data Readed{ip_address}", $"\n Attemp No: {attempting_not_read} \n Exception: {e.Message}");
                    }

                    connected = false;
                    plc_disable = true;

                    Thread.Sleep(1000);


                }

                return PLC_return;
            }
        }

        public bool pinging(string ip)
        {
            bool plc_connected = false;
            try
            {
                Ping myPing = new Ping();
                PingReply reply = myPing.Send(ip, 1000);
                if (reply.Status == IPStatus.Success)
                {
                    Console.WriteLine("Status :  " + reply.Status + " \n Time : " + reply.RoundtripTime.ToString() + " \n Address : " + reply.Address);
                    //Console.WriteLine(reply.ToString());
                    //string message = "Status :  " + reply.Status + " \n Time : " + reply.RoundtripTime.ToString() + " \n Address : " + reply.Address;
                    //string title = $"Message: PLC {ip} Connected";
                    //MessageBox.Show(message, title);
                    plc_connected = true;


                }
                else
                {


                    string message = "No Pinging, PLC has been disconnected";
                    string title = $"Error: PLC Address {ip} Not Connected";
                    //MessageBoxButtons buttons = MessageBoxButtons.OK;
                    //MessageBox.Show(message, title, buttons, MessageBoxIcon.Warning);
                    plc_connected = false;

                }
            }
            catch (Exception e)
            {

                Console.WriteLine("Exception: " + e.Message);
                string message = e.Message;
                string title = $"Error: PLC Address {ip} has been disconnected";
                //MessageBoxButtons buttons = MessageBoxButtons.OK;
                //MessageBox.Show(message, title, buttons, MessageBoxIcon.Warning);
                plc_connected = false;


               

            }
            return plc_connected;

        }

    }



}


  