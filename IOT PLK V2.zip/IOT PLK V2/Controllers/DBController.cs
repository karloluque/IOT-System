﻿using Microsoft.Data.SqlClient;
using PLK_IIOT_V2.Controllers;
using PLK_IIOT_V2.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Net;
using System.Net.NetworkInformation;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLK_IIOT_V2.Controllers
{
    class DBController
    {
        int errcount1=0,errcount2=0;
        public IOT_Tags_1 PLC = new IOT_Tags_1();
        IOT_Tags_1 PLC_lastdata = new IOT_Tags_1();
        NotepadController Notepad = new NotepadController();
        public PLC_settings PLC1_Settings = new PLC_settings();
        public PLC_settings PLC2_Settings = new PLC_settings();
        EmailController Emailsend = new EmailController();
        List<IOT_Tags_1> IOTtags = new List<IOT_Tags_1>();

        int error = 0;
        string resu;
        int err_ite1=0;
        int err_ite2=0;
        int err_ite3=0;
        public bool forcewebserver;
        DateTime datetimeplc;
        SqlConnection con;
        SqlDataAdapter da;
        DataSet dt;
        string HostName = Dns.GetHostName();
        string Domain = Environment.UserDomainName;
        public DBController()
        {
            

            //var temp2 = Notepad.Read_Notepad("PLC2_Settings");
            //PLC2_Settings.PLC_enabled = temp2[0];
            //PLC2_Settings.Machine_Name = temp2[1];
            //PLC2_Settings.Ip_Address = temp2[2];
          //Task.Run(Thread1);
        }
        void Thread1()
        {


            while (true)
            {
                
            }

        }
         
        public string Connection()
        {
            string connectionString = null;
         
           
            if ( forcewebserver)
            {
                connectionString = $"Data Source =sql.bsite.net\\MSSQL2016; User Id=controlsplastikon_;Password=Plastikon2022!; Initial Catalog=controlsplastikon_";

            }
            else
            {
              connectionString = $"Data Source ={PLC1_Settings.Servername}\\SQLEXPRESS; User Id=iot;Password=Plastikon2022!; Initial Catalog=Machine";

            }
           






            return connectionString;
        }
       
       

        public bool update_IOTTags1(DB_IOT_Tags_Model_1 inproduction)
        {

            bool rpta = false;
          
              var  cn = Connection();
            
            if (TestConnectiontoServer(cn) == true)
            {
                try
                {

                    using (var connection = new SqlConnection(cn))
                    {
                        connection.Open();
                        SqlCommand cmd = new SqlCommand("sp_IOTTags1_Update", connection);
                        cmd.Parameters.AddWithValue("ID", inproduction.ID);
                        cmd.Parameters.AddWithValue("Machine", inproduction.Machine);
                        cmd.Parameters.AddWithValue("PartNumber", inproduction.PartNumber);
                        cmd.Parameters.AddWithValue("PartStatus", inproduction.PartStatus);
                        cmd.Parameters.AddWithValue("Datetime", inproduction.DateTime);
                        cmd.Parameters.AddWithValue("PLCDateTime", inproduction.PLCDateTime);
                        cmd.Parameters.AddWithValue("PLCHour", inproduction.PLCHour);
                        cmd.Parameters.AddWithValue("PLCMin", inproduction.PLCMin);
                        cmd.Parameters.AddWithValue("PLCSec", inproduction.PLCSec);
                        cmd.Parameters.AddWithValue("TotalCount", inproduction.TotalCount);
                        cmd.Parameters.AddWithValue("TotalGood", inproduction.TotalGood);
                        cmd.Parameters.AddWithValue("TotalBad", inproduction.TotalBad);
                        cmd.Parameters.AddWithValue("Runtime", inproduction.RunTime);
                        cmd.Parameters.AddWithValue("PlannedTime", inproduction.PlannedTime);
                        cmd.Parameters.AddWithValue("StopTime", inproduction.StopTime);
                        cmd.Parameters.AddWithValue("BreakdownCount", inproduction.BreakdownCount);
                        cmd.Parameters.AddWithValue("OEE", inproduction.OEE);
                        cmd.Parameters.AddWithValue("MTBF", inproduction.MTBF);
                        cmd.Parameters.AddWithValue("MTTR", inproduction.MTTR);
                        cmd.Parameters.AddWithValue("CurrentCT", inproduction.CurrentCT);
                        cmd.Parameters.AddWithValue("LastCT", inproduction.LastCT);
                        cmd.Parameters.AddWithValue("AvgCT", inproduction.AvgCT);
                        cmd.Parameters.AddWithValue("Heartbeat", inproduction.Heartbeat);
                        cmd.Parameters.AddWithValue("SequenceStep", inproduction.SequenceStep);
                        cmd.Parameters.AddWithValue("SequenceMsg", inproduction.SequenceMsg);
                        cmd.Parameters.AddWithValue("AlarmNum", inproduction.AlarmNum);
                        cmd.Parameters.AddWithValue("AlarmMsg", inproduction.AlarmMsg);
                        cmd.Parameters.AddWithValue("Remotereset", inproduction.Remotereset);
                        cmd.Parameters.AddWithValue("TodayCount", inproduction.TodayCount);
                        cmd.Parameters.AddWithValue($"HourlyCount1", inproduction.HourlyCount[1]);
                        cmd.Parameters.AddWithValue($"HourlyCount2", inproduction.HourlyCount[2]);
                        cmd.Parameters.AddWithValue($"HourlyCount3", inproduction.HourlyCount[3]);
                        cmd.Parameters.AddWithValue($"HourlyCount4", inproduction.HourlyCount[4]);
                        cmd.Parameters.AddWithValue($"HourlyCount5", inproduction.HourlyCount[5]);
                        cmd.Parameters.AddWithValue($"HourlyCount6", inproduction.HourlyCount[6]);
                        cmd.Parameters.AddWithValue($"HourlyCount7", inproduction.HourlyCount[7]);
                        cmd.Parameters.AddWithValue($"HourlyCount8", inproduction.HourlyCount[8]);
                        cmd.Parameters.AddWithValue($"HourlyCount9", inproduction.HourlyCount[9]);
                        cmd.Parameters.AddWithValue($"HourlyCount10", inproduction.HourlyCount[10]);
                        cmd.Parameters.AddWithValue($"HourlyCount11", inproduction.HourlyCount[11]);
                        cmd.Parameters.AddWithValue($"HourlyCount12", inproduction.HourlyCount[12]);
                        cmd.Parameters.AddWithValue($"HourlyCount13", inproduction.HourlyCount[13]);
                        cmd.Parameters.AddWithValue($"HourlyCount14", inproduction.HourlyCount[14]);
                        cmd.Parameters.AddWithValue($"HourlyCount15", inproduction.HourlyCount[15]);
                        cmd.Parameters.AddWithValue($"HourlyCount16", inproduction.HourlyCount[16]);
                        cmd.Parameters.AddWithValue($"HourlyCount17", inproduction.HourlyCount[17]);
                        cmd.Parameters.AddWithValue($"HourlyCount18", inproduction.HourlyCount[18]);
                        cmd.Parameters.AddWithValue($"HourlyCount19", inproduction.HourlyCount[19]);
                        cmd.Parameters.AddWithValue($"HourlyCount20", inproduction.HourlyCount[20]);
                        cmd.Parameters.AddWithValue($"HourlyCount21", inproduction.HourlyCount[21]);
                        cmd.Parameters.AddWithValue($"HourlyCount22", inproduction.HourlyCount[22]);
                        cmd.Parameters.AddWithValue($"HourlyCount23", inproduction.HourlyCount[23]);
                        cmd.Parameters.AddWithValue($"HourlyCount24", inproduction.HourlyCount[0]);
                        cmd.Parameters.AddWithValue("ShiftCount1", inproduction.ShiftCount[0]);
                        cmd.Parameters.AddWithValue("ShiftCount2", inproduction.ShiftCount[1]);
                        cmd.Parameters.AddWithValue("ShiftCount3", inproduction.ShiftCount[2]);
                        cmd.Parameters.AddWithValue($"YdayCount", inproduction.YdayCount);
                        cmd.Parameters.AddWithValue("YdayShiftCount1", inproduction.YdayShiftCount[0]);
                        cmd.Parameters.AddWithValue("YdayShiftCount2", inproduction.YdayShiftCount[1]);
                        cmd.Parameters.AddWithValue("YdayShiftCount3", inproduction.YdayShiftCount[2]);
                        cmd.Parameters.AddWithValue("OEEShift1", inproduction.OEEShift[0]);
                        cmd.Parameters.AddWithValue("OEEShift2", inproduction.OEEShift[1]);
                        cmd.Parameters.AddWithValue("OEEShift3", inproduction.OEEShift[2]);
                        cmd.Parameters.AddWithValue($"ShiftRecord", inproduction.ShiftRecord);


                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.ExecuteNonQuery();


                    }
                    rpta = true;
                }
                catch (Exception e)
                {
                   
                    string error = e.Message;

                    errcount1++;
                    if (errcount1>5)
                    {
                        Emailsend.SimpleEmailSender($"{PLC1_Settings.Machine_Name} IOT: ERROR UPDATE QUERY", $"\n {e.Message}");
                        errcount1 = 0;
                    }
                        
                    rpta = false;
                }
            }
            else
            {
                rpta = false;
                errcount2++;
                if (errcount2 >= 5)
                {
                    Emailsend.SimpleEmailSender($"{PLC1_Settings.Machine_Name} IOT: Server Connection Error ", $"\n Not Connecttion to server {PLC1_Settings.Servername}\nQuery:update_IOTTags1 ID: {PLC1_Settings.Machine_ID}");
                    errcount2 = 0;
                }
                
            }

          

            return rpta;
        }

        public bool update_IOTTags1_WebServer(DB_IOT_Tags_Model_1 inproduction)
        {

            bool rpta = false;

            var cn = $"Data Source =sql.bsite.net\\MSSQL2016; User Id=controlsplastikon_;Password=Plastikon2022!; Initial Catalog=controlsplastikon_";


            if (TestConnectiontoServer(cn) == true)
            {

                
                try
                {

                    using (var connection = new SqlConnection(cn))
                    {
                        connection.Open();
                        SqlCommand cmd = new SqlCommand("sp_IOTTags1_Update", connection);
                        cmd.Parameters.AddWithValue("ID", inproduction.ID);
                        cmd.Parameters.AddWithValue("Machine", inproduction.Machine);
                        cmd.Parameters.AddWithValue("PartNumber", inproduction.PartNumber);
                        cmd.Parameters.AddWithValue("PartStatus", inproduction.PartStatus);
                        cmd.Parameters.AddWithValue("Datetime", inproduction.DateTime);
                        cmd.Parameters.AddWithValue("PLCDateTime", inproduction.PLCDateTime);
                        cmd.Parameters.AddWithValue("PLCHour", inproduction.PLCHour);
                        cmd.Parameters.AddWithValue("PLCMin", inproduction.PLCMin);
                        cmd.Parameters.AddWithValue("PLCSec", inproduction.PLCSec);
                        cmd.Parameters.AddWithValue("TotalCount", inproduction.TotalCount);
                        cmd.Parameters.AddWithValue("TotalGood", inproduction.TotalGood);
                        cmd.Parameters.AddWithValue("TotalBad", inproduction.TotalBad);
                        cmd.Parameters.AddWithValue("Runtime", inproduction.RunTime);
                        cmd.Parameters.AddWithValue("PlannedTime", inproduction.PlannedTime);
                        cmd.Parameters.AddWithValue("StopTime", inproduction.StopTime);
                        cmd.Parameters.AddWithValue("BreakdownCount", inproduction.BreakdownCount);
                        cmd.Parameters.AddWithValue("OEE", inproduction.OEE);
                        cmd.Parameters.AddWithValue("MTBF", inproduction.MTBF);
                        cmd.Parameters.AddWithValue("MTTR", inproduction.MTTR);
                        cmd.Parameters.AddWithValue("CurrentCT", inproduction.CurrentCT);
                        cmd.Parameters.AddWithValue("LastCT", inproduction.LastCT);
                        cmd.Parameters.AddWithValue("AvgCT", inproduction.AvgCT);
                        cmd.Parameters.AddWithValue("Heartbeat", inproduction.Heartbeat);
                        cmd.Parameters.AddWithValue("SequenceStep", inproduction.SequenceStep);
                        cmd.Parameters.AddWithValue("SequenceMsg", inproduction.SequenceMsg);
                        cmd.Parameters.AddWithValue("AlarmNum", inproduction.AlarmNum);
                        cmd.Parameters.AddWithValue("AlarmMsg", inproduction.AlarmMsg);
                        cmd.Parameters.AddWithValue("Remotereset", inproduction.Remotereset);
                        cmd.Parameters.AddWithValue("TodayCount", inproduction.TodayCount);
                        cmd.Parameters.AddWithValue($"HourlyCount1", inproduction.HourlyCount[1]);
                        cmd.Parameters.AddWithValue($"HourlyCount2", inproduction.HourlyCount[2]);
                        cmd.Parameters.AddWithValue($"HourlyCount3", inproduction.HourlyCount[3]);
                        cmd.Parameters.AddWithValue($"HourlyCount4", inproduction.HourlyCount[4]);
                        cmd.Parameters.AddWithValue($"HourlyCount5", inproduction.HourlyCount[5]);
                        cmd.Parameters.AddWithValue($"HourlyCount6", inproduction.HourlyCount[6]);
                        cmd.Parameters.AddWithValue($"HourlyCount7", inproduction.HourlyCount[7]);
                        cmd.Parameters.AddWithValue($"HourlyCount8", inproduction.HourlyCount[8]);
                        cmd.Parameters.AddWithValue($"HourlyCount9", inproduction.HourlyCount[9]);
                        cmd.Parameters.AddWithValue($"HourlyCount10", inproduction.HourlyCount[10]);
                        cmd.Parameters.AddWithValue($"HourlyCount11", inproduction.HourlyCount[11]);
                        cmd.Parameters.AddWithValue($"HourlyCount12", inproduction.HourlyCount[12]);
                        cmd.Parameters.AddWithValue($"HourlyCount13", inproduction.HourlyCount[13]);
                        cmd.Parameters.AddWithValue($"HourlyCount14", inproduction.HourlyCount[14]);
                        cmd.Parameters.AddWithValue($"HourlyCount15", inproduction.HourlyCount[15]);
                        cmd.Parameters.AddWithValue($"HourlyCount16", inproduction.HourlyCount[16]);
                        cmd.Parameters.AddWithValue($"HourlyCount17", inproduction.HourlyCount[17]);
                        cmd.Parameters.AddWithValue($"HourlyCount18", inproduction.HourlyCount[18]);
                        cmd.Parameters.AddWithValue($"HourlyCount19", inproduction.HourlyCount[19]);
                        cmd.Parameters.AddWithValue($"HourlyCount20", inproduction.HourlyCount[20]);
                        cmd.Parameters.AddWithValue($"HourlyCount21", inproduction.HourlyCount[21]);
                        cmd.Parameters.AddWithValue($"HourlyCount22", inproduction.HourlyCount[22]);
                        cmd.Parameters.AddWithValue($"HourlyCount23", inproduction.HourlyCount[23]);
                        cmd.Parameters.AddWithValue($"HourlyCount24", inproduction.HourlyCount[0]);
                        cmd.Parameters.AddWithValue("ShiftCount1", inproduction.ShiftCount[0]);
                        cmd.Parameters.AddWithValue("ShiftCount2", inproduction.ShiftCount[1]);
                        cmd.Parameters.AddWithValue("ShiftCount3", inproduction.ShiftCount[2]);
                        cmd.Parameters.AddWithValue($"YdayCount", inproduction.YdayCount);
                        cmd.Parameters.AddWithValue("YdayShiftCount1", inproduction.YdayShiftCount[0]);
                        cmd.Parameters.AddWithValue("YdayShiftCount2", inproduction.YdayShiftCount[1]);
                        cmd.Parameters.AddWithValue("YdayShiftCount3", inproduction.YdayShiftCount[2]);
                        cmd.Parameters.AddWithValue("OEEShift1", inproduction.OEEShift[0]);
                        cmd.Parameters.AddWithValue("OEEShift2", inproduction.OEEShift[1]);
                        cmd.Parameters.AddWithValue("OEEShift3", inproduction.OEEShift[2]);
                        cmd.Parameters.AddWithValue($"ShiftRecord", inproduction.ShiftRecord);


                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.ExecuteNonQuery();


                    }
                    rpta = true;
                }
                catch (Exception e)
                {
                    string error = e.Message;
                    Emailsend.SimpleEmailSender($"{PLC1_Settings.Machine_Name} IOT: ERROR UPDATE QUERY", $"\n {e.Message}  WEB");
                    rpta = false;
                }
            }
            else
            {
                rpta = false;
                Emailsend.SimpleEmailSender($"{PLC1_Settings.Machine_Name} IOT: Server Connection Error ", $"\n Not Connecttion to server {PLC1_Settings.Servername}\nQuery:update_IOTTags1 ID: {PLC1_Settings.Machine_ID}   WEB");
            }



            return rpta;
        }


        public IOT_Tags_1 select_IOTTags1(int ID)
        {
            IOT_Tags_1 IOTtags_return= new IOT_Tags_1();
            bool rpta = false;

            var cn = Connection();

            if (TestConnectiontoServer(cn) == true)
            {
                try
                {
                    using (var connection = new SqlConnection(cn))
                    {
                        connection.Open();
                        SqlCommand cmd = new SqlCommand("sp_IOTTags1_select", connection);
                        cmd.Parameters.AddWithValue("ID", ID);
                        cmd.CommandType = CommandType.StoredProcedure;


                        using (var dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                var IOTtags = new IOT_Tags_1
                                {
                                    Machine_Name = dr["Machine"].ToString(),
                                    Ip_Address = PLC1_Settings.Ip_Address,
                                    Sequence_Step_Num = Convert.ToInt32(dr["SequenceStep"]),
                                    Sequence_Step_msg = dr["SequenceMsg"].ToString(),
                                    Alarm_Code = Convert.ToInt32(dr["AlarmNum"]),
                                    Alarm_msg = dr["AlarmMsg"].ToString(),
                                    Hourly_Counter = new int[24]
                                    {
                                    Convert.ToInt32(dr["HourlyCount24"]),
                                    Convert.ToInt32(dr["HourlyCount1"]),
                                    Convert.ToInt32(dr["HourlyCount2"]),
                                    Convert.ToInt32(dr["HourlyCount3"]),
                                    Convert.ToInt32(dr["HourlyCount4"]),
                                    Convert.ToInt32(dr["HourlyCount5"]),
                                    Convert.ToInt32(dr["HourlyCount6"]),
                                    Convert.ToInt32(dr["HourlyCount7"]),
                                    Convert.ToInt32(dr["HourlyCount8"]),
                                    Convert.ToInt32(dr["HourlyCount9"]),
                                    Convert.ToInt32(dr["HourlyCount10"]),
                                    Convert.ToInt32(dr["HourlyCount11"]),
                                    Convert.ToInt32(dr["HourlyCount12"]),
                                    Convert.ToInt32(dr["HourlyCount13"]),
                                    Convert.ToInt32(dr["HourlyCount14"]),
                                    Convert.ToInt32(dr["HourlyCount15"]),
                                    Convert.ToInt32(dr["HourlyCount16"]),
                                    Convert.ToInt32(dr["HourlyCount17"]),
                                    Convert.ToInt32(dr["HourlyCount18"]),
                                    Convert.ToInt32(dr["HourlyCount19"]),
                                    Convert.ToInt32(dr["HourlyCount20"]),
                                    Convert.ToInt32(dr["HourlyCount21"]),
                                    Convert.ToInt32(dr["HourlyCount22"]),
                                    Convert.ToInt32(dr["HourlyCount23"]),

                                    },
                                    Todays_Shifts = new int[3]
                                    {
                                    Convert.ToInt32(dr["ShiftCount1"]),
                                    Convert.ToInt32(dr["ShiftCount2"]),
                                    Convert.ToInt32(dr["ShiftCount3"]),
                                    },
                                    Todays_Total = Convert.ToInt32(dr["TodayCount"]),
                                    Current_Takt_time_msec = (int)(Convert.ToDecimal(dr["CurrentCT"]) * 1),
                                    Last_Takt_Time_msec = (int)(Convert.ToDecimal(dr["LastCT"]) * 1),
                                    Avg_Takt_Time_msec = (int)(Convert.ToDecimal(dr["AvgCT"]) * 1),
                                    OEE_Day = (float)Convert.ToDecimal(dr["OEE"]),
                                    Heartbeat = Convert.ToInt32(dr["Heartbeat"]),
                                    Remotereset = Convert.ToInt32(dr["Remotereset"]),
                                    Ydays_Total = Convert.ToInt32(dr["YdayCount"]),
                                    Ydays_Shifts = new int[3]
                                {
                                    Convert.ToInt32(dr["YdayShiftCount1"]),
                                    Convert.ToInt32(dr["YdayShiftCount2"]),
                                    Convert.ToInt32(dr["YdayShiftCount3"]),
                                },
                                    PLC_Datetime = new int[8]
                                {
                                    0,
                                    0,
                                    0,
                                    Convert.ToInt32(dr["PLCHour"]),
                                    Convert.ToInt32(dr["PLCMin"]),
                                    Convert.ToInt32(dr["PLCSec"]),
                                    0,
                                    0,


                                },
                                    OEE_Shift = new float[3]
                                {
                                    (float)Convert.ToDecimal(dr["OEEShift1"]),
                                    (float)Convert.ToDecimal(dr["OEEShift2"]),
                                    (float)Convert.ToDecimal(dr["OEEShift3"]),
                                },
                                    Linerecord = Convert.ToInt32(dr["ShiftRecord"])
                                };
                                datetimeplc = Convert.ToDateTime(dr["PLCDateTime"]);


                                IOTtags_return = IOTtags;
                            }




                        }
                        IOTtags_return.PLC_Datetime[0] = datetimeplc.Year;
                        IOTtags_return.PLC_Datetime[1] = datetimeplc.Month;
                        IOTtags_return.PLC_Datetime[2] = datetimeplc.Day;






                    }


                    rpta = true;
                }
                catch (Exception e)
                {
                    string error = e.Message;
                    Emailsend.SimpleEmailSender($"{PLC1_Settings.Machine_Name} IOT: ERROR SELECT QUERY", $"\n {e.Message}");
                    rpta = false;
                }
            }
            else
            {
                rpta = false;
                Emailsend.SimpleEmailSender($"{PLC1_Settings.Machine_Name} IOT: Server Connection Error ", $"\n Not Connecttion to server {PLC1_Settings.Servername}\nQuery:select_IOTTags1 ID: {PLC1_Settings.Machine_ID}");

            }



            return IOTtags_return;
            
        }

        public List<IOT_Tags_1> select_IOTTags1_table()
        {
            List<IOT_Tags_1> IOTtags_return=new List<IOT_Tags_1>();           
            var cn = Connection();
            if (TestConnectiontoServer(cn) == true)
            {
               
                try
                {
                    using (var connection = new SqlConnection(cn))
                    {

                        connection.Open();
                        SqlCommand cmd = new SqlCommand("sp_IOTTags1_select_all", connection);

                        cmd.CommandType = CommandType.StoredProcedure;


                        using (var dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                IOTtags_return.Add(new IOT_Tags_1()
                                {

                                    Machine_Name = dr["Machine"].ToString(),
                                    Ip_Address = dr["Machine"].ToString(),
                                    Sequence_Step_Num = Convert.ToInt32(dr["SequenceStep"]),
                                    Sequence_Step_msg = dr["SequenceMsg"].ToString(),
                                    Alarm_Code = Convert.ToInt32(dr["AlarmNum"]),
                                    Alarm_msg = dr["AlarmMsg"].ToString(),
                                    Hourly_Counter = new int[24]
                                    {
                                    Convert.ToInt32(dr["HourlyCount24"]),
                                    Convert.ToInt32(dr["HourlyCount1"]),
                                    Convert.ToInt32(dr["HourlyCount2"]),
                                    Convert.ToInt32(dr["HourlyCount3"]),
                                    Convert.ToInt32(dr["HourlyCount4"]),
                                    Convert.ToInt32(dr["HourlyCount5"]),
                                    Convert.ToInt32(dr["HourlyCount6"]),
                                    Convert.ToInt32(dr["HourlyCount7"]),
                                    Convert.ToInt32(dr["HourlyCount8"]),
                                    Convert.ToInt32(dr["HourlyCount9"]),
                                    Convert.ToInt32(dr["HourlyCount10"]),
                                    Convert.ToInt32(dr["HourlyCount11"]),
                                    Convert.ToInt32(dr["HourlyCount12"]),
                                    Convert.ToInt32(dr["HourlyCount13"]),
                                    Convert.ToInt32(dr["HourlyCount14"]),
                                    Convert.ToInt32(dr["HourlyCount15"]),
                                    Convert.ToInt32(dr["HourlyCount16"]),
                                    Convert.ToInt32(dr["HourlyCount17"]),
                                    Convert.ToInt32(dr["HourlyCount18"]),
                                    Convert.ToInt32(dr["HourlyCount19"]),
                                    Convert.ToInt32(dr["HourlyCount20"]),
                                    Convert.ToInt32(dr["HourlyCount21"]),
                                    Convert.ToInt32(dr["HourlyCount22"]),
                                    Convert.ToInt32(dr["HourlyCount23"]),

                                    },
                                    Todays_Shifts = new int[3]
                                    {
                                    Convert.ToInt32(dr["ShiftCount1"]),
                                    Convert.ToInt32(dr["ShiftCount2"]),
                                    Convert.ToInt32(dr["ShiftCount3"]),
                                    },
                                    Todays_Total = Convert.ToInt32(dr["TodayCount"]),
                                    Current_Takt_time_msec = (int)(Convert.ToDecimal(dr["CurrentCT"]) * 1),
                                    Last_Takt_Time_msec = (int)(Convert.ToDecimal(dr["LastCT"]) * 1),
                                    Avg_Takt_Time_msec = (int)(Convert.ToDecimal(dr["AvgCT"]) * 1),
                                    OEE_Day = (float)Convert.ToDecimal(dr["OEE"]),
                                    Heartbeat = Convert.ToInt32(dr["Heartbeat"]),
                                    Remotereset = Convert.ToInt32(dr["Remotereset"]),

                                    PLC_Datetime = new int[8]
                                    {
                                  Convert.ToInt32(Convert.ToDateTime(dr["PLCDateTime"]).Year),
                                  Convert.ToInt32(Convert.ToDateTime(dr["PLCDateTime"]).Month),
                                  Convert.ToInt32(Convert.ToDateTime(dr["PLCDateTime"]).Day),
                                  Convert.ToInt32(Convert.ToDateTime(dr["PLCDateTime"]).Hour),
                                  Convert.ToInt32(Convert.ToDateTime(dr["PLCDateTime"]).Minute),
                                  Convert.ToInt32(Convert.ToDateTime(dr["PLCDateTime"]).Second),
                                  0,
                                  0,

                                    },
                                    Ydays_Total = Convert.ToInt32(dr["YdayCount"]),
                                    Ydays_Shifts = new int[3]
                                    {
                                    Convert.ToInt32(dr["YdayShiftCount1"]),
                                    Convert.ToInt32(dr["YdayShiftCount2"]),
                                    Convert.ToInt32(dr["YdayShiftCount3"]),
                                    },
                                    OEE_Shift = new float[3]
                                    {
                                    (float)Convert.ToDecimal(dr["OEEShift1"]),
                                    (float)Convert.ToDecimal(dr["OEEShift2"]),
                                    (float)Convert.ToDecimal(dr["OEEShift3"]),
                                    },
                                    Linerecord = Convert.ToInt32(dr["ShiftRecord"])



                                });




                            }




                        }
                        IOTtags = IOTtags_return;
                       





                    }
                }
                catch (Exception e)
                {

                    string error = e.Message;
                    Emailsend.SimpleEmailSender($"{PLC1_Settings.Machine_Name} IOT: ERROR SELECT * QUERY", $"\n {e.Message}");
                    System.Windows.MessageBox.Show(e.Message);
                }

            }
            else
            {

               
                Emailsend.SimpleEmailSender($"{PLC1_Settings.Machine_Name} IOT: Server Connection Error ", $"\n Not Connecttion to server {PLC1_Settings.Servername}\nQuery:Select *");
               }


            return IOTtags_return;

        }
        public PLC_settings select_Machineinfo_table()
        {
           PLC_settings _plc_settings= new PLC_settings();
            var cn = Connection();
            if (TestConnectiontoServer(cn) == true)
            {
                try
                {
                    using (var connection = new SqlConnection(cn))
                    {

                        connection.Open();
                        SqlCommand cmd = new SqlCommand("sp_MachineInfo_select", connection);

                        cmd.CommandType = CommandType.StoredProcedure;


                        using (var dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                var plcsetup=new PLC_settings()
                                {

                                    Machine_ID = dr["ID"].ToString(),
                                    ID = dr["ID"].ToString(),
                                    Building = dr["Building"].ToString(),
                                    Machine_Name = dr["MachineName"].ToString(),
                                    Ip_Address = dr["IPAddress"].ToString(),
                                    TargetPerHour = Convert.ToInt32(dr["TargetPerHour"]),
                                    IdealCT = (float)Convert.ToDecimal(dr["IdealCT"]),
                                    Shift1StartHr = Convert.ToInt32(dr["Shift1StartHr"]),
                                    Shift1EndHr = Convert.ToInt32(dr["Shift1EndHr"]),
                                    Shift2StartHr = Convert.ToInt32(dr["Shift2StartHr"]),
                                    Shift2EndHr = Convert.ToInt32(dr["Shift2EndHr"]),
                                    Shift3StartHr = Convert.ToInt32(dr["Shift3StartHr"]),
                                    Shift3EndHr = Convert.ToInt32(dr["Shift3EndHr"]),



                                };



                                _plc_settings = plcsetup;
                            }


                            

                        }






                    }
                }
                catch (Exception e)
                {

                    string error = e.Message;
                    Emailsend.SimpleEmailSender($"{PLC1_Settings.Machine_Name} IOT: ERROR SELECT MachineInfo * QUERY", $"\n {e.Message}");
                    //System.Windows.MessageBox.Show(e.Message);
                }

            }
            else
            {


                Emailsend.SimpleEmailSender($"{PLC1_Settings.Machine_Name} IOT: Server Connection Error ", $"\n Not Connecttion to server {PLC1_Settings.Servername}\nQuery:Select * MachineInfo");
            }


            return _plc_settings;

        }
        public List<PLC_settings> select_Machineinfo_table_all()
        {
            List<PLC_settings> _plc_settings = new List<PLC_settings>();
            var cn = Connection();
            if (TestConnectiontoServer(cn) == true)
            {
                try
                {
                    using (var connection = new SqlConnection(cn))
                    {

                        connection.Open();
                        SqlCommand cmd = new SqlCommand("sp_MachineInfo_select_all", connection);

                        cmd.CommandType = CommandType.StoredProcedure;


                        using (var dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                _plc_settings.Add(new PLC_settings()
                                {

                                    Machine_ID = dr["ID"].ToString(),
                                    Building = dr["Building"].ToString(),
                                    Machine_Name = dr["MachineName"].ToString(),
                                    Ip_Address= dr["IPAddress"].ToString(),
                                    TargetPerHour = Convert.ToInt32(dr["TargetPerHour"]),
                                    IdealCT = (float)Convert.ToDecimal(dr["IdealCT"]),
                                    Shift1StartHr = Convert.ToInt32(dr["Shift1StartHr"]),
                                    Shift1EndHr = Convert.ToInt32(dr["Shift1EndHr"]),
                                    Shift2StartHr = Convert.ToInt32(dr["Shift2StartHr"]),
                                    Shift2EndHr = Convert.ToInt32(dr["Shift2EndHr"]),
                                    Shift3StartHr = Convert.ToInt32(dr["Shift3StartHr"]),
                                    Shift3EndHr = Convert.ToInt32(dr["Shift3EndHr"]),



                                });




                            }




                        }






                    }
                }
                catch (Exception e)
                {

                    string error = e.Message;
                    Emailsend.SimpleEmailSender($"{PLC1_Settings.Machine_Name} IOT: ERROR SELECT MachineInfo * QUERY", $"\n {e.Message}");
                    //System.Windows.MessageBox.Show(e.Message);
                }

            }
            else
            {


                Emailsend.SimpleEmailSender($"{PLC1_Settings.Machine_Name} IOT: Server Connection Error ", $"\n Not Connecttion to server {PLC1_Settings.Servername}\nQuery:Select * MachineInfo");
            }


            return _plc_settings;

        }
     

        private bool pinging(string ip)
        {
            bool plc_connected = false;
            try
            {
                Ping myPing = new Ping();
                PingReply reply = myPing.Send(ip, 1000);
                if (reply.Status == IPStatus.Success)
                {
                    Console.WriteLine("Status :  " + reply.Status + " \n Time : " + reply.RoundtripTime.ToString() + " \n Address : " + reply.Address);
                    //Console.WriteLine(reply.ToString());
                    //string message = "Status :  " + reply.Status + " \n Time : " + reply.RoundtripTime.ToString() + " \n Address : " + reply.Address;
                    //string title = $"Message: PLC {ip} Connected";
                    //MessageBox.Show(message, title);
                    plc_connected = true;


                }
                else
                {


                    string message = "No Pinging, PLC has been disconnected";
                    string title = $"Error: PLC Address {ip} Not Connected";
                    //MessageBoxButtons buttons = MessageBoxButtons.OK;
                    //MessageBox.Show(message, title, buttons, MessageBoxIcon.Warning);
                    plc_connected = false;

                }
            }
            catch (Exception e)
            {

                Console.WriteLine("Exception: " + e.Message);
                string message = e.Message;
                string title = $"Error: PLC Address {ip} has been disconnected";
                //MessageBoxButtons buttons = MessageBoxButtons.OK;
                //MessageBox.Show(message, title, buttons, MessageBoxIcon.Warning);
                plc_connected = false;




            }
            return plc_connected;

        }

        private bool TestConnectiontoServer(string connectionstring)
        {
            bool sqlconection = false;
            var cn = connectionstring;
           

            using (SqlConnection connection = new SqlConnection(cn))
            {

                
                try
                {

                    connection.Open();
                    sqlconection = true;

                }
                catch (SqlException)
                {
                    sqlconection = false;

                }
            }

            return sqlconection;
        }

       
        public bool CheckWebServerConnection()
        {
            bool returnbool = false;
            var connectionString = $"Data Source =sql.bsite.net\\MSSQL2016; User Id=controlsplastikon_;Password=Plastikon2022!; Initial Catalog=controlsplastikon_";
         
            returnbool = TestConnectiontoServer(connectionString);
            return returnbool;
        }
        public bool CheckLocalServerConnection()
        {
            bool returnbool = false;
            var connectionString = $"Data Source ={PLC1_Settings.Servername}\\SQLEXPRESS; User Id=iot;Password=Plastikon2022!; Initial Catalog=Machine";

            returnbool = TestConnectiontoServer(connectionString);
            return returnbool; 
        }
    }

    


}


//public bool update_Test()
//{
//    bool rpta = false;

//    try
//    {
//        var cn = $"Data Source =LT-CA-00175\\SQLEXPRESS; User Id=iot;Password=Plastikon2022!!; Initial Catalog=Machine;";
//        var d = 0;
//        using (var connection = new SqlConnection(cn))
//        {
//            connection.Open();
//            SqlCommand cmd = new SqlCommand("sp_test_update", connection);
//            cmd.Parameters.AddWithValue("ID", 1);
//            cmd.Parameters.AddWithValue("Prueba", 666);
//            cmd.Parameters.AddWithValue("Machine", "JAlo");


//            cmd.CommandType = CommandType.StoredProcedure;

//            cmd.ExecuteNonQuery();
//            //////SqlConnection con = new SqlConnection(cn);
//            //////con.Open();
//            //////SqlCommand sc = new SqlCommand($"update Test SET ID='1', Prueba='888',Machine='otravezJalo!' WHERE ID = '1' ", con);


//            ////sc.ExecuteNonQuery();
//            ////con.Close();

//        }
//        rpta = true;
//    }
//    catch (Exception e)
//    {
//        string error = e.Message;
//        rpta = false;
//    }
//    return rpta;
//}