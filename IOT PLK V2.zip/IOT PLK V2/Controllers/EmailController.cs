﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Net;
using PLK_IIOT_V2.Controllers;
using PLK_IIOT_V2.Models;
using System.Net.Mail;
using System.Text.RegularExpressions;
using System.Threading;
using System.Linq;
using System.Net.Mime;

namespace PLK_IIOT_V2.Controllers
{


    class EmailController
    {
        string htmlcontent;
        public string CaptureDirectory;
        string CurrentDirectory = Environment.CurrentDirectory;
        string HostName = Dns.GetHostName();
        string IpAddress_Host;
        NotepadController Notepad = new NotepadController();
        public bool disabled_emails = false;
        public PLC_settings PLC1_Settings = new PLC_settings();
        public PLC_settings PLC2_Settings = new PLC_settings();
        public List<IOT_Tags_1> Machines = new List<IOT_Tags_1>();
        
        public EmailController()
        {
            //Emailsender("hugo.palafox@plastikon.com", "juan.aceves@plastikon.com", "testing", "This has been sent from IOT Application");
            //var temp1 = Notepad.Read_Notepad("PLC1_Settings");
            //PLC1_Settings.PLC_enabled = temp1[0];
            //PLC1_Settings.Machine_Name = temp1[1];
            //PLC1_Settings.Machine_ID = temp1[2];
            //PLC1_Settings.Ip_Address = temp1[3];
            //PLC1_Settings.Server_enabled = temp1[4];
            //PLC1_Settings.Servername = temp1[5];
            //PLC1_Settings.Database = temp1[6];
            //PLC1_Settings.Table = temp1[7];

            //var temp2 = Notepad.Read_Notepad("PLC2_Settings");
            //PLC2_Settings.PLC_enabled = temp2[0];
            //PLC2_Settings.Machine_Name = temp2[1];
            //PLC2_Settings.Ip_Address = temp2[2];
        }
        public void SimpleEmailSender(string subject, string body)
        {
            if (disabled_emails == true) goto disabled_emailing;
            IpAddress_Host = ip_host(HostName);
            try
            {
                MailMessage mail = new MailMessage();
                System.Net.Mail.SmtpClient SmtpServer = new System.Net.Mail.SmtpClient("smtp.gmail.com");

                string sender = "plastikoniot@gmail.com";
                mail.From = new MailAddress(sender);
                mail.To.Add("hugo.palafox@plastikon.com");

                mail.Priority = MailPriority.High;
                mail.Subject = subject;

                mail.Body = ($"{body} \n\n Name of computer: { HostName} \n");

                SmtpServer.Port = 587;
                SmtpServer.Credentials = new System.Net.NetworkCredential("plastikoniot@gmail.com", "gbpnotamivbmplam");
                SmtpServer.EnableSsl = true;

                SmtpServer.Send(mail);

            }
            catch (Exception ee)
            {

                //System.Windows.MessageBox.Show(ee.Message);
                Thread.Sleep(10000);
            }
        disabled_emailing:;
        }
        public void Emailsender_fromserver(List<string> emails,string subject)
        {
            
            string html;
            if (disabled_emails == true) goto disabled_emailing;

            IpAddress_Host = ip_host(HostName);



         

            DateTime theDate = DateTime.Now;
            theDate.ToString("yyyy-MM-dd");





            try
            {
                MailMessage mail = new MailMessage();
                System.Net.Mail.SmtpClient SmtpServer = new System.Net.Mail.SmtpClient("smtp.gmail.com");

                foreach (var email in emails)
                {
                    if (ValidateEmail(email))
                    {
                        var copy = new MailAddress(email);
                        mail.CC.Add(copy);
                    }
                   
                }                
               

                string sender = "plastikoniot@gmail.com";
                mail.From = new MailAddress(sender);
                mail.To.Add("hugo.palafox@plastikon.com");

                mail.Subject = subject;
                mail.IsBodyHtml = true;
              
                Machines[0].SpareDINT[0] = 5;
                Machines[1].SpareDINT[0] = 5;
                Machines[2].SpareDINT[0] = 6;
                Machines[3].SpareDINT[0] = 6;
                Machines[4].SpareDINT[0] = 6;
                Machines[5].SpareDINT[0] = 6;
                Machines[6].SpareDINT[0] = 6;
                
                
                string endofemail= @"<p style=font - size:20px>This has been sent by a Plastikon IIOT Application</p>";
              
                string startofemail= @$"<p><b>Computer Date and Time {theDate} </b></p>";
               
                for (int i = 0; i < Machines.Count; i++)
                {
                    Machines[i].SpareDINT[0] = i>=2? 5:6;
                    htmlcontent = htmlcontent + htmlcontent_plc1(Machines[i]);
                }
                mail.Body = startofemail+ htmlcontent+ endofemail;

                SmtpServer.Port = 587;
                SmtpServer.Credentials = new System.Net.NetworkCredential("plastikoniot@gmail.com", "gbpnotamivbmplam");
                SmtpServer.EnableSsl = true;

                SmtpServer.Send(mail);
                Machines.Clear();
               // System.Windows.MessageBox.Show("Email has been sent Successfully!");
            }
            catch (Exception ee)
            {

                //System.Windows.MessageBox.Show(ee.Message);
                SimpleEmailSender("Error on Email report", ee.Message);
                //System.Windows.MessageBox.Show("Error on Email report", ee.Message);
                ///  Thread.Sleep(10000);
            }
        disabled_emailing:;
        }
        public void Emailsender(List<string> emails, string subject, IOT_Tags_1 data, IOT_Tags_1 data2)
        {
            string html;
            //if (disabled_emails == true) goto disabled_emailing;

            IpAddress_Host = ip_host(HostName);
            


            //string line_record;
            //line_record = String.Join(" ", Notepad1.Read_Notepad("0"));

            DateTime theDate = DateTime.Now;
            theDate.ToString("yyyy-MM-dd");





            try
            {
                MailMessage mail = new MailMessage();
                System.Net.Mail.SmtpClient SmtpServer = new System.Net.Mail.SmtpClient("smtp.gmail.com");

                string sender = "plastikoniot@gmail.com";
                mail.From = new MailAddress(sender);
                mail.To.Add("hugo.palafox@plastikon.com");


                foreach (var email in emails)
                {
                    if (ValidateEmail(email))
                    {
                        var copy = new MailAddress(email);
                        mail.CC.Add(copy);
                    }

                }
               
                mail.Subject = subject;



                mail.IsBodyHtml = true;


                // mail.Priority = MailPriority.High;

                html = htmlcontent_plc1(data) + "<img src='cid:imagen' />";
  
                    


                AlternateView htmlView =
                    AlternateView.CreateAlternateViewFromString(html,
                                            Encoding.UTF8,
                                            MediaTypeNames.Text.Html);

                LinkedResource img =
                    new LinkedResource(CaptureDirectory,
                                        MediaTypeNames.Image.Jpeg);
                img.ContentId = "imagen";

                htmlView.LinkedResources.Add(img);

                mail.AlternateViews.Add(htmlView);





               mail.Body = htmlcontent_plc1(data) + "<img src='cid:imagen' />";

                SmtpServer.Port = 587;
                SmtpServer.Credentials = new System.Net.NetworkCredential("plastikoniot@gmail.com", "gbpnotamivbmplam");
                SmtpServer.EnableSsl = true;

                SmtpServer.Send(mail);
                //System.Windows.MessageBox.Show("Email has been sent Successfully!");
            }
            catch (Exception ee)
            {

                //System.Windows.MessageBox.Show(ee.Message);
                SimpleEmailSender("Error on Email report", ee.Message);
                //System.Windows.MessageBox.Show("Error on Email report", ee.Message);
              ///  Thread.Sleep(10000);
            }
       // disabled_emailing:;
        }


        bool ValidateEmail(string email)
        {
            bool bool_return = false;



            if (email == null)
            {
                bool_return = false;
            }
            else
            {
                Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
                Match match = regex.Match(email);
                bool_return = match.Success;
            }



            return bool_return;
        }
        public string ip_host(string HostName)
        {
            string str_return = null;
            IPAddress[] ipaddress = Dns.GetHostAddresses(HostName);
            str_return = Convert.ToString(ipaddress[1]);
            return str_return;
        }
        string htmlcontent_plc1(IOT_Tags_1 data)
        {
           
            string htmlString="";
            if (data.SpareDINT[0] == 6)
            {
                DateTime theDate = DateTime.Now;
                theDate.ToString("yyyy-MM-dd");

                htmlString = $@"<html>
<body>

<FONT COLOR=#0000CD> <p style=font-size:30px>{data.Machine_Name} Production Report </p></FONT>

<table>
<table border=0>

 <! ––this is a comment––> 


<th><b>Hours</b></th>
<th><b>Production Shift 1</b></th>
<th><b>Hours</b></th>
<th><b>Production Shift 2</b></th>
<th><b>Hours</b></th>
<th><b>Production Shift 3</b></th>



 <! ––Data 1––> 



<tr>
<td>6:00-7:00</td>
<td><center>{data.Hourly_Counter[6]}</center></td>

<td>14:00-15:00</td>
<td><center>{data.Hourly_Counter[14]}</center></td>

<td>22:00-23:00</td>
<td><center>{data.Hourly_Counter[22]}</center></td>
</tr>



<tr>
<td>7:00-8:00</td>
<td><center>{data.Hourly_Counter[7]}</center></td>

<td>15:00-16:00</td>
<td><center>{data.Hourly_Counter[15]}</center></td>

<td>23:00-00:00</td>
<td><center>{data.Hourly_Counter[23]}</center></td>
</tr>



<tr>
<td>8:00-9:00</td>
<td><center>{data.Hourly_Counter[8]}</center></td>

<td>16:00-17:00</td>
<td><center>{data.Hourly_Counter[16]}</center></td>

<td>00:00-1:00</td>
<td><center>{data.Hourly_Counter[0]}</center></td>
</tr>



<tr>
<td>9:00-10:00</td>
<td><center>{data.Hourly_Counter[9]}</center></td>

<td>17:00-18:00</td>
<td><center>{data.Hourly_Counter[17]}</center></td>

<td>1:00-2:00</td>
<td><center>{data.Hourly_Counter[1]}</center></td>
</tr>

<tr>
<td>10:00-11:00</td>
<td><center>{data.Hourly_Counter[10]}</center></td>

<td>18:00-19:00</td>
<td><center>{data.Hourly_Counter[18]}</center></td>

<td>2:00-3:00</td>
<td><center>{data.Hourly_Counter[2]}</center></td>
</tr>

<tr>
<td>11:00-12:00</td>
<td><center>{data.Hourly_Counter[11]}</center></td>

<td>19:00-20:00</td>
<td><center>{data.Hourly_Counter[19]}</center></td>

<td>3:00-2:00</td>
<td><center>{data.Hourly_Counter[3]}</center></td>
</tr>

<tr>
<td>12:00-13:00</td>
<td><center>{data.Hourly_Counter[12]}</center></td>
<td>20:00-21:00</td>
<td><center>{data.Hourly_Counter[20]}</center></td>
<td>4:00-5:00</td>
<td><center>{data.Hourly_Counter[4]}</center></td>
</tr>


<tr>




<td>13:00-14:00</td>
<td><center>{data.Hourly_Counter[13]}</center></td>

<td>21:00-22:00</td>
<td><center>{data.Hourly_Counter[21]}</center></td>

<td>5:00-6:00</td>
<td><center>{data.Hourly_Counter[5]}</center></td>

</tr>


<tr>
<td>Total Shift 1</td>
<td><center>{data.Todays_Shifts[0]}</center></td>
<td>Total Shift 2</td>
<td><center>{data.Todays_Shifts[1]}</center></td>
<td>Total Shift 3</td>
<td><center>{data.Todays_Shifts[2]}</center></td>
</tr>

<tr>
<td>Yesterday's Totals Shift 1</td>
<td><center>{data.Ydays_Shifts[0]}</center></td>
<td>Yesterday's Totals Shift 3</td>
<td><center>{data.Ydays_Shifts[1]}</center></td>
<td>Yesterday's Totals Shift 3</td>
<td><center>{data.Ydays_Shifts[2]}</center></td>
</tr>
</table>
<br>  <br/> 

<p></p>
<p></p>
<p><b>Today's Total Production: {data.Todays_Total} </b></p>
<p></p>

<p></p>
<p></p>
<p><b>Line Record: {data.Linerecord} </b></p>
<p></p>



      </body>
</html>
             ";
            }
            else
            {
                DateTime theDate = DateTime.Now;
                theDate.ToString("yyyy-MM-dd");

                htmlString = $@"<html>
<body>

 
<table>
<table border=0>
<FONT COLOR=#0000CD> <p style=font-size:30px>{data.Machine_Name} Production Report </p></FONT>
<table>
<table border=0>
 <! ––this is a comment––> 


<th><b>Hours</b></th>
<th><b>Production Shift 1</b></th>
<th><b>Hours</b></th>
<th><b>Production Shift 2</b></th>
<th><b>Hours</b></th>
<th><b>Production Shift 3</b></th>



 <! ––Data 1––> 


<tr>
<td>5:00-6:00</td>
<td><center>{data.Hourly_Counter[5]}</center></td>

<td>13:00-14:00</td>
<td><center>{data.Hourly_Counter[13]}</center></td>

<td>21:00-22:00</td>
<td><center>{data.Hourly_Counter[21]}</center></td>
</tr>

<tr>
<td>6:00-7:00</td>
<td><center>{data.Hourly_Counter[6]}</center></td>

<td>14:00-15:00</td>
<td><center>{data.Hourly_Counter[14]}</center></td>

<td>22:00-23:00</td>
<td><center>{data.Hourly_Counter[22]}</center></td>
</tr>



<tr>
<td>7:00-8:00</td>
<td><center>{data.Hourly_Counter[7]}</center></td>

<td>15:00-16:00</td>
<td><center>{data.Hourly_Counter[15]}</center></td>

<td>23:00-00:00</td>
<td><center>{data.Hourly_Counter[23]}</center></td>
</tr>



<tr>
<td>8:00-9:00</td>
<td><center>{data.Hourly_Counter[8]}</center></td>

<td>16:00-17:00</td>
<td><center>{data.Hourly_Counter[16]}</center></td>

<td>00:00-1:00</td>
<td><center>{data.Hourly_Counter[0]}</center></td>
</tr>



<tr>
<td>9:00-10:00</td>
<td><center>{data.Hourly_Counter[9]}</center></td>

<td>17:00-18:00</td>
<td><center>{data.Hourly_Counter[17]}</center></td>

<td>1:00-2:00</td>
<td><center>{data.Hourly_Counter[1]}</center></td>
</tr>

<tr>
<td>10:00-11:00</td>
<td><center>{data.Hourly_Counter[10]}</center></td>

<td>18:00-19:00</td>
<td><center>{data.Hourly_Counter[18]}</center></td>

<td>2:00-3:00</td>
<td><center>{data.Hourly_Counter[2]}</center></td>
</tr>

<tr>
<td>11:00-12:00</td>
<td><center>{data.Hourly_Counter[11]}</center></td>

<td>19:00-20:00</td>
<td><center>{data.Hourly_Counter[19]}</center></td>

<td>3:00-2:00</td>
<td><center>{data.Hourly_Counter[3]}</center></td>
</tr>

<tr>
<td>12:00-13:00</td>
<td><center>{data.Hourly_Counter[12]}</center></td>
<td>20:00-21:00</td>
<td><center>{data.Hourly_Counter[20]}</center></td>
<td>4:00-5:00</td>
<td><center>{data.Hourly_Counter[4]}</center></td>
</tr>





<tr>
<td>Total Shift 1</td>
<td><center>{data.Todays_Shifts[0]}</center></td>
<td>Total Shift 2</td>
<td><center>{data.Todays_Shifts[1]}</center></td>
<td>Total Shift 3</td>
<td><center>{data.Todays_Shifts[2]}</center></td>
</tr>

<tr>
<td>Yesterday's Totals Shift 1</td>
<td><center>{data.Ydays_Shifts[0]}</center></td>
<td>Yesterday's Totals Shift 3</td>
<td><center>{data.Ydays_Shifts[1]}</center></td>
<td>Yesterday's Totals Shift 3</td>
<td><center>{data.Ydays_Shifts[2]}</center></td>
</tr>



</table>
<br>  <br/> 

<p></p>
<p></p>
<p><b>Today's Total Production: {data.Todays_Total} </b></p>
<p></p>

<p></p>
<p></p>
<p><b>Line Record: {data.Linerecord} </b></p>
<p></p>



      </body>
</html>
             ";
            }
          
            return htmlString;
        }

        string htmlcontent_2plc(IOT_Tags_1 data, IOT_Tags_1 data2, int LineRecord)
        {



            DateTime theDate = DateTime.Now;
            theDate.ToString("yyyy-MM-dd");

            string htmlString = $@"<html>
<body>
 <p><b>YF Line Production {theDate} </b></p>

<p><b>YF Flex Line Production</b></p>
<table>
<table border=0>

 <! ––this is a comment––> 


<th><b>Hours</b></th>
<th><b>Production Shift 1</b></th>
<th><b>Hours</b></th>
<th><b>Production Shift 2</b></th>
<th><b>Hours</b></th>
<th><b>Production Shift 3</b></th>



 <! ––Data 1––> 
<tr>
<td>5:00-6:00</td>
<td><center>{data.Hourly_Counter[5]}</center></td>

<td>13:00-14:00</td>
<td><center>{data.Hourly_Counter[13]}</center></td>

<td>21:00-22:00</td>
<td><center>{data.Hourly_Counter[21]}</center></td>
</tr>



<tr>
<td>6:00-7:00</td>
<td><center>{data.Hourly_Counter[6]}</center></td>

<td>14:00-15:00</td>
<td><center>{data.Hourly_Counter[14]}</center></td>

<td>22:00-23:00</td>
<td><center>{data.Hourly_Counter[22]}</center></td>
</tr>



<tr>
<td>7:00-8:00</td>
<td><center>{data.Hourly_Counter[7]}</center></td>

<td>15:00-16:00</td>
<td><center>{data.Hourly_Counter[15]}</center></td>

<td>23:00-00:00</td>
<td><center>{data.Hourly_Counter[23]}</center></td>
</tr>



<tr>
<td>8:00-9:00</td>
<td><center>{data.Hourly_Counter[8]}</center></td>

<td>16:00-17:00</td>
<td><center>{data.Hourly_Counter[16]}</center></td>

<td>00:00-1:00</td>
<td><center>{data.Hourly_Counter[0]}</center></td>
</tr>



<tr>
<td>9:00-10:00</td>
<td><center>{data.Hourly_Counter[9]}</center></td>

<td>17:00-18:00</td>
<td><center>{data.Hourly_Counter[17]}</center></td>

<td>1:00-2:00</td>
<td><center>{data.Hourly_Counter[1]}</center></td>
</tr>

<tr>
<td>10:00-11:00</td>
<td><center>{data.Hourly_Counter[10]}</center></td>

<td>18:00-19:00</td>
<td><center>{data.Hourly_Counter[18]}</center></td>

<td>2:00-3:00</td>
<td><center>{data.Hourly_Counter[2]}</center></td>
</tr>

<tr>
<td>11:00-12:00</td>
<td><center>{data.Hourly_Counter[11]}</center></td>

<td>19:00-20:00</td>
<td><center>{data.Hourly_Counter[19]}</center></td>

<td>3:00-2:00</td>
<td><center>{data.Hourly_Counter[3]}</center></td>
</tr>

<tr>
<td>12:00-13:00</td>
<td><center>{data.Hourly_Counter[12]}</center></td>
<td>20:00-21:00</td>
<td><center>{data.Hourly_Counter[20]}</center></td>
<td>4:00-5:00</td>
<td><center>{data.Hourly_Counter[4]}</center></td>
</tr>

<tr>
<td>Total Shift 1</td>
<td><center>{data.Todays_Shifts[0]}</center></td>
<td>Total Shift 2</td>
<td><center>{data.Todays_Shifts[1]}</center></td>
<td>Total Shift 3</td>
<td><center>{data.Todays_Shifts[2]}</center></td>
</tr>

<tr>
<td>Yesterday's Totals Shift 1</td>
<td><center>{data.Ydays_Shifts[0]}</center></td>
<td>Yesterday's Totals Shift 3</td>
<td><center>{data.Ydays_Shifts[1]}</center></td>
<td>Yesterday's Totals Shift 3</td>
<td><center>{data.Ydays_Shifts[2]}</center></td>
</tr>
</table>
<br>  <br/> 

<p><b>YF Main Line Production</b></p>
<br>  <br/> 
<table>
 <! ––Data 2––> 
<th><b>Hours</b></th>
<th><b>Production Shift 1</b></th>
<th><b>Hours</b></th>
<th><b>Production Shift 2</b></th>
<th><b>Hours</b></th>
<th><b>Production Shift 3</b></th>



<tr>
<td>5:00-6:00</td>
<td><center>{data2.Hourly_Counter[5]}</center></td>

<td>13:00-14:00</td>
<td><center>{data2.Hourly_Counter[13]}</center></td>

<td>21:00-22:00</td>
<td><center>{data2.Hourly_Counter[21]}</center></td>
</tr>



<tr>
<td>6:00-7:00</td>
<td><center>{data2.Hourly_Counter[6]}</center></td>

<td>14:00-15:00</td>
<td><center>{data2.Hourly_Counter[14]}</center></td>

<td>22:00-23:00</td>
<td><center>{data2.Hourly_Counter[22]}</center></td>
</tr>



<tr>
<td>7:00-8:00</td>
<td><center>{data2.Hourly_Counter[7]}</center></td>

<td>15:00-16:00</td>
<td><center>{data2.Hourly_Counter[15]}</center></td>

<td>23:00-00:00</td>
<td><center>{data2.Hourly_Counter[23]}</center></td>
</tr>



<tr>
<td>8:00-9:00</td>
<td><center>{data2.Hourly_Counter[8]}</center></td>

<td>16:00-17:00</td>
<td><center>{data2.Hourly_Counter[16]}</center></td>

<td>00:00-1:00</td>
<td><center>{data2.Hourly_Counter[0]}</center></td>
</tr>



<tr>
<td>9:00-10:00</td>
<td><center>{data2.Hourly_Counter[9]}</center></td>

<td>17:00-18:00</td>
<td><center>{data2.Hourly_Counter[17]}</center></td>

<td>1:00-2:00</td>
<td><center>{data2.Hourly_Counter[1]}</center></td>
</tr>

<tr>
<td>10:00-11:00</td>
<td><center>{data2.Hourly_Counter[10]}</center></td>

<td>18:00-19:00</td>
<td><center>{data2.Hourly_Counter[18]}</center></td>

<td>2:00-3:00</td>
<td><center>{data2.Hourly_Counter[2]}</center></td>
</tr>

<tr>
<td>11:00-12:00</td>
<td><center>{data2.Hourly_Counter[11]}</center></td>

<td>19:00-20:00</td>
<td><center>{data2.Hourly_Counter[19]}</center></td>

<td>3:00-2:00</td>
<td><center>{data2.Hourly_Counter[3]}</center></td>
</tr>

<tr>
<td>12:00-13:00</td>
<td><center>{data2.Hourly_Counter[12]}</center></td>
<td>20:00-21:00</td>
<td><center>{data2.Hourly_Counter[20]}</center></td>
<td>4:00-5:00</td>
<td><center>{data2.Hourly_Counter[4]}</center></td>
</tr>

<tr>
<td>Total Shift 1</td>
<td><center>{data2.Todays_Shifts[0]}</center></td>
<td>Total Shift 2</td>
<td><center>{data2.Todays_Shifts[1]}</center></td>
<td>Total Shift 3</td>
<td><center>{data2.Todays_Shifts[2]}</center></td>
</tr>

<tr>
<td>Yesterday's Totals Shift 1</td>
<td><center>{data2.Ydays_Shifts[0]}</center></td>
<td>Yesterday's Totals Shift 3</td>
<td><center>{data2.Ydays_Shifts[1]}</center></td>
<td>Yesterday's Totals Shift 3</td>
<td><center>{data2.Ydays_Shifts[2]}</center></td>
</tr>






</table>
<p></p>
<p></p>
<p><b>Line Record: {LineRecord} </b></p>
<p></p>
<p><b>Total Overall Lines: {data.Todays_Total + data2.Todays_Total} </b></p>
<p></p>
<p>This has been sent by IOT Application Automatically at end of shifts<br></br></p>

<p>Host Name: {HostName} </p>
 



      </body>
</html>
             ";
            return htmlString;
        }



    }


}
