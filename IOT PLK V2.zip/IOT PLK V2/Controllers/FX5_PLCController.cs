﻿using System;
using System.Collections.Generic;
using System.Text;
using PLK_IIOT_V2.Models;
using Corsinvest.AllenBradley.PLC.Api;
using System.Threading.Tasks;
using System.Threading;
using System.Linq;
using System.Windows.Forms;
using System.Net.NetworkInformation;
using HslCommunication.Profinet.Melsec;
using HslCommunication;
using HslCommunication.ModBus;

namespace PLK_IIOT_V2.Controllers
{
    class FX5_PLCController
    {
        EmailController Emailsend = new EmailController();
        public bool connected;
        Controller cpu;
        TagGroup g1;
        public string tag = null;
        public string tag2 = null;
        string ip_address;
        bool enabled;
        //public Tag<Model_PLC_1>[] Nest = new Tag<Model_PLC_1>[2];

        public IOT_Tags_1 Datareaded_out = new IOT_Tags_1();
        public IOT_Tags_1 Datareaded_out_temp = new IOT_Tags_1();

        public int attempt2connect = 0, attempting = 0, attempting_not_read = 0, attemptemail1 = 0, attemptemail2 = 0;
        public bool plc_disable, pinging_ip1, pinging_ip2, reset_done = false;
        string path;
        bool testingmode = false;
        int plc_no = new int();
        public int j;
        //Nest 0 = Flex Line
        //Nest 1 = Main Line
        public PLC_settings PLC1_Settings = new PLC_settings();
        public PLC_settings PLC2_Settings = new PLC_settings();
        NotepadController Notepad = new NotepadController();
        string ip_address2;

        short[] testread;
        int currentPLC = new int();

        //short[] memory;
        IOT_Tags_1 PLC_return = new IOT_Tags_1();

        bool plc1enabled = new bool();
        bool plc2enabled = new bool();
        public FX5_PLCController(string enabled, string ip, string path, string tag_in, string tag_in2, int plc_no)
        {

            
            if (enabled == "1")
            {
                this.path = path;
                this.enabled = true;
                this.plc_no = plc_no;
                cpu = new Controller(ip, path, CPUType.LGX);
                g1 = cpu.CreateGroup();
                tag = tag_in;
                tag2 = tag_in2;
                ip_address = ip;

                //Thread1();

                if (true)
                {
                    Task.Run(Thread1);

                }

            }
           





        }
    
       

         
void Thread1()
        {
        
            while (true)
            {





                var ping = pinging(ip_address);
                pinging_ip1 = ping;
                var r = 0;
                if (ping == true)
                {
                    var t = 0;
                    if ((attempting_not_read > 1 || attempting > 1) && ping == true)
                    {

                        Emailsend.SimpleEmailSender($"{PLC1_Settings.Machine_Name} IOT: Comunication Restablished and restarted {ip_address}", $"\n After Attemp Read No: {attempting_not_read} \n\n After Attemp Ping No: {attempting} \n");

                        attempting_not_read = 0;
                        attempting = 0;



                    }

                    var PLC = PLCReading(Datareaded_out, ip_address);
                    Datareaded_out = PLC;
                    var g = 0;
                    Datareaded_out_temp = Datareaded_out;
                    Thread.Sleep(100);
                }
                else
                {
                    
                    attempting++;
                    attemptemail2++;

                    if (attemptemail2 > 6000000 || attempting == 1)
                    {
                        attemptemail2 = 0;
                        Emailsend.SimpleEmailSender($"{PLC1_Settings.Machine_Name} IOT: No Pinging, No Connection PLC {ip_address}", $"\n Attemp No: {attempting} \n Check Ethernet Connection or PLC\n");
                        Datareaded_out_temp = Datareaded_out;
                    }
                    Datareaded_out = Datareaded_out_temp;
                    Thread.Sleep(1000);
                }

               
                
            }
       


        }
        public IOT_Tags_1 PLCReading(IOT_Tags_1 value, string ipaddress)
        {
            IOT_Tags_1 PLC_return = new IOT_Tags_1();


            using (ModbusTcpNet busTcpClient = new ModbusTcpNet(ipaddress, 10000, 0))
            {
                busTcpClient?.ConnectClose();
                busTcpClient.AddressStartWithZero = true;
                busTcpClient.IsCheckMessageId = true;
                busTcpClient.IsStringReverse = false;
                busTcpClient.DataFormat = HslCommunication.Core.DataFormat.ABCD;
                try
                {
                    OperateResult connect = busTcpClient.ConnectServer();
                    if (connect.IsSuccess)
                    {

                       
                        var memory = busTcpClient.ReadInt16("4000", 500).Content;//read the short value of register 100
                      
                        if (memory.Length >= 70 ||memory != null)
                        {
                            var hourly = (memory.Take(24).ToArray());
                            for (int i = 0; i < 24; i++)
                            {
                                PLC_return.Hourly_Counter[i] = (int)hourly[i];

                            }

                            PLC_return.Current_Shift = memory[24];
                             var shiftstoday = memory.Skip(25).Take(3).ToArray();
                            PLC_return.Todays_Shifts[0] = (int)shiftstoday[0];
                            PLC_return.Todays_Shifts[1] = (int)shiftstoday[1];
                            PLC_return.Todays_Shifts[2] = (int)shiftstoday[2];

                            PLC_return.Todays_Total = (int)memory[28];

                            var ydayshift = memory.Skip(28).Take(3).ToArray();
                            PLC_return.Ydays_Shifts[0] = (int)ydayshift[0];
                            PLC_return.Ydays_Shifts[1] = (int)ydayshift[1];
                            PLC_return.Ydays_Shifts[2] = (int)ydayshift[2];



                            PLC_return.Ydays_Total = memory[32];

                            var shift_scrap = memory.Skip(32).Take(3).ToArray();

                            // PLC_return.shift_scrap = Array.ConvertAll(shift_scrap, val => (int)val);

                            var today_scrap = memory[36];
                            var yday_scrap = memory[37];
                            PLC_return.Daily_Target = memory[38];
                            PLC_return.Sequence_Step_Num = memory[40];
                            PLC_return.Current_Shift = memory[42];
                            PLC_return.Current_Takt_time_msec = memory[44]*100; //FLOTANTE
                            PLC_return.Avg_Takt_Time_msec = memory[46]*100;

                            PLC_return.Alarm_msg = "";
                            PLC_return.Last_Takt_Time_msec = memory[48]*100;

                            PLC_return.OEE_Day = memory[50]/100;
                            PLC_return.OEE_Shift[0] = memory[52]/100;
                            PLC_return.OEE_Shift[1] = memory[54]/100;
                            PLC_return.OEE_Shift[2] = memory[56]/100;

                            PLC_return.PLC_Datetime[0] = memory[60];
                            PLC_return.PLC_Datetime[1] = memory[61];
                            PLC_return.PLC_Datetime[2] = memory[62];
                            PLC_return.PLC_Datetime[3] = memory[63];
                            PLC_return.PLC_Datetime[4] = memory[64];
                            PLC_return.PLC_Datetime[5] = memory[65];
                            PLC_return.Day_of_Week = memory[66];

                            PLC_return.Heartbeat = memory[67];
                            PLC_return.Remotereset = memory[68];
                            PLC_return.Linerecord = memory[69];

                            //MONDAY
                            PLC_return.Weekly_Count_S1[0]=memory[70];
                            PLC_return.Weekly_Count_S2[0]=memory[71];
                            PLC_return.Weekly_Count_S3[0]=memory[72];
                            
                            //TUE
                            PLC_return.Weekly_Count_S1[1]=memory[73];
                            PLC_return.Weekly_Count_S2[1]=memory[74];
                            PLC_return.Weekly_Count_S3[1]=memory[75];

                            //WED
                            PLC_return.Weekly_Count_S1[2]=memory[76];
                            PLC_return.Weekly_Count_S2[2]=memory[77];
                            PLC_return.Weekly_Count_S3[2]=memory[78];
                            
                            //THU
                            PLC_return.Weekly_Count_S1[3]=memory[79];
                            PLC_return.Weekly_Count_S2[3]=memory[80];
                            PLC_return.Weekly_Count_S3[3]=memory[81];

                            //FRI
                            PLC_return.Weekly_Count_S1[4] = memory[82];
                            PLC_return.Weekly_Count_S2[4] = memory[83];
                            PLC_return.Weekly_Count_S3[4] = memory[84];

                            //SAT
                            PLC_return.Weekly_Count_S1[5] = memory[85];
                            PLC_return.Weekly_Count_S2[5] = memory[86];
                            PLC_return.Weekly_Count_S3[5] = memory[87];

                            //SUN
                            PLC_return.Weekly_Count_S1[6] = memory[88];
                            PLC_return.Weekly_Count_S2[6] = memory[89];
                            PLC_return.Weekly_Count_S3[6] = memory[90];

                            PLC_return.Alarm_Code = memory[91];


                            //shift 1 start
                            PLC_return.SpareDINT[0] = memory[92];
                            //shift 1 end
                            PLC_return.SpareDINT[1] = memory[93];

                            //shift 2 start
                            PLC_return.SpareDINT[2] = memory[94];
                            //shift 2 end
                            PLC_return.SpareDINT[3] = memory[95];

                            //shift 3 start
                            PLC_return.SpareDINT[4] = memory[96];
                            //shift 3 end
                            PLC_return.SpareDINT[5] = memory[97];
                          
                            for (int i = 0; i < 168; i++)
                            {
                                PLC_return.Weekly_Count_OEE[i] = memory[i+150];
                              
                            }

                       
                            for (int i = 0; i < 169; i++)
                            {
                                PLC_return.Weekly_Count_Hours[i] =(int) memory[i+318];
                               
                            }

                            PLC_return.Ip_Address = PLC1_Settings.Ip_Address;
                            PLC_return.Machine_Name = PLC1_Settings.Machine_Name;
                            PLC_return.Sequence_Step_msg = "";

                        }

                    }
                    else
                    {
                        MessageBox.Show(HslCommunication.StringResources.Language.ConnectedFailed + connect.Message + Environment.NewLine +
                            "Error: " + connect.ErrorCode);

                        PLC_return = value;
                        attempting_not_read++;
                        attemptemail1++;
                        if (attemptemail1 > 6000000 || attempting_not_read == 1)
                        {
                            attemptemail1 = 0;
                            Emailsend.SimpleEmailSender($" {PLC1_Settings.Machine_Name} IOT: Not Reading, No Data Readed{ip_address}", $"\n Attemp No: {attempting_not_read} \n {HslCommunication.StringResources.Language.ConnectedFailed} + {connect.Message} + {Environment.NewLine} + Error:  + {connect.ErrorCode}");
                        }

                        connected = false;
                        plc_disable = true;

                        Thread.Sleep(1000);

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
          
            return PLC_return;
        }

        public bool pinging(string ip)
        {
            bool plc_connected = false;
            try
            {
                Ping myPing = new Ping();
                PingReply reply = myPing.Send(ip, 1000);
                if (reply.Status == IPStatus.Success)
                {
                    Console.WriteLine("Status :  " + reply.Status + " \n Time : " + reply.RoundtripTime.ToString() + " \n Address : " + reply.Address);
                    //Console.WriteLine(reply.ToString());
                    //string message = "Status :  " + reply.Status + " \n Time : " + reply.RoundtripTime.ToString() + " \n Address : " + reply.Address;
                    //string title = $"Message: PLC {ip} Connected";
                    //MessageBox.Show(message, title);
                    plc_connected = true;


                }
                else
                {


                    string message = "No Pinging, PLC has been disconnected";
                    string title = $"Error: PLC Address {ip} Not Connected";
                    //MessageBoxButtons buttons = MessageBoxButtons.OK;
                    //MessageBox.Show(message, title, buttons, MessageBoxIcon.Warning);
                    plc_connected = false;

                }
            }
            catch (Exception e)
            {

                Console.WriteLine("Exception: " + e.Message);
                string message = e.Message;
                string title = $"Error: PLC Address {ip} has been disconnected";
                //MessageBoxButtons buttons = MessageBoxButtons.OK;
                //MessageBox.Show(message, title, buttons, MessageBoxIcon.Warning);
                plc_connected = false;


               

            }
            return plc_connected;

        }

    }



}


  