﻿using System;
using System.Collections.Generic;
using System.Text;
using PLK_IIOT_V2.Models;
using Corsinvest.AllenBradley.PLC.Api;
using System.Threading.Tasks;
using System.Threading;
using System.Linq;
using System.IO;
using System.Windows.Forms;

namespace PLK_IIOT_V2.Controllers
{
    class NotepadController
    {
        List<string> returnstrings = new List<string>();
        string error_line;
        public string[] readed_value = new string[30];
        public string path = Directory.GetCurrentDirectory();

        public PLC_settings PLC1_Settings = new PLC_settings();
        public PLC_settings PLC2_Settings = new PLC_settings();
        public NotepadController()
        {



        }


        public void Write_Notepad(List<string> Data_in, string notepad_name)
        {
            CreateDirectory();
            try
            {

                //Pass the filepath and filename to the StreamWriter Constructor
                StreamWriter sw = new StreamWriter($"{path}\\notepad data\\DataStored_{notepad_name}.txt");

                for (int i = 0; i < Data_in.Count; i++)
                {
                    sw.WriteLine(Data_in[i]);
                }
                //Close the file
                sw.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.Message);
                string message = e.Message;
                string title = "Error Write";
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                MessageBox.Show(message, title, buttons, MessageBoxIcon.Warning);
            }
            finally
            {
                Console.WriteLine("Executing finally block.");
            }

        }
        public List<string> Read_Notepad(string notepad_number)
        {
            returnstrings.Clear();
             String line, ln;
            int counter = 0, return_value = 0;
            try
            {
                //Pass the file path and file name to the StreamReader constructor
                StreamReader sr_countline = new StreamReader($"{path}\\notepad data\\DataStored_{notepad_number}.txt");
                StreamReader sr = new StreamReader($"{path}\\notepad data\\DataStored_{notepad_number}.txt");
                //Count all lines of text

                while ((ln = sr_countline.ReadLine()) != null && ln.Length > 0)
                {

                    counter++;
                }
                var f = 0;
                //returnstrings = new string[counter];
                //Read until you reach end of file
                for (int i = 0; i < counter; i++)
                {


                    //Read the next line
                    line = sr.ReadLine();
                    returnstrings.Add(line);
                    error_line = line;
                    var sd = 0;
                }


                //close the file
                sr.Close();
                sr_countline.Close();


            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.Message);
                string message = e.Message + "\n" + $"DataStored_{notepad_number}" + $"\n Line:{error_line}";
                string title = "Error Read";
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                MessageBox.Show(message, title, buttons, MessageBoxIcon.Warning);
                Thread.Sleep(10000);
            }
            finally
            {
                Console.WriteLine("Executing finally block.");
            }
            return returnstrings;

        }
        void CreateDirectory()
        {
            // Specify the directory you want to manipulate.



            string folderName = $"{path}\\Notepad Data";
            // If directory does not exist, create it
            if (!Directory.Exists(folderName))
            {
                Directory.CreateDirectory(folderName);
            }


        }
        public int readlines(string notepad_number)
        {
            string[] returnstrings = new string[50];
            String line, ln;
            int counter = 0, return_value = 0;
            try
            {
                //Pass the file path and file name to the StreamReader constructor
                StreamReader sr_countline = new StreamReader($"{path}\\notepad data\\DataStored_{notepad_number}.txt");
                StreamReader sr = new StreamReader($"{path}\\notepad data\\DataStored_{notepad_number}.txt");
                //Count all lines of text

                while ((ln = sr_countline.ReadLine()) != null)
                {

                    counter++;
                }
                var f = 0;
                return_value = counter;
                sr_countline.Close();


            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.Message);
                string message = e.Message;
                string title = "Error Read Lines";
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                MessageBox.Show(message, title, buttons, MessageBoxIcon.Warning);
                Thread.Sleep(10000);
            }
            finally
            {
                Console.WriteLine("Executing finally block.");
            }
            return return_value;

        }








    }
}


