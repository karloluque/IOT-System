﻿namespace PLK_IIOT_V2
{
    partial class DataForm2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.lbl_s3h8 = new System.Windows.Forms.Label();
            this.label_s3h8 = new System.Windows.Forms.Label();
            this.lbl_s2h8 = new System.Windows.Forms.Label();
            this.label_s2h8 = new System.Windows.Forms.Label();
            this.lbl_s1h8 = new System.Windows.Forms.Label();
            this.label_s1h8 = new System.Windows.Forms.Label();
            this.lbl_s3h7 = new System.Windows.Forms.Label();
            this.label_s3h7 = new System.Windows.Forms.Label();
            this.lbl_s2h7 = new System.Windows.Forms.Label();
            this.label_s2h7 = new System.Windows.Forms.Label();
            this.lbl_s1h7 = new System.Windows.Forms.Label();
            this.label_s1h7 = new System.Windows.Forms.Label();
            this.lbl_s3h6 = new System.Windows.Forms.Label();
            this.label_s3h6 = new System.Windows.Forms.Label();
            this.lbl_s2h6 = new System.Windows.Forms.Label();
            this.label_s2h6 = new System.Windows.Forms.Label();
            this.lbl_s1h6 = new System.Windows.Forms.Label();
            this.label_s1h6 = new System.Windows.Forms.Label();
            this.lbl_s3h5 = new System.Windows.Forms.Label();
            this.label_s3h5 = new System.Windows.Forms.Label();
            this.lbl_s2h5 = new System.Windows.Forms.Label();
            this.label_s2h5 = new System.Windows.Forms.Label();
            this.lbl_s1h5 = new System.Windows.Forms.Label();
            this.label_s1h5 = new System.Windows.Forms.Label();
            this.lbl_s3h4 = new System.Windows.Forms.Label();
            this.label_s3h4 = new System.Windows.Forms.Label();
            this.lbl_s2h4 = new System.Windows.Forms.Label();
            this.label_s2h4 = new System.Windows.Forms.Label();
            this.lbl_s1h4 = new System.Windows.Forms.Label();
            this.label_s1h4 = new System.Windows.Forms.Label();
            this.lbl_s3h3 = new System.Windows.Forms.Label();
            this.label_s3h3 = new System.Windows.Forms.Label();
            this.lbl_s2h3 = new System.Windows.Forms.Label();
            this.label_s2h3 = new System.Windows.Forms.Label();
            this.lbl_s1h3 = new System.Windows.Forms.Label();
            this.label_s1h3 = new System.Windows.Forms.Label();
            this.lbl_s3h2 = new System.Windows.Forms.Label();
            this.label_s3h2 = new System.Windows.Forms.Label();
            this.lbl_s2h2 = new System.Windows.Forms.Label();
            this.label_s2h2 = new System.Windows.Forms.Label();
            this.lbl_s1h2 = new System.Windows.Forms.Label();
            this.label_s1h2 = new System.Windows.Forms.Label();
            this.lbl_s3h1 = new System.Windows.Forms.Label();
            this.label_s3h1 = new System.Windows.Forms.Label();
            this.lbl_s2h1 = new System.Windows.Forms.Label();
            this.label_s2h1 = new System.Windows.Forms.Label();
            this.lbl_s1h1 = new System.Windows.Forms.Label();
            this.label_s1h1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.label9 = new System.Windows.Forms.Label();
            this.lbl_total_s1 = new System.Windows.Forms.Label();
            this.label_total_s1 = new System.Windows.Forms.Label();
            this.label_total_s3 = new System.Windows.Forms.Label();
            this.lbl_total_s2 = new System.Windows.Forms.Label();
            this.lbl_total_s3 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.lbl_lasttakt = new System.Windows.Forms.Label();
            this.lbl_avg_takttime = new System.Windows.Forms.Label();
            this.lbl_oee = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
            this.label88 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.tableLayoutPanel13 = new System.Windows.Forms.TableLayoutPanel();
            this.pb_heartbeat = new System.Windows.Forms.PictureBox();
            this.label_tittle = new System.Windows.Forms.Label();
            this.lbl_date = new System.Windows.Forms.Label();
            this.tmr_update = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.panel4.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.panel15.SuspendLayout();
            this.tableLayoutPanel11.SuspendLayout();
            this.tableLayoutPanel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_heartbeat)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1003, 1036);
            this.panel1.TabIndex = 0;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(43)))), ((int)(((byte)(87)))));
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Controls.Add(this.panel2, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel3, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.panel4, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.panel5, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.panel15, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel13, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 6;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 3F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 3F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1003, 1036);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(56)))), ((int)(((byte)(66)))));
            this.panel2.Controls.Add(this.tableLayoutPanel2);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 82);
            this.panel2.Margin = new System.Windows.Forms.Padding(0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1003, 725);
            this.panel2.TabIndex = 0;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(43)))), ((int)(((byte)(87)))));
            this.tableLayoutPanel2.ColumnCount = 6;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.001F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 23.33233F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.001F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 23.33233F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.001F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 23.33233F));
            this.tableLayoutPanel2.Controls.Add(this.lbl_s3h8, 5, 7);
            this.tableLayoutPanel2.Controls.Add(this.label_s3h8, 4, 7);
            this.tableLayoutPanel2.Controls.Add(this.lbl_s2h8, 3, 7);
            this.tableLayoutPanel2.Controls.Add(this.label_s2h8, 2, 7);
            this.tableLayoutPanel2.Controls.Add(this.lbl_s1h8, 1, 7);
            this.tableLayoutPanel2.Controls.Add(this.label_s1h8, 0, 7);
            this.tableLayoutPanel2.Controls.Add(this.lbl_s3h7, 5, 6);
            this.tableLayoutPanel2.Controls.Add(this.label_s3h7, 4, 6);
            this.tableLayoutPanel2.Controls.Add(this.lbl_s2h7, 3, 6);
            this.tableLayoutPanel2.Controls.Add(this.label_s2h7, 2, 6);
            this.tableLayoutPanel2.Controls.Add(this.lbl_s1h7, 1, 6);
            this.tableLayoutPanel2.Controls.Add(this.label_s1h7, 0, 6);
            this.tableLayoutPanel2.Controls.Add(this.lbl_s3h6, 5, 5);
            this.tableLayoutPanel2.Controls.Add(this.label_s3h6, 4, 5);
            this.tableLayoutPanel2.Controls.Add(this.lbl_s2h6, 3, 5);
            this.tableLayoutPanel2.Controls.Add(this.label_s2h6, 2, 5);
            this.tableLayoutPanel2.Controls.Add(this.lbl_s1h6, 1, 5);
            this.tableLayoutPanel2.Controls.Add(this.label_s1h6, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.lbl_s3h5, 5, 4);
            this.tableLayoutPanel2.Controls.Add(this.label_s3h5, 4, 4);
            this.tableLayoutPanel2.Controls.Add(this.lbl_s2h5, 3, 4);
            this.tableLayoutPanel2.Controls.Add(this.label_s2h5, 2, 4);
            this.tableLayoutPanel2.Controls.Add(this.lbl_s1h5, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.label_s1h5, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.lbl_s3h4, 5, 3);
            this.tableLayoutPanel2.Controls.Add(this.label_s3h4, 4, 3);
            this.tableLayoutPanel2.Controls.Add(this.lbl_s2h4, 3, 3);
            this.tableLayoutPanel2.Controls.Add(this.label_s2h4, 2, 3);
            this.tableLayoutPanel2.Controls.Add(this.lbl_s1h4, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.label_s1h4, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.lbl_s3h3, 5, 2);
            this.tableLayoutPanel2.Controls.Add(this.label_s3h3, 4, 2);
            this.tableLayoutPanel2.Controls.Add(this.lbl_s2h3, 3, 2);
            this.tableLayoutPanel2.Controls.Add(this.label_s2h3, 2, 2);
            this.tableLayoutPanel2.Controls.Add(this.lbl_s1h3, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.label_s1h3, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.lbl_s3h2, 5, 1);
            this.tableLayoutPanel2.Controls.Add(this.label_s3h2, 4, 1);
            this.tableLayoutPanel2.Controls.Add(this.lbl_s2h2, 3, 1);
            this.tableLayoutPanel2.Controls.Add(this.label_s2h2, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.lbl_s1h2, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.label_s1h2, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.lbl_s3h1, 5, 0);
            this.tableLayoutPanel2.Controls.Add(this.label_s3h1, 4, 0);
            this.tableLayoutPanel2.Controls.Add(this.lbl_s2h1, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.label_s2h1, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.lbl_s1h1, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.label_s1h1, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 8;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1003, 725);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // lbl_s3h8
            // 
            this.lbl_s3h8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(43)))), ((int)(((byte)(87)))));
            this.lbl_s3h8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_s3h8.Font = new System.Drawing.Font("Segoe UI", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_s3h8.ForeColor = System.Drawing.Color.White;
            this.lbl_s3h8.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_s3h8.Location = new System.Drawing.Point(771, 633);
            this.lbl_s3h8.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_s3h8.Name = "lbl_s3h8";
            this.lbl_s3h8.Size = new System.Drawing.Size(229, 92);
            this.lbl_s3h8.TabIndex = 47;
            this.lbl_s3h8.Text = "XXX";
            this.lbl_s3h8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_s3h8
            // 
            this.label_s3h8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(182)))), ((int)(((byte)(244)))));
            this.label_s3h8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_s3h8.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_s3h8.ForeColor = System.Drawing.Color.Black;
            this.label_s3h8.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label_s3h8.Location = new System.Drawing.Point(671, 633);
            this.label_s3h8.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label_s3h8.Name = "label_s3h8";
            this.label_s3h8.Size = new System.Drawing.Size(94, 92);
            this.label_s3h8.TabIndex = 46;
            this.label_s3h8.Text = "4:00";
            this.label_s3h8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_s2h8
            // 
            this.lbl_s2h8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(43)))), ((int)(((byte)(87)))));
            this.lbl_s2h8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_s2h8.Font = new System.Drawing.Font("Segoe UI", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_s2h8.ForeColor = System.Drawing.Color.White;
            this.lbl_s2h8.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_s2h8.Location = new System.Drawing.Point(437, 633);
            this.lbl_s2h8.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_s2h8.Name = "lbl_s2h8";
            this.lbl_s2h8.Size = new System.Drawing.Size(228, 92);
            this.lbl_s2h8.TabIndex = 45;
            this.lbl_s2h8.Text = "XXX";
            this.lbl_s2h8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_s2h8
            // 
            this.label_s2h8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(182)))), ((int)(((byte)(244)))));
            this.label_s2h8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_s2h8.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_s2h8.ForeColor = System.Drawing.Color.Black;
            this.label_s2h8.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label_s2h8.Location = new System.Drawing.Point(337, 633);
            this.label_s2h8.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label_s2h8.Name = "label_s2h8";
            this.label_s2h8.Size = new System.Drawing.Size(94, 92);
            this.label_s2h8.TabIndex = 44;
            this.label_s2h8.Text = "20:00";
            this.label_s2h8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_s1h8
            // 
            this.lbl_s1h8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(43)))), ((int)(((byte)(87)))));
            this.lbl_s1h8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_s1h8.Font = new System.Drawing.Font("Segoe UI", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_s1h8.ForeColor = System.Drawing.Color.White;
            this.lbl_s1h8.Location = new System.Drawing.Point(103, 633);
            this.lbl_s1h8.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_s1h8.Name = "lbl_s1h8";
            this.lbl_s1h8.Size = new System.Drawing.Size(228, 92);
            this.lbl_s1h8.TabIndex = 43;
            this.lbl_s1h8.Text = "XXX";
            this.lbl_s1h8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_s1h8
            // 
            this.label_s1h8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(182)))), ((int)(((byte)(244)))));
            this.label_s1h8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_s1h8.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_s1h8.ForeColor = System.Drawing.Color.Black;
            this.label_s1h8.Location = new System.Drawing.Point(3, 633);
            this.label_s1h8.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label_s1h8.Name = "label_s1h8";
            this.label_s1h8.Size = new System.Drawing.Size(94, 92);
            this.label_s1h8.TabIndex = 42;
            this.label_s1h8.Text = "12:00";
            this.label_s1h8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_s3h7
            // 
            this.lbl_s3h7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(43)))), ((int)(((byte)(87)))));
            this.lbl_s3h7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_s3h7.Font = new System.Drawing.Font("Segoe UI", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_s3h7.ForeColor = System.Drawing.Color.White;
            this.lbl_s3h7.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_s3h7.Location = new System.Drawing.Point(771, 543);
            this.lbl_s3h7.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_s3h7.Name = "lbl_s3h7";
            this.lbl_s3h7.Size = new System.Drawing.Size(229, 87);
            this.lbl_s3h7.TabIndex = 41;
            this.lbl_s3h7.Text = "XXX";
            this.lbl_s3h7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_s3h7
            // 
            this.label_s3h7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(182)))), ((int)(((byte)(244)))));
            this.label_s3h7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_s3h7.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_s3h7.ForeColor = System.Drawing.Color.Black;
            this.label_s3h7.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label_s3h7.Location = new System.Drawing.Point(671, 543);
            this.label_s3h7.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label_s3h7.Name = "label_s3h7";
            this.label_s3h7.Size = new System.Drawing.Size(94, 87);
            this.label_s3h7.TabIndex = 40;
            this.label_s3h7.Text = "3:00";
            this.label_s3h7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_s2h7
            // 
            this.lbl_s2h7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(43)))), ((int)(((byte)(87)))));
            this.lbl_s2h7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_s2h7.Font = new System.Drawing.Font("Segoe UI", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_s2h7.ForeColor = System.Drawing.Color.White;
            this.lbl_s2h7.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_s2h7.Location = new System.Drawing.Point(437, 543);
            this.lbl_s2h7.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_s2h7.Name = "lbl_s2h7";
            this.lbl_s2h7.Size = new System.Drawing.Size(228, 87);
            this.lbl_s2h7.TabIndex = 39;
            this.lbl_s2h7.Text = "XXX";
            this.lbl_s2h7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_s2h7
            // 
            this.label_s2h7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(182)))), ((int)(((byte)(244)))));
            this.label_s2h7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_s2h7.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_s2h7.ForeColor = System.Drawing.Color.Black;
            this.label_s2h7.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label_s2h7.Location = new System.Drawing.Point(337, 543);
            this.label_s2h7.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label_s2h7.Name = "label_s2h7";
            this.label_s2h7.Size = new System.Drawing.Size(94, 87);
            this.label_s2h7.TabIndex = 38;
            this.label_s2h7.Text = "19:00";
            this.label_s2h7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_s1h7
            // 
            this.lbl_s1h7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(43)))), ((int)(((byte)(87)))));
            this.lbl_s1h7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_s1h7.Font = new System.Drawing.Font("Segoe UI", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_s1h7.ForeColor = System.Drawing.Color.White;
            this.lbl_s1h7.Location = new System.Drawing.Point(103, 543);
            this.lbl_s1h7.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_s1h7.Name = "lbl_s1h7";
            this.lbl_s1h7.Size = new System.Drawing.Size(228, 87);
            this.lbl_s1h7.TabIndex = 37;
            this.lbl_s1h7.Text = "XXX";
            this.lbl_s1h7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_s1h7
            // 
            this.label_s1h7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(182)))), ((int)(((byte)(244)))));
            this.label_s1h7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_s1h7.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_s1h7.ForeColor = System.Drawing.Color.Black;
            this.label_s1h7.Location = new System.Drawing.Point(3, 543);
            this.label_s1h7.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label_s1h7.Name = "label_s1h7";
            this.label_s1h7.Size = new System.Drawing.Size(94, 87);
            this.label_s1h7.TabIndex = 36;
            this.label_s1h7.Text = "11:00";
            this.label_s1h7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_s3h6
            // 
            this.lbl_s3h6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(43)))), ((int)(((byte)(87)))));
            this.lbl_s3h6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_s3h6.Font = new System.Drawing.Font("Segoe UI", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_s3h6.ForeColor = System.Drawing.Color.White;
            this.lbl_s3h6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_s3h6.Location = new System.Drawing.Point(771, 453);
            this.lbl_s3h6.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_s3h6.Name = "lbl_s3h6";
            this.lbl_s3h6.Size = new System.Drawing.Size(229, 87);
            this.lbl_s3h6.TabIndex = 35;
            this.lbl_s3h6.Text = "XXX";
            this.lbl_s3h6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_s3h6
            // 
            this.label_s3h6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(182)))), ((int)(((byte)(244)))));
            this.label_s3h6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_s3h6.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_s3h6.ForeColor = System.Drawing.Color.Black;
            this.label_s3h6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label_s3h6.Location = new System.Drawing.Point(671, 453);
            this.label_s3h6.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label_s3h6.Name = "label_s3h6";
            this.label_s3h6.Size = new System.Drawing.Size(94, 87);
            this.label_s3h6.TabIndex = 34;
            this.label_s3h6.Text = "2:00";
            this.label_s3h6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_s2h6
            // 
            this.lbl_s2h6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(43)))), ((int)(((byte)(87)))));
            this.lbl_s2h6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_s2h6.Font = new System.Drawing.Font("Segoe UI", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_s2h6.ForeColor = System.Drawing.Color.White;
            this.lbl_s2h6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_s2h6.Location = new System.Drawing.Point(437, 453);
            this.lbl_s2h6.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_s2h6.Name = "lbl_s2h6";
            this.lbl_s2h6.Size = new System.Drawing.Size(228, 87);
            this.lbl_s2h6.TabIndex = 33;
            this.lbl_s2h6.Text = "XXX";
            this.lbl_s2h6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_s2h6
            // 
            this.label_s2h6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(182)))), ((int)(((byte)(244)))));
            this.label_s2h6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_s2h6.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_s2h6.ForeColor = System.Drawing.Color.Black;
            this.label_s2h6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label_s2h6.Location = new System.Drawing.Point(337, 453);
            this.label_s2h6.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label_s2h6.Name = "label_s2h6";
            this.label_s2h6.Size = new System.Drawing.Size(94, 87);
            this.label_s2h6.TabIndex = 32;
            this.label_s2h6.Text = "18:00";
            this.label_s2h6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_s1h6
            // 
            this.lbl_s1h6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(43)))), ((int)(((byte)(87)))));
            this.lbl_s1h6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_s1h6.Font = new System.Drawing.Font("Segoe UI", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_s1h6.ForeColor = System.Drawing.Color.White;
            this.lbl_s1h6.Location = new System.Drawing.Point(103, 453);
            this.lbl_s1h6.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_s1h6.Name = "lbl_s1h6";
            this.lbl_s1h6.Size = new System.Drawing.Size(228, 87);
            this.lbl_s1h6.TabIndex = 31;
            this.lbl_s1h6.Text = "XXX";
            this.lbl_s1h6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_s1h6
            // 
            this.label_s1h6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(182)))), ((int)(((byte)(244)))));
            this.label_s1h6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_s1h6.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_s1h6.ForeColor = System.Drawing.Color.Black;
            this.label_s1h6.Location = new System.Drawing.Point(3, 453);
            this.label_s1h6.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label_s1h6.Name = "label_s1h6";
            this.label_s1h6.Size = new System.Drawing.Size(94, 87);
            this.label_s1h6.TabIndex = 30;
            this.label_s1h6.Text = "10:00";
            this.label_s1h6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_s3h5
            // 
            this.lbl_s3h5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(43)))), ((int)(((byte)(87)))));
            this.lbl_s3h5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_s3h5.Font = new System.Drawing.Font("Segoe UI", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_s3h5.ForeColor = System.Drawing.Color.White;
            this.lbl_s3h5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_s3h5.Location = new System.Drawing.Point(771, 363);
            this.lbl_s3h5.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_s3h5.Name = "lbl_s3h5";
            this.lbl_s3h5.Size = new System.Drawing.Size(229, 87);
            this.lbl_s3h5.TabIndex = 29;
            this.lbl_s3h5.Text = "XXX";
            this.lbl_s3h5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_s3h5
            // 
            this.label_s3h5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(182)))), ((int)(((byte)(244)))));
            this.label_s3h5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_s3h5.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_s3h5.ForeColor = System.Drawing.Color.Black;
            this.label_s3h5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label_s3h5.Location = new System.Drawing.Point(671, 363);
            this.label_s3h5.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label_s3h5.Name = "label_s3h5";
            this.label_s3h5.Size = new System.Drawing.Size(94, 87);
            this.label_s3h5.TabIndex = 28;
            this.label_s3h5.Text = "1:00";
            this.label_s3h5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_s2h5
            // 
            this.lbl_s2h5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(43)))), ((int)(((byte)(87)))));
            this.lbl_s2h5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_s2h5.Font = new System.Drawing.Font("Segoe UI", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_s2h5.ForeColor = System.Drawing.Color.White;
            this.lbl_s2h5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_s2h5.Location = new System.Drawing.Point(437, 363);
            this.lbl_s2h5.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_s2h5.Name = "lbl_s2h5";
            this.lbl_s2h5.Size = new System.Drawing.Size(228, 87);
            this.lbl_s2h5.TabIndex = 27;
            this.lbl_s2h5.Text = "XXX";
            this.lbl_s2h5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_s2h5
            // 
            this.label_s2h5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(182)))), ((int)(((byte)(244)))));
            this.label_s2h5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_s2h5.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_s2h5.ForeColor = System.Drawing.Color.Black;
            this.label_s2h5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label_s2h5.Location = new System.Drawing.Point(337, 363);
            this.label_s2h5.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label_s2h5.Name = "label_s2h5";
            this.label_s2h5.Size = new System.Drawing.Size(94, 87);
            this.label_s2h5.TabIndex = 26;
            this.label_s2h5.Text = "17:00";
            this.label_s2h5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_s1h5
            // 
            this.lbl_s1h5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(43)))), ((int)(((byte)(87)))));
            this.lbl_s1h5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_s1h5.Font = new System.Drawing.Font("Segoe UI", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_s1h5.ForeColor = System.Drawing.Color.White;
            this.lbl_s1h5.Location = new System.Drawing.Point(103, 363);
            this.lbl_s1h5.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_s1h5.Name = "lbl_s1h5";
            this.lbl_s1h5.Size = new System.Drawing.Size(228, 87);
            this.lbl_s1h5.TabIndex = 25;
            this.lbl_s1h5.Text = "XXX";
            this.lbl_s1h5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_s1h5
            // 
            this.label_s1h5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(182)))), ((int)(((byte)(244)))));
            this.label_s1h5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_s1h5.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_s1h5.ForeColor = System.Drawing.Color.Black;
            this.label_s1h5.Location = new System.Drawing.Point(3, 363);
            this.label_s1h5.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label_s1h5.Name = "label_s1h5";
            this.label_s1h5.Size = new System.Drawing.Size(94, 87);
            this.label_s1h5.TabIndex = 24;
            this.label_s1h5.Text = "9:00";
            this.label_s1h5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_s3h4
            // 
            this.lbl_s3h4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(43)))), ((int)(((byte)(87)))));
            this.lbl_s3h4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_s3h4.Font = new System.Drawing.Font("Segoe UI", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_s3h4.ForeColor = System.Drawing.Color.White;
            this.lbl_s3h4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_s3h4.Location = new System.Drawing.Point(771, 273);
            this.lbl_s3h4.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_s3h4.Name = "lbl_s3h4";
            this.lbl_s3h4.Size = new System.Drawing.Size(229, 87);
            this.lbl_s3h4.TabIndex = 23;
            this.lbl_s3h4.Text = "XXX";
            this.lbl_s3h4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_s3h4
            // 
            this.label_s3h4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(182)))), ((int)(((byte)(244)))));
            this.label_s3h4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_s3h4.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_s3h4.ForeColor = System.Drawing.Color.Black;
            this.label_s3h4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label_s3h4.Location = new System.Drawing.Point(671, 273);
            this.label_s3h4.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label_s3h4.Name = "label_s3h4";
            this.label_s3h4.Size = new System.Drawing.Size(94, 87);
            this.label_s3h4.TabIndex = 22;
            this.label_s3h4.Text = "00:00";
            this.label_s3h4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_s2h4
            // 
            this.lbl_s2h4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(43)))), ((int)(((byte)(87)))));
            this.lbl_s2h4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_s2h4.Font = new System.Drawing.Font("Segoe UI", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_s2h4.ForeColor = System.Drawing.Color.White;
            this.lbl_s2h4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_s2h4.Location = new System.Drawing.Point(437, 273);
            this.lbl_s2h4.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_s2h4.Name = "lbl_s2h4";
            this.lbl_s2h4.Size = new System.Drawing.Size(228, 87);
            this.lbl_s2h4.TabIndex = 21;
            this.lbl_s2h4.Text = "XXX";
            this.lbl_s2h4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_s2h4
            // 
            this.label_s2h4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(182)))), ((int)(((byte)(244)))));
            this.label_s2h4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_s2h4.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_s2h4.ForeColor = System.Drawing.Color.Black;
            this.label_s2h4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label_s2h4.Location = new System.Drawing.Point(337, 273);
            this.label_s2h4.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label_s2h4.Name = "label_s2h4";
            this.label_s2h4.Size = new System.Drawing.Size(94, 87);
            this.label_s2h4.TabIndex = 20;
            this.label_s2h4.Text = "16:00";
            this.label_s2h4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_s1h4
            // 
            this.lbl_s1h4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(43)))), ((int)(((byte)(87)))));
            this.lbl_s1h4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_s1h4.Font = new System.Drawing.Font("Segoe UI", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_s1h4.ForeColor = System.Drawing.Color.White;
            this.lbl_s1h4.Location = new System.Drawing.Point(103, 273);
            this.lbl_s1h4.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_s1h4.Name = "lbl_s1h4";
            this.lbl_s1h4.Size = new System.Drawing.Size(228, 87);
            this.lbl_s1h4.TabIndex = 19;
            this.lbl_s1h4.Text = "XXX";
            this.lbl_s1h4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_s1h4
            // 
            this.label_s1h4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(182)))), ((int)(((byte)(244)))));
            this.label_s1h4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_s1h4.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_s1h4.ForeColor = System.Drawing.Color.Black;
            this.label_s1h4.Location = new System.Drawing.Point(3, 273);
            this.label_s1h4.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label_s1h4.Name = "label_s1h4";
            this.label_s1h4.Size = new System.Drawing.Size(94, 87);
            this.label_s1h4.TabIndex = 18;
            this.label_s1h4.Text = "8:00";
            this.label_s1h4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_s3h3
            // 
            this.lbl_s3h3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(43)))), ((int)(((byte)(87)))));
            this.lbl_s3h3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_s3h3.Font = new System.Drawing.Font("Segoe UI", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_s3h3.ForeColor = System.Drawing.Color.White;
            this.lbl_s3h3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_s3h3.Location = new System.Drawing.Point(771, 183);
            this.lbl_s3h3.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_s3h3.Name = "lbl_s3h3";
            this.lbl_s3h3.Size = new System.Drawing.Size(229, 87);
            this.lbl_s3h3.TabIndex = 17;
            this.lbl_s3h3.Text = "XXX";
            this.lbl_s3h3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_s3h3
            // 
            this.label_s3h3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(182)))), ((int)(((byte)(244)))));
            this.label_s3h3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_s3h3.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_s3h3.ForeColor = System.Drawing.Color.Black;
            this.label_s3h3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label_s3h3.Location = new System.Drawing.Point(671, 183);
            this.label_s3h3.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label_s3h3.Name = "label_s3h3";
            this.label_s3h3.Size = new System.Drawing.Size(94, 87);
            this.label_s3h3.TabIndex = 16;
            this.label_s3h3.Text = "23:00";
            this.label_s3h3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_s2h3
            // 
            this.lbl_s2h3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(43)))), ((int)(((byte)(87)))));
            this.lbl_s2h3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_s2h3.Font = new System.Drawing.Font("Segoe UI", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_s2h3.ForeColor = System.Drawing.Color.White;
            this.lbl_s2h3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_s2h3.Location = new System.Drawing.Point(437, 183);
            this.lbl_s2h3.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_s2h3.Name = "lbl_s2h3";
            this.lbl_s2h3.Size = new System.Drawing.Size(228, 87);
            this.lbl_s2h3.TabIndex = 15;
            this.lbl_s2h3.Text = "XXX";
            this.lbl_s2h3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_s2h3
            // 
            this.label_s2h3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(182)))), ((int)(((byte)(244)))));
            this.label_s2h3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_s2h3.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_s2h3.ForeColor = System.Drawing.Color.Black;
            this.label_s2h3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label_s2h3.Location = new System.Drawing.Point(337, 183);
            this.label_s2h3.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label_s2h3.Name = "label_s2h3";
            this.label_s2h3.Size = new System.Drawing.Size(94, 87);
            this.label_s2h3.TabIndex = 14;
            this.label_s2h3.Text = "15:00";
            this.label_s2h3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_s1h3
            // 
            this.lbl_s1h3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(43)))), ((int)(((byte)(87)))));
            this.lbl_s1h3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_s1h3.Font = new System.Drawing.Font("Segoe UI", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_s1h3.ForeColor = System.Drawing.Color.White;
            this.lbl_s1h3.Location = new System.Drawing.Point(103, 183);
            this.lbl_s1h3.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_s1h3.Name = "lbl_s1h3";
            this.lbl_s1h3.Size = new System.Drawing.Size(228, 87);
            this.lbl_s1h3.TabIndex = 13;
            this.lbl_s1h3.Text = "XXX";
            this.lbl_s1h3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_s1h3
            // 
            this.label_s1h3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(182)))), ((int)(((byte)(244)))));
            this.label_s1h3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_s1h3.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_s1h3.ForeColor = System.Drawing.Color.Black;
            this.label_s1h3.Location = new System.Drawing.Point(3, 183);
            this.label_s1h3.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label_s1h3.Name = "label_s1h3";
            this.label_s1h3.Size = new System.Drawing.Size(94, 87);
            this.label_s1h3.TabIndex = 12;
            this.label_s1h3.Text = "7:00";
            this.label_s1h3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_s3h2
            // 
            this.lbl_s3h2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(43)))), ((int)(((byte)(87)))));
            this.lbl_s3h2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_s3h2.Font = new System.Drawing.Font("Segoe UI", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_s3h2.ForeColor = System.Drawing.Color.White;
            this.lbl_s3h2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_s3h2.Location = new System.Drawing.Point(771, 93);
            this.lbl_s3h2.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_s3h2.Name = "lbl_s3h2";
            this.lbl_s3h2.Size = new System.Drawing.Size(229, 87);
            this.lbl_s3h2.TabIndex = 11;
            this.lbl_s3h2.Text = "XXX";
            this.lbl_s3h2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_s3h2
            // 
            this.label_s3h2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(182)))), ((int)(((byte)(244)))));
            this.label_s3h2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_s3h2.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_s3h2.ForeColor = System.Drawing.Color.Black;
            this.label_s3h2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label_s3h2.Location = new System.Drawing.Point(671, 93);
            this.label_s3h2.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label_s3h2.Name = "label_s3h2";
            this.label_s3h2.Size = new System.Drawing.Size(94, 87);
            this.label_s3h2.TabIndex = 10;
            this.label_s3h2.Text = "22:00";
            this.label_s3h2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_s2h2
            // 
            this.lbl_s2h2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(43)))), ((int)(((byte)(87)))));
            this.lbl_s2h2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_s2h2.Font = new System.Drawing.Font("Segoe UI", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_s2h2.ForeColor = System.Drawing.Color.White;
            this.lbl_s2h2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_s2h2.Location = new System.Drawing.Point(437, 93);
            this.lbl_s2h2.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_s2h2.Name = "lbl_s2h2";
            this.lbl_s2h2.Size = new System.Drawing.Size(228, 87);
            this.lbl_s2h2.TabIndex = 9;
            this.lbl_s2h2.Text = "XXX";
            this.lbl_s2h2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_s2h2
            // 
            this.label_s2h2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(182)))), ((int)(((byte)(244)))));
            this.label_s2h2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_s2h2.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_s2h2.ForeColor = System.Drawing.Color.Black;
            this.label_s2h2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label_s2h2.Location = new System.Drawing.Point(337, 93);
            this.label_s2h2.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label_s2h2.Name = "label_s2h2";
            this.label_s2h2.Size = new System.Drawing.Size(94, 87);
            this.label_s2h2.TabIndex = 8;
            this.label_s2h2.Text = "14:00";
            this.label_s2h2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_s1h2
            // 
            this.lbl_s1h2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(43)))), ((int)(((byte)(87)))));
            this.lbl_s1h2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_s1h2.Font = new System.Drawing.Font("Segoe UI", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_s1h2.ForeColor = System.Drawing.Color.White;
            this.lbl_s1h2.Location = new System.Drawing.Point(103, 93);
            this.lbl_s1h2.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_s1h2.Name = "lbl_s1h2";
            this.lbl_s1h2.Size = new System.Drawing.Size(228, 87);
            this.lbl_s1h2.TabIndex = 7;
            this.lbl_s1h2.Text = "XXX";
            this.lbl_s1h2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_s1h2
            // 
            this.label_s1h2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(182)))), ((int)(((byte)(244)))));
            this.label_s1h2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_s1h2.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_s1h2.ForeColor = System.Drawing.Color.Black;
            this.label_s1h2.Location = new System.Drawing.Point(3, 93);
            this.label_s1h2.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label_s1h2.Name = "label_s1h2";
            this.label_s1h2.Size = new System.Drawing.Size(94, 87);
            this.label_s1h2.TabIndex = 6;
            this.label_s1h2.Text = "6:00";
            this.label_s1h2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_s3h1
            // 
            this.lbl_s3h1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(43)))), ((int)(((byte)(87)))));
            this.lbl_s3h1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_s3h1.Font = new System.Drawing.Font("Segoe UI", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_s3h1.ForeColor = System.Drawing.Color.White;
            this.lbl_s3h1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_s3h1.Location = new System.Drawing.Point(771, 3);
            this.lbl_s3h1.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_s3h1.Name = "lbl_s3h1";
            this.lbl_s3h1.Size = new System.Drawing.Size(229, 87);
            this.lbl_s3h1.TabIndex = 5;
            this.lbl_s3h1.Text = "XXX";
            this.lbl_s3h1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_s3h1
            // 
            this.label_s3h1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(182)))), ((int)(((byte)(244)))));
            this.label_s3h1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_s3h1.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_s3h1.ForeColor = System.Drawing.Color.Black;
            this.label_s3h1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label_s3h1.Location = new System.Drawing.Point(671, 3);
            this.label_s3h1.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label_s3h1.Name = "label_s3h1";
            this.label_s3h1.Size = new System.Drawing.Size(94, 87);
            this.label_s3h1.TabIndex = 4;
            this.label_s3h1.Text = "21:00";
            this.label_s3h1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_s2h1
            // 
            this.lbl_s2h1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(43)))), ((int)(((byte)(87)))));
            this.lbl_s2h1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_s2h1.Font = new System.Drawing.Font("Segoe UI", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_s2h1.ForeColor = System.Drawing.Color.White;
            this.lbl_s2h1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_s2h1.Location = new System.Drawing.Point(437, 3);
            this.lbl_s2h1.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_s2h1.Name = "lbl_s2h1";
            this.lbl_s2h1.Size = new System.Drawing.Size(228, 87);
            this.lbl_s2h1.TabIndex = 3;
            this.lbl_s2h1.Text = "XXX";
            this.lbl_s2h1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_s2h1
            // 
            this.label_s2h1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(182)))), ((int)(((byte)(244)))));
            this.label_s2h1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_s2h1.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_s2h1.ForeColor = System.Drawing.Color.Black;
            this.label_s2h1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label_s2h1.Location = new System.Drawing.Point(337, 3);
            this.label_s2h1.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label_s2h1.Name = "label_s2h1";
            this.label_s2h1.Size = new System.Drawing.Size(94, 87);
            this.label_s2h1.TabIndex = 2;
            this.label_s2h1.Text = "13:00";
            this.label_s2h1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_s1h1
            // 
            this.lbl_s1h1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(43)))), ((int)(((byte)(87)))));
            this.lbl_s1h1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_s1h1.Font = new System.Drawing.Font("Segoe UI", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_s1h1.ForeColor = System.Drawing.Color.White;
            this.lbl_s1h1.Location = new System.Drawing.Point(103, 3);
            this.lbl_s1h1.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_s1h1.Name = "lbl_s1h1";
            this.lbl_s1h1.Size = new System.Drawing.Size(228, 87);
            this.lbl_s1h1.TabIndex = 1;
            this.lbl_s1h1.Text = "XXX";
            this.lbl_s1h1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_s1h1
            // 
            this.label_s1h1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(182)))), ((int)(((byte)(244)))));
            this.label_s1h1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_s1h1.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_s1h1.ForeColor = System.Drawing.Color.Black;
            this.label_s1h1.Location = new System.Drawing.Point(3, 3);
            this.label_s1h1.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label_s1h1.Name = "label_s1h1";
            this.label_s1h1.Size = new System.Drawing.Size(94, 87);
            this.label_s1h1.TabIndex = 0;
            this.label_s1h1.Text = "5:00";
            this.label_s1h1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.tableLayoutPanel4);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 807);
            this.panel3.Margin = new System.Windows.Forms.Padding(0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1003, 103);
            this.panel3.TabIndex = 2;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 6;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.001F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 23.33233F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.001F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 23.33233F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.001F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 23.33233F));
            this.tableLayoutPanel4.Controls.Add(this.label9, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.lbl_total_s1, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.label_total_s1, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.label_total_s3, 4, 0);
            this.tableLayoutPanel4.Controls.Add(this.lbl_total_s2, 3, 0);
            this.tableLayoutPanel4.Controls.Add(this.lbl_total_s3, 5, 0);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 1;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(1003, 103);
            this.tableLayoutPanel4.TabIndex = 0;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(120)))), ((int)(((byte)(102)))));
            this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label9.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label9.Location = new System.Drawing.Point(337, 3);
            this.label9.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(94, 100);
            this.label9.TabIndex = 8;
            this.label9.Text = "Total \r\nShift 2";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_total_s1
            // 
            this.lbl_total_s1.AutoSize = true;
            this.lbl_total_s1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(171)))), ((int)(((byte)(128)))));
            this.lbl_total_s1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_total_s1.Font = new System.Drawing.Font("Segoe UI", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_total_s1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_total_s1.Location = new System.Drawing.Point(103, 3);
            this.lbl_total_s1.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_total_s1.Name = "lbl_total_s1";
            this.lbl_total_s1.Size = new System.Drawing.Size(228, 100);
            this.lbl_total_s1.TabIndex = 7;
            this.lbl_total_s1.Text = "XXX";
            this.lbl_total_s1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_total_s1
            // 
            this.label_total_s1.AutoSize = true;
            this.label_total_s1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(120)))), ((int)(((byte)(102)))));
            this.label_total_s1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_total_s1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_total_s1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label_total_s1.Location = new System.Drawing.Point(3, 3);
            this.label_total_s1.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label_total_s1.Name = "label_total_s1";
            this.label_total_s1.Size = new System.Drawing.Size(94, 100);
            this.label_total_s1.TabIndex = 0;
            this.label_total_s1.Text = "Total \r\nShift 1";
            this.label_total_s1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_total_s3
            // 
            this.label_total_s3.AutoSize = true;
            this.label_total_s3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(120)))), ((int)(((byte)(102)))));
            this.label_total_s3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_total_s3.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_total_s3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label_total_s3.Location = new System.Drawing.Point(671, 3);
            this.label_total_s3.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label_total_s3.Name = "label_total_s3";
            this.label_total_s3.Size = new System.Drawing.Size(94, 100);
            this.label_total_s3.TabIndex = 2;
            this.label_total_s3.Text = "Total\r\nShift 3";
            this.label_total_s3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_total_s2
            // 
            this.lbl_total_s2.AutoSize = true;
            this.lbl_total_s2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(171)))), ((int)(((byte)(128)))));
            this.lbl_total_s2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_total_s2.Font = new System.Drawing.Font("Segoe UI", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_total_s2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_total_s2.Location = new System.Drawing.Point(437, 3);
            this.lbl_total_s2.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_total_s2.Name = "lbl_total_s2";
            this.lbl_total_s2.Size = new System.Drawing.Size(228, 100);
            this.lbl_total_s2.TabIndex = 9;
            this.lbl_total_s2.Text = "XXX";
            this.lbl_total_s2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_total_s3
            // 
            this.lbl_total_s3.AutoSize = true;
            this.lbl_total_s3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(92)))), ((int)(((byte)(171)))), ((int)(((byte)(128)))));
            this.lbl_total_s3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_total_s3.Font = new System.Drawing.Font("Segoe UI", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_total_s3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_total_s3.Location = new System.Drawing.Point(771, 3);
            this.lbl_total_s3.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.lbl_total_s3.Name = "lbl_total_s3";
            this.lbl_total_s3.Size = new System.Drawing.Size(229, 100);
            this.lbl_total_s3.TabIndex = 10;
            this.lbl_total_s3.Text = "XXX";
            this.lbl_total_s3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.tableLayoutPanel3);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(0, 910);
            this.panel4.Margin = new System.Windows.Forms.Padding(0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1003, 31);
            this.panel4.TabIndex = 3;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 3;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Controls.Add(this.label1, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.label3, 2, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(1003, 31);
            this.tableLayoutPanel3.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(337, 3);
            this.label1.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(328, 28);
            this.label1.TabIndex = 0;
            this.label1.Text = "AVG Takt Time";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(3, 3);
            this.label2.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(328, 28);
            this.label2.TabIndex = 1;
            this.label2.Text = "OEE";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Location = new System.Drawing.Point(671, 3);
            this.label3.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(329, 28);
            this.label3.TabIndex = 2;
            this.label3.Text = "Last Takt Time";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.tableLayoutPanel5);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(0, 941);
            this.panel5.Margin = new System.Windows.Forms.Padding(0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1003, 95);
            this.panel5.TabIndex = 4;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 3;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33133F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33433F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33433F));
            this.tableLayoutPanel5.Controls.Add(this.lbl_lasttakt, 2, 0);
            this.tableLayoutPanel5.Controls.Add(this.lbl_avg_takttime, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.lbl_oee, 0, 0);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 95F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(1003, 95);
            this.tableLayoutPanel5.TabIndex = 0;
            // 
            // lbl_lasttakt
            // 
            this.lbl_lasttakt.AutoSize = true;
            this.lbl_lasttakt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_lasttakt.Font = new System.Drawing.Font("Segoe UI", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_lasttakt.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_lasttakt.Location = new System.Drawing.Point(668, 0);
            this.lbl_lasttakt.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_lasttakt.Name = "lbl_lasttakt";
            this.lbl_lasttakt.Size = new System.Drawing.Size(335, 95);
            this.lbl_lasttakt.TabIndex = 2;
            this.lbl_lasttakt.Text = "XX.XX sec";
            this.lbl_lasttakt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_avg_takttime
            // 
            this.lbl_avg_takttime.AutoSize = true;
            this.lbl_avg_takttime.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_avg_takttime.Font = new System.Drawing.Font("Segoe UI", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_avg_takttime.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_avg_takttime.Location = new System.Drawing.Point(334, 0);
            this.lbl_avg_takttime.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_avg_takttime.Name = "lbl_avg_takttime";
            this.lbl_avg_takttime.Size = new System.Drawing.Size(334, 95);
            this.lbl_avg_takttime.TabIndex = 1;
            this.lbl_avg_takttime.Text = "XX.XX sec";
            this.lbl_avg_takttime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_oee
            // 
            this.lbl_oee.AutoSize = true;
            this.lbl_oee.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_oee.Font = new System.Drawing.Font("Segoe UI", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_oee.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_oee.Location = new System.Drawing.Point(0, 0);
            this.lbl_oee.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_oee.Name = "lbl_oee";
            this.lbl_oee.Size = new System.Drawing.Size(334, 95);
            this.lbl_oee.TabIndex = 0;
            this.lbl_oee.Text = "XX.XX";
            this.lbl_oee.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.tableLayoutPanel11);
            this.panel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel15.Location = new System.Drawing.Point(0, 51);
            this.panel15.Margin = new System.Windows.Forms.Padding(0);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(1003, 31);
            this.panel15.TabIndex = 10;
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.ColumnCount = 3;
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33178F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33411F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33411F));
            this.tableLayoutPanel11.Controls.Add(this.label88, 2, 0);
            this.tableLayoutPanel11.Controls.Add(this.label87, 0, 0);
            this.tableLayoutPanel11.Controls.Add(this.label86, 1, 0);
            this.tableLayoutPanel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel11.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 1;
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(1003, 31);
            this.tableLayoutPanel11.TabIndex = 0;
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label88.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label88.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label88.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label88.Location = new System.Drawing.Point(671, 0);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(329, 31);
            this.label88.TabIndex = 2;
            this.label88.Text = "Shift 3";
            this.label88.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label87.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label87.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label87.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label87.Location = new System.Drawing.Point(3, 0);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(328, 31);
            this.label87.TabIndex = 1;
            this.label87.Text = "Shift 1";
            this.label87.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label86.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label86.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label86.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label86.Location = new System.Drawing.Point(337, 0);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(328, 31);
            this.label86.TabIndex = 0;
            this.label86.Text = "Shift 2";
            this.label86.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel13
            // 
            this.tableLayoutPanel13.ColumnCount = 3;
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel13.Controls.Add(this.pb_heartbeat, 0, 0);
            this.tableLayoutPanel13.Controls.Add(this.label_tittle, 1, 0);
            this.tableLayoutPanel13.Controls.Add(this.lbl_date, 2, 0);
            this.tableLayoutPanel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel13.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel13.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel13.Name = "tableLayoutPanel13";
            this.tableLayoutPanel13.RowCount = 1;
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel13.Size = new System.Drawing.Size(1003, 51);
            this.tableLayoutPanel13.TabIndex = 16;
            // 
            // pb_heartbeat
            // 
            this.pb_heartbeat.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pb_heartbeat.Location = new System.Drawing.Point(62, 13);
            this.pb_heartbeat.Margin = new System.Windows.Forms.Padding(0);
            this.pb_heartbeat.Name = "pb_heartbeat";
            this.pb_heartbeat.Size = new System.Drawing.Size(25, 25);
            this.pb_heartbeat.TabIndex = 4;
            this.pb_heartbeat.TabStop = false;
            // 
            // label_tittle
            // 
            this.label_tittle.AutoSize = true;
            this.label_tittle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label_tittle.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_tittle.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label_tittle.Location = new System.Drawing.Point(153, 0);
            this.label_tittle.Name = "label_tittle";
            this.label_tittle.Size = new System.Drawing.Size(696, 51);
            this.label_tittle.TabIndex = 1;
            this.label_tittle.Text = "CONSOLE FLEX LINE ASSEMBLY";
            this.label_tittle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_date
            // 
            this.lbl_date.AutoSize = true;
            this.lbl_date.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_date.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_date.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_date.Location = new System.Drawing.Point(855, 0);
            this.lbl_date.Name = "lbl_date";
            this.lbl_date.Size = new System.Drawing.Size(145, 51);
            this.lbl_date.TabIndex = 2;
            this.lbl_date.Text = "label5";
            this.lbl_date.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tmr_update
            // 
            this.tmr_update.Interval = 500;
           
            // 
            // DataForm2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1003, 1036);
            this.Controls.Add(this.panel1);
            this.Name = "DataForm2";
            this.Text = "DataForm2";
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.tableLayoutPanel11.ResumeLayout(false);
            this.tableLayoutPanel11.PerformLayout();
            this.tableLayoutPanel13.ResumeLayout(false);
            this.tableLayoutPanel13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_heartbeat)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label lbl_s3h8;
        private System.Windows.Forms.Label label_s3h8;
        private System.Windows.Forms.Label lbl_s2h8;
        private System.Windows.Forms.Label label_s2h8;
        private System.Windows.Forms.Label lbl_s1h8;
        private System.Windows.Forms.Label label_s1h8;
        private System.Windows.Forms.Label lbl_s3h7;
        private System.Windows.Forms.Label label_s3h7;
        private System.Windows.Forms.Label lbl_s2h7;
        private System.Windows.Forms.Label label_s2h7;
        private System.Windows.Forms.Label lbl_s1h7;
        private System.Windows.Forms.Label label_s1h7;
        private System.Windows.Forms.Label lbl_s3h6;
        private System.Windows.Forms.Label label_s3h6;
        private System.Windows.Forms.Label lbl_s2h6;
        private System.Windows.Forms.Label label_s2h6;
        private System.Windows.Forms.Label lbl_s1h6;
        private System.Windows.Forms.Label label_s1h6;
        private System.Windows.Forms.Label lbl_s3h5;
        private System.Windows.Forms.Label label_s3h5;
        private System.Windows.Forms.Label lbl_s2h5;
        private System.Windows.Forms.Label label_s2h5;
        private System.Windows.Forms.Label lbl_s1h5;
        private System.Windows.Forms.Label label_s1h5;
        private System.Windows.Forms.Label lbl_s3h4;
        private System.Windows.Forms.Label label_s3h4;
        private System.Windows.Forms.Label lbl_s2h4;
        private System.Windows.Forms.Label label_s2h4;
        private System.Windows.Forms.Label lbl_s1h4;
        private System.Windows.Forms.Label label_s1h4;
        private System.Windows.Forms.Label lbl_s3h3;
        private System.Windows.Forms.Label label_s3h3;
        private System.Windows.Forms.Label lbl_s2h3;
        private System.Windows.Forms.Label label_s2h3;
        private System.Windows.Forms.Label lbl_s1h3;
        private System.Windows.Forms.Label label_s1h3;
        private System.Windows.Forms.Label lbl_s3h2;
        private System.Windows.Forms.Label label_s3h2;
        private System.Windows.Forms.Label lbl_s2h2;
        private System.Windows.Forms.Label label_s2h2;
        private System.Windows.Forms.Label lbl_s1h2;
        private System.Windows.Forms.Label label_s1h2;
        private System.Windows.Forms.Label lbl_s3h1;
        private System.Windows.Forms.Label label_s3h1;
        private System.Windows.Forms.Label lbl_s2h1;
        private System.Windows.Forms.Label label_s2h1;
        private System.Windows.Forms.Label lbl_s1h1;
        private System.Windows.Forms.Label label_s1h1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lbl_total_s1;
        private System.Windows.Forms.Label label_total_s1;
        private System.Windows.Forms.Label label_total_s3;
        private System.Windows.Forms.Label lbl_total_s2;
        private System.Windows.Forms.Label lbl_total_s3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Label lbl_lasttakt;
        private System.Windows.Forms.Label lbl_avg_takttime;
        private System.Windows.Forms.Label lbl_oee;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel11;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel13;
        private System.Windows.Forms.PictureBox pb_heartbeat;
        private System.Windows.Forms.Label label_tittle;
        private System.Windows.Forms.Label lbl_date;
        private System.Windows.Forms.Timer tmr_update;
    }
}