﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using PLK_IIOT_V2.Controllers;
using PLK_IIOT_V2.Models;

namespace PLK_IIOT_V2
{
    //public delegate void DataSendHandler(Model_PLC_1 data_in);

    public partial class DataForm3 : Form
    {

        public int label_hours, machineselected = 0;
        public int machinelimit = 0;
        public IOT_Tags_1 PLC = new IOT_Tags_1();
        NotepadController Notepad = new NotepadController();
        PLC_settings PLC1_Settings = new PLC_settings();
        public DataForm3()
        {
            InitializeComponent();
            //tmr_update.Start();

            //FormMain sent = new FormMain(PLC);
            //sent.DataSent += Datareceived;

            var temp1 = Notepad.Read_Notepad("PLC1_Settings");
            PLC1_Settings.PLC_enabled = temp1[0];
            PLC1_Settings.Machine_Name = temp1[1];
            PLC1_Settings.Machine_ID = temp1[2];
            PLC1_Settings.Ip_Address = temp1[3];
            PLC1_Settings.Server_enabled = temp1[4];
            PLC1_Settings.Servername = temp1[5];
            PLC1_Settings.Database = temp1[6];
            PLC1_Settings.Table = temp1[7];
            PLC1_Settings.only_server_mode = temp1[8];
            PLC1_Settings.webservermode = temp1[9];
            PLC1_Settings.PLCType = Convert.ToInt32(temp1[10]);

            picb_next.Visible = Convert.ToBoolean(Convert.ToInt32(PLC1_Settings.only_server_mode))==false?false:true;
            picb_prev.Visible = Convert.ToBoolean(Convert.ToInt32(PLC1_Settings.only_server_mode))==false?false:true;
        }
      
            
      
        public void Data_Refresh(IOT_Tags_1 data_in)
        {

            PLC = data_in;
            
            label_tittle.Text = Convert.ToBoolean(Convert.ToInt32(PLC1_Settings.only_server_mode)) == true ? PLC.Machine_Name: PLC1_Settings.Machine_Name;

            lbl_sequencestep.Text = PLC.Sequence_Step_msg;

            lbl_date.Text = PLC.PLC_Datetime[1].ToString("00") + "/" + PLC.PLC_Datetime[2].ToString("00") + "/" + PLC.PLC_Datetime[0].ToString("00") +"  "+ PLC.PLC_Datetime[3].ToString("00") + ":" + PLC.PLC_Datetime[4].ToString("00") + ":" + PLC.PLC_Datetime[5].ToString("00");

            //label_hours();
            hearbeat();



            lbl_total_s1.Text = PLC.Todays_Shifts[0].ToString();
            lbl_total_s2.Text = PLC.Todays_Shifts[1].ToString();
            lbl_total_s3.Text = PLC.Todays_Shifts[2].ToString();

            lbl_currentCT.Text = Decimal.Round(Convert.ToDecimal(PLC.Current_Takt_time_msec)/1000, 2).ToString() + " Sec.";
            lbl_avg_takttime.Text = Decimal.Round(Convert.ToDecimal(PLC.Avg_Takt_Time_msec) / 1000, 2).ToString() + " Sec.";
            lbl_lasttakt.Text = Decimal.Round(Convert.ToDecimal(PLC.Last_Takt_Time_msec) / 1000, 2).ToString() + " Sec.";

            if (PLC.SpareDINT[0] == 6)
            {
                label_hours = 1;
            }
            else
            {
                if (PLC.SpareDINT[0] == 5)
                {
                    label_hours = 0;
                }
            }
           
            if (label_hours == 0)
            {
                lbl_s1h1.Text = PLC.Hourly_Counter[5].ToString();
                lbl_s1h2.Text = PLC.Hourly_Counter[6].ToString();
                lbl_s1h3.Text = PLC.Hourly_Counter[7].ToString();
                lbl_s1h4.Text = PLC.Hourly_Counter[8].ToString();
                lbl_s1h5.Text = PLC.Hourly_Counter[9].ToString();
                lbl_s1h6.Text = PLC.Hourly_Counter[10].ToString();
                lbl_s1h7.Text = PLC.Hourly_Counter[11].ToString();
                lbl_s1h8.Text = PLC.Hourly_Counter[12].ToString();

                lbl_s2h1.Text = PLC.Hourly_Counter[13].ToString();
                lbl_s2h2.Text = PLC.Hourly_Counter[14].ToString();
                lbl_s2h3.Text = PLC.Hourly_Counter[15].ToString();
                lbl_s2h4.Text = PLC.Hourly_Counter[16].ToString();
                lbl_s2h5.Text = PLC.Hourly_Counter[17].ToString();
                lbl_s2h6.Text = PLC.Hourly_Counter[18].ToString();
                lbl_s2h7.Text = PLC.Hourly_Counter[19].ToString();
                lbl_s2h8.Text = PLC.Hourly_Counter[20].ToString();

                lbl_s3h1.Text = PLC.Hourly_Counter[21].ToString();
                lbl_s3h2.Text = PLC.Hourly_Counter[22].ToString();
                lbl_s3h3.Text = PLC.Hourly_Counter[23].ToString();
                lbl_s3h4.Text = PLC.Hourly_Counter[0].ToString();
                lbl_s3h5.Text = PLC.Hourly_Counter[1].ToString();
                lbl_s3h6.Text = PLC.Hourly_Counter[2].ToString();
                lbl_s3h7.Text = PLC.Hourly_Counter[3].ToString();
                lbl_s3h8.Text = PLC.Hourly_Counter[4].ToString();
            }
            else
            {
                if (label_hours == 1)
                {
                    label_hours_2();
                }
                    
            }
           

        }
        
        void label_hours_1()
        {
            label_s1h1.Text = "5:30\n6:30";
            label_s1h2.Text = "6:30\n7:30";
            label_s1h3.Text = "7:30\n8:30";
            label_s1h4.Text = "8:30\n9:30";
            label_s1h5.Text = "9:30\n10:30";
            label_s1h6.Text = "10:30\n11:30";
            label_s1h7.Text = "11:30\n12:30";
            label_s1h8.Text = "12:30\n1:30";

            label_s2h1.Text = "1:30\n2:30";
            label_s2h2.Text = "2:30\n3:30";
            label_s2h3.Text = "3:30\n4:30";
            label_s2h4.Text = "4:30\n5:30";
            label_s2h5.Text = "5:30\n6:30";
            label_s2h6.Text = "6:30\n7:30";
            label_s2h7.Text = "7:30\n8:30";
            label_s2h8.Text = "8:30\n9:30";

            label_s3h1.Text = "9:30\n10:30";
            label_s3h2.Text = "10:30\n11:30";
            label_s3h3.Text = "11:30\n12:30";
            label_s3h4.Text = "12:30\n1:30";
            label_s3h5.Text = "1:30\n2:30";
            label_s3h6.Text = "2:30\n3:30";
            label_s3h7.Text = "3:30\n4:30";
            label_s3h8.Text = "4:30\n5:30";


        }
         void label_hours_2()
        {

            label_s1h1.Text = "6:00\n7:00";
            label_s1h2.Text = "7:00\n8:00";
            label_s1h3.Text = "8:00\n9:00";
            label_s1h4.Text = "9:00\n10:00";
            label_s1h5.Text = "10:00\n11:00";
            label_s1h6.Text = "11:00\n12:00";
            label_s1h7.Text = "12:00\n1:00";
            label_s1h8.Text = "1:00\n2:00";



            label_s2h1.Text = "2:00\n3:00";
            label_s2h2.Text = "3:00\n4:00";
            label_s2h3.Text = "4:00\n5:00";
            label_s2h4.Text = "5:00\n6:00";
            label_s2h5.Text = "6:00\n7:00";
            label_s2h6.Text = "7:00\n8:00";
            label_s2h7.Text = "8:00\n9:00";
            label_s2h8.Text = "9:00\n10:00";

            label_s3h1.Text = "10:00\n11:00";
            label_s3h2.Text = "11:00\n12:00";
            label_s3h3.Text = "12:00\n1:00";
            label_s3h4.Text = "1:00\n2:00";
            label_s3h5.Text = "2:00\n3:00";
            label_s3h6.Text = "3:00\n4:00";
            label_s3h7.Text = "4:00\n5:00";
            label_s3h8.Text = "5:00\n6:00";

            lbl_s1h1.Text = PLC.Hourly_Counter[6].ToString();
            lbl_s1h2.Text = PLC.Hourly_Counter[7].ToString();
            lbl_s1h3.Text = PLC.Hourly_Counter[8].ToString();
            lbl_s1h4.Text = PLC.Hourly_Counter[9].ToString();
            lbl_s1h5.Text = PLC.Hourly_Counter[10].ToString();
            lbl_s1h6.Text = PLC.Hourly_Counter[11].ToString();
            lbl_s1h7.Text = PLC.Hourly_Counter[12].ToString();
            lbl_s1h8.Text = PLC.Hourly_Counter[13].ToString();

            lbl_s2h1.Text = PLC.Hourly_Counter[14].ToString();
            lbl_s2h2.Text = PLC.Hourly_Counter[15].ToString();
            lbl_s2h3.Text = PLC.Hourly_Counter[16].ToString();
            lbl_s2h4.Text = PLC.Hourly_Counter[17].ToString();
            lbl_s2h5.Text = PLC.Hourly_Counter[18].ToString();
            lbl_s2h6.Text = PLC.Hourly_Counter[19].ToString();
            lbl_s2h7.Text = PLC.Hourly_Counter[20].ToString();
            lbl_s2h8.Text = PLC.Hourly_Counter[21].ToString();

            lbl_s3h1.Text = PLC.Hourly_Counter[22].ToString();
            lbl_s3h2.Text = PLC.Hourly_Counter[23].ToString();
            lbl_s3h3.Text = PLC.Hourly_Counter[0].ToString();
            lbl_s3h4.Text = PLC.Hourly_Counter[1].ToString();
            lbl_s3h5.Text = PLC.Hourly_Counter[2].ToString();
            lbl_s3h6.Text = PLC.Hourly_Counter[3].ToString();
            lbl_s3h7.Text = PLC.Hourly_Counter[4].ToString();
            lbl_s3h8.Text = PLC.Hourly_Counter[5].ToString();

        }


        float OEE_calculate(float goodpartsshift, int idealCT)
        {
            float return_value = 0.0F;


            return_value = (float)Decimal.Round(Convert.ToDecimal(((goodpartsshift * (float)idealCT) / (float)(420 * 60)) * 100), 2);

            return return_value;
        }
        void hearbeat()
        {
            if (Convert.ToBoolean(PLC.Heartbeat) == true)
            {
                pb_heartbeat.BackColor = System.Drawing.Color.White;

            }
            else
            {
                pb_heartbeat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(43)))), ((int)(((byte)(87)))));


            }
        }

        private void lbl_s2h1_Click(object sender, EventArgs e)
        {

        }

        private void label_tittle_Click(object sender, EventArgs e)
        {

        }

        private void picb_prev_Click(object sender, EventArgs e)
        {
            machineselected--;
            if (machineselected < 0) machineselected = machinelimit;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            
            machineselected++;
            if (machineselected > machinelimit) machineselected = 0;

        }
    }
}
