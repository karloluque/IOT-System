﻿using ScottPlot;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PLK_IIOT_V2
{
    public partial class Form1 : Form
    {
        string[] yLabels;
        int Hr = Convert.ToInt32(DateTime.Now.ToString("HH"));
        int minutes = Convert.ToInt32(DateTime.Now.ToString("mm"));
        int seconds = Convert.ToInt32(DateTime.Now.ToString("ss"));
        int Day = Convert.ToInt32(DateTime.Now.ToString("dd"));
        int Month = Convert.ToInt32(DateTime.Now.ToString("MM"));
        int Year = Convert.ToInt32(DateTime.Now.ToString("yyyy"));
        DateTime start;
       
        public Form1()
        {
            InitializeComponent();
            timer1.Start();
          
          

        }
        //List<double> DataX_in, List<double> DataY_in
        

        private void timer1_Tick(object sender, EventArgs e)
        {
            Hr = Convert.ToInt32(DateTime.Now.ToString("HH"));
            minutes = Convert.ToInt32(DateTime.Now.ToString("mm"));
            seconds = Convert.ToInt32(DateTime.Now.ToString("ss"));
            Day = Convert.ToInt32(DateTime.Now.ToString("dd"));
            Month = Convert.ToInt32(DateTime.Now.ToString("MM"));
            Year = Convert.ToInt32(DateTime.Now.ToString("yyyy"));
            //plot1_refresh();



        }

        
    }
}
