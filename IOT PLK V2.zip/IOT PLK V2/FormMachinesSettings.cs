﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PLK_IIOT_V2
{
    public partial class FormMachinesSettings : Form
    {
        public FormMachinesSettings()
        {
            InitializeComponent();
        }
    }
}
