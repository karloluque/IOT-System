﻿
namespace PLK_IIOT_V2
{

    partial class FormMain
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.pnl_Center = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.solidGauge5 = new LiveCharts.WinForms.SolidGauge();
            this.picbx_logo = new System.Windows.Forms.PictureBox();
            this.lbl_shift_record = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lbl_solidGauge1 = new System.Windows.Forms.Label();
            this.lbl_solidGauge2 = new System.Windows.Forms.Label();
            this.lbl_solidGauge3 = new System.Windows.Forms.Label();
            this.lbl_solidGauge4 = new System.Windows.Forms.Label();
            this.lbl_solidGauge5 = new System.Windows.Forms.Label();
            this.pnl_PLC2 = new System.Windows.Forms.Panel();
            this.pnl_PLC1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_validate_data1 = new System.Windows.Forms.Button();
            this.tmr_update = new System.Windows.Forms.Timer(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.MItem_File = new System.Windows.Forms.ToolStripMenuItem();
            this.MItem_Edit = new System.Windows.Forms.ToolStripMenuItem();
            this.Edit_Send_Report = new System.Windows.Forms.ToolStripMenuItem();
            this.TSEditSendCurrent = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1_edit_emails = new System.Windows.Forms.ToolStripMenuItem();
            this.Mitem_Setup = new System.Windows.Forms.ToolStripMenuItem();
            this.Setup_PLC1 = new System.Windows.Forms.ToolStripMenuItem();
            this.Setup_PLC2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip_MachinesInfo = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.status_label_plc = new System.Windows.Forms.ToolStripStatusLabel();
            this.status_label_errorapp = new System.Windows.Forms.ToolStripStatusLabel();
            this.status_plc_alarm_msg = new System.Windows.Forms.ToolStripStatusLabel();
            this.status_msg_app = new System.Windows.Forms.ToolStripStatusLabel();
            this.tableLayoutPanel1.SuspendLayout();
            this.pnl_Center.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_logo)).BeginInit();
            this.pnl_PLC1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(43)))), ((int)(((byte)(87)))));
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 45F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 38F));
            this.tableLayoutPanel1.Controls.Add(this.pnl_Center, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.pnl_PLC2, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.pnl_PLC1, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1904, 1041);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // pnl_Center
            // 
            this.pnl_Center.Controls.Add(this.tableLayoutPanel2);
            this.pnl_Center.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_Center.Location = new System.Drawing.Point(856, 0);
            this.pnl_Center.Margin = new System.Windows.Forms.Padding(0);
            this.pnl_Center.Name = "pnl_Center";
            this.pnl_Center.Size = new System.Drawing.Size(323, 1041);
            this.pnl_Center.TabIndex = 9;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.solidGauge5, 0, 10);
            this.tableLayoutPanel2.Controls.Add(this.picbx_logo, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.lbl_shift_record, 0, 12);
            this.tableLayoutPanel2.Controls.Add(this.label4, 0, 11);
            this.tableLayoutPanel2.Controls.Add(this.lbl_solidGauge1, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.lbl_solidGauge2, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.lbl_solidGauge3, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.lbl_solidGauge4, 0, 7);
            this.tableLayoutPanel2.Controls.Add(this.lbl_solidGauge5, 0, 9);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 13;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.25F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 3.5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 13.5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 3.5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 13.5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 3.5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 13.5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 3.5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 13.5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 3.5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 13.5F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 3.25F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.5F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(323, 1041);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // solidGauge5
            // 
            this.solidGauge5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.solidGauge5.Location = new System.Drawing.Point(0, 794);
            this.solidGauge5.Margin = new System.Windows.Forms.Padding(0);
            this.solidGauge5.Name = "solidGauge5";
            this.solidGauge5.Size = new System.Drawing.Size(323, 140);
            this.solidGauge5.TabIndex = 28;
            this.solidGauge5.Text = "solidGauge1";
            // 
            // picbx_logo
            // 
            this.picbx_logo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.picbx_logo.Image = ((System.Drawing.Image)(resources.GetObject("picbx_logo.Image")));
            this.picbx_logo.Location = new System.Drawing.Point(3, 3);
            this.picbx_logo.Name = "picbx_logo";
            this.picbx_logo.Size = new System.Drawing.Size(317, 48);
            this.picbx_logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picbx_logo.TabIndex = 23;
            this.picbx_logo.TabStop = false;
            this.picbx_logo.Click += new System.EventHandler(this.picbx_logo_Click);
            // 
            // lbl_shift_record
            // 
            this.lbl_shift_record.AutoSize = true;
            this.lbl_shift_record.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(43)))), ((int)(((byte)(87)))));
            this.lbl_shift_record.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_shift_record.Font = new System.Drawing.Font("Segoe UI", 50.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_shift_record.ForeColor = System.Drawing.Color.Gold;
            this.lbl_shift_record.Location = new System.Drawing.Point(0, 967);
            this.lbl_shift_record.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_shift_record.Name = "lbl_shift_record";
            this.lbl_shift_record.Size = new System.Drawing.Size(323, 74);
            this.lbl_shift_record.TabIndex = 22;
            this.lbl_shift_record.Text = "XXX";
            this.lbl_shift_record.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Gold;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label4.Location = new System.Drawing.Point(4, 938);
            this.label4.Margin = new System.Windows.Forms.Padding(4);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(315, 25);
            this.label4.TabIndex = 21;
            this.label4.Text = "★LINE RECORD ★";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_solidGauge1
            // 
            this.lbl_solidGauge1.AutoSize = true;
            this.lbl_solidGauge1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_solidGauge1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_solidGauge1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_solidGauge1.Location = new System.Drawing.Point(3, 54);
            this.lbl_solidGauge1.Name = "lbl_solidGauge1";
            this.lbl_solidGauge1.Size = new System.Drawing.Size(317, 36);
            this.lbl_solidGauge1.TabIndex = 29;
            this.lbl_solidGauge1.Text = "label1";
            this.lbl_solidGauge1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_solidGauge2
            // 
            this.lbl_solidGauge2.AutoSize = true;
            this.lbl_solidGauge2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_solidGauge2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_solidGauge2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_solidGauge2.Location = new System.Drawing.Point(3, 230);
            this.lbl_solidGauge2.Name = "lbl_solidGauge2";
            this.lbl_solidGauge2.Size = new System.Drawing.Size(317, 36);
            this.lbl_solidGauge2.TabIndex = 30;
            this.lbl_solidGauge2.Text = "label1";
            this.lbl_solidGauge2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_solidGauge3
            // 
            this.lbl_solidGauge3.AutoSize = true;
            this.lbl_solidGauge3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_solidGauge3.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_solidGauge3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_solidGauge3.Location = new System.Drawing.Point(3, 406);
            this.lbl_solidGauge3.Name = "lbl_solidGauge3";
            this.lbl_solidGauge3.Size = new System.Drawing.Size(317, 36);
            this.lbl_solidGauge3.TabIndex = 31;
            this.lbl_solidGauge3.Text = "label2";
            this.lbl_solidGauge3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_solidGauge4
            // 
            this.lbl_solidGauge4.AutoSize = true;
            this.lbl_solidGauge4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_solidGauge4.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_solidGauge4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_solidGauge4.Location = new System.Drawing.Point(3, 582);
            this.lbl_solidGauge4.Name = "lbl_solidGauge4";
            this.lbl_solidGauge4.Size = new System.Drawing.Size(317, 36);
            this.lbl_solidGauge4.TabIndex = 32;
            this.lbl_solidGauge4.Text = "label3";
            this.lbl_solidGauge4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_solidGauge5
            // 
            this.lbl_solidGauge5.AutoSize = true;
            this.lbl_solidGauge5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_solidGauge5.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_solidGauge5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_solidGauge5.Location = new System.Drawing.Point(3, 758);
            this.lbl_solidGauge5.Name = "lbl_solidGauge5";
            this.lbl_solidGauge5.Size = new System.Drawing.Size(317, 36);
            this.lbl_solidGauge5.TabIndex = 33;
            this.lbl_solidGauge5.Text = "label5";
            this.lbl_solidGauge5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnl_PLC2
            // 
            this.pnl_PLC2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_PLC2.Location = new System.Drawing.Point(1179, 0);
            this.pnl_PLC2.Margin = new System.Windows.Forms.Padding(0);
            this.pnl_PLC2.Name = "pnl_PLC2";
            this.pnl_PLC2.Size = new System.Drawing.Size(725, 1041);
            this.pnl_PLC2.TabIndex = 22;
            // 
            // pnl_PLC1
            // 
            this.pnl_PLC1.Controls.Add(this.label1);
            this.pnl_PLC1.Controls.Add(this.btn_validate_data1);
            this.pnl_PLC1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_PLC1.Location = new System.Drawing.Point(0, 0);
            this.pnl_PLC1.Margin = new System.Windows.Forms.Padding(0);
            this.pnl_PLC1.Name = "pnl_PLC1";
            this.pnl_PLC1.Size = new System.Drawing.Size(856, 1041);
            this.pnl_PLC1.TabIndex = 23;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(324, 1022);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "label1";
            // 
            // btn_validate_data1
            // 
            this.btn_validate_data1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_validate_data1.Location = new System.Drawing.Point(231, 369);
            this.btn_validate_data1.Name = "btn_validate_data1";
            this.btn_validate_data1.Size = new System.Drawing.Size(329, 135);
            this.btn_validate_data1.TabIndex = 0;
            this.btn_validate_data1.Text = "PLC data no valid or no exist\r\n(Press to Validate)";
            this.btn_validate_data1.UseVisualStyleBackColor = true;
            this.btn_validate_data1.Click += new System.EventHandler(this.btn_validate_data_Click);
            // 
            // tmr_update
            // 
            this.tmr_update.Interval = 250;
            this.tmr_update.Tick += new System.EventHandler(this.tmr_update_Tick);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MItem_File,
            this.MItem_Edit,
            this.Mitem_Setup});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1904, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "File";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // MItem_File
            // 
            this.MItem_File.Name = "MItem_File";
            this.MItem_File.Size = new System.Drawing.Size(37, 20);
            this.MItem_File.Text = "File";
            // 
            // MItem_Edit
            // 
            this.MItem_Edit.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Edit_Send_Report,
            this.TSEditSendCurrent,
            this.toolStripMenuItem1_edit_emails});
            this.MItem_Edit.Name = "MItem_Edit";
            this.MItem_Edit.Size = new System.Drawing.Size(39, 20);
            this.MItem_Edit.Text = "Edit";
            // 
            // Edit_Send_Report
            // 
            this.Edit_Send_Report.Name = "Edit_Send_Report";
            this.Edit_Send_Report.Size = new System.Drawing.Size(193, 22);
            this.Edit_Send_Report.Text = "Send Complete Report";
            this.Edit_Send_Report.Click += new System.EventHandler(this.Edit_Send_Report_Click);
            // 
            // TSEditSendCurrent
            // 
            this.TSEditSendCurrent.Name = "TSEditSendCurrent";
            this.TSEditSendCurrent.Size = new System.Drawing.Size(193, 22);
            this.TSEditSendCurrent.Text = "Send Current Screen";
            this.TSEditSendCurrent.Click += new System.EventHandler(this.TSEditSendCurrent_Click);
            // 
            // toolStripMenuItem1_edit_emails
            // 
            this.toolStripMenuItem1_edit_emails.Name = "toolStripMenuItem1_edit_emails";
            this.toolStripMenuItem1_edit_emails.Size = new System.Drawing.Size(193, 22);
            this.toolStripMenuItem1_edit_emails.Text = "Edit emails";
            this.toolStripMenuItem1_edit_emails.Click += new System.EventHandler(this.toolStripMenuItem1_edit_emails_Click);
            // 
            // Mitem_Setup
            // 
            this.Mitem_Setup.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Setup_PLC1,
            this.Setup_PLC2,
            this.toolStrip_MachinesInfo});
            this.Mitem_Setup.Name = "Mitem_Setup";
            this.Mitem_Setup.Size = new System.Drawing.Size(49, 20);
            this.Mitem_Setup.Text = "Setup";
            // 
            // Setup_PLC1
            // 
            this.Setup_PLC1.Name = "Setup_PLC1";
            this.Setup_PLC1.Size = new System.Drawing.Size(149, 22);
            this.Setup_PLC1.Text = "Setup PLC 1";
            this.Setup_PLC1.Click += new System.EventHandler(this.Setup_PLC1_Click);
            // 
            // Setup_PLC2
            // 
            this.Setup_PLC2.Name = "Setup_PLC2";
            this.Setup_PLC2.Size = new System.Drawing.Size(149, 22);
            this.Setup_PLC2.Text = "Setup PLC 2";
            // 
            // toolStrip_MachinesInfo
            // 
            this.toolStrip_MachinesInfo.Name = "toolStrip_MachinesInfo";
            this.toolStrip_MachinesInfo.Size = new System.Drawing.Size(149, 22);
            this.toolStrip_MachinesInfo.Text = "Machines Info";
            this.toolStrip_MachinesInfo.Click += new System.EventHandler(this.toolStrip_MachinesInfo_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.status_label_plc,
            this.status_label_errorapp,
            this.status_plc_alarm_msg,
            this.status_msg_app});
            this.statusStrip1.Location = new System.Drawing.Point(0, 1019);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1904, 22);
            this.statusStrip1.TabIndex = 3;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // status_label_plc
            // 
            this.status_label_plc.BackColor = System.Drawing.SystemColors.ControlLight;
            this.status_label_plc.ForeColor = System.Drawing.SystemColors.ControlText;
            this.status_label_plc.Name = "status_label_plc";
            this.status_label_plc.Size = new System.Drawing.Size(92, 17);
            this.status_label_plc.Text = "PLC: Connected";
            // 
            // status_label_errorapp
            // 
            this.status_label_errorapp.ForeColor = System.Drawing.Color.Red;
            this.status_label_errorapp.Name = "status_label_errorapp";
            this.status_label_errorapp.Size = new System.Drawing.Size(118, 17);
            this.status_label_errorapp.Text = "Application: No error";
            this.status_label_errorapp.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // status_plc_alarm_msg
            // 
            this.status_plc_alarm_msg.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.status_plc_alarm_msg.ForeColor = System.Drawing.Color.Yellow;
            this.status_plc_alarm_msg.Name = "status_plc_alarm_msg";
            this.status_plc_alarm_msg.Size = new System.Drawing.Size(115, 17);
            this.status_plc_alarm_msg.Text = "PLC Alarm message:";
            // 
            // status_msg_app
            // 
            this.status_msg_app.ActiveLinkColor = System.Drawing.Color.PowderBlue;
            this.status_msg_app.ForeColor = System.Drawing.Color.MediumBlue;
            this.status_msg_app.Name = "status_msg_app";
            this.status_msg_app.Size = new System.Drawing.Size(59, 17);
            this.status_msg_app.Text = "Message: ";
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(43)))), ((int)(((byte)(87)))));
            this.ClientSize = new System.Drawing.Size(1904, 1041);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormMain";
            this.Text = "PLK_IIOT_Template";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormMain_FormClosing);
            this.Load += new System.EventHandler(this.FormMain_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.pnl_Center.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbx_logo)).EndInit();
            this.pnl_PLC1.ResumeLayout(false);
            this.pnl_PLC1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Timer tmr_update;
        private System.Windows.Forms.Panel pnl_Center;
        private System.Windows.Forms.Panel pnl_PLC2;
        private System.Windows.Forms.Panel pnl_PLC1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private LiveCharts.WinForms.SolidGauge solidGauge5;
        private System.Windows.Forms.PictureBox picbx_logo;
        private System.Windows.Forms.Label lbl_shift_record;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbl_solidGauge1;
        private System.Windows.Forms.Label lbl_solidGauge2;
        private System.Windows.Forms.Label lbl_solidGauge3;
        private System.Windows.Forms.Label lbl_solidGauge4;
        private System.Windows.Forms.Label lbl_solidGauge5;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem File;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem Setup_PLC1;
        private System.Windows.Forms.ToolStripMenuItem Setup_PLC2;
        private System.Windows.Forms.ToolStripMenuItem MItem_File;
        private System.Windows.Forms.ToolStripMenuItem MItem_Edit;
        private System.Windows.Forms.ToolStripMenuItem Mitem_Setup;
        private System.Windows.Forms.Button btn_validate_data1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ToolStripMenuItem Edit_Send_Report;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1_edit_emails;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripStatusLabel status_label_plc;
        private System.Windows.Forms.ToolStripStatusLabel status_label_errorapp;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel status_plc_alarm_msg;
        private System.Windows.Forms.ToolStripMenuItem TSEditSendCurrent;
        private System.Windows.Forms.ToolStripStatusLabel status_msg_app;
        private System.Windows.Forms.ToolStripMenuItem toolStrip_MachinesInfo;
    }
}

