﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using PLK_IIOT_V2.Models;
using PLK_IIOT_V2.Controllers;
using Color = System.Windows.Media.Color;
using LiveCharts.Wpf;
using System.Windows.Media;
using System.Drawing.Imaging;
using System.Net.Mail;
using System.Net.Mime;
using System.IO;
using PLK_IIOT_V2;
using System.Net;
using System.Net.NetworkInformation;
using System.Threading;
using System.Threading.Tasks;

namespace PLK_IIOT_V2
{
    //public delegate void DataSendHandler(Model_PLC_1 data_in);
    public partial class FormMain : Form
    {
        //public event DataSendHandler DataSent;

        public delegate void SendDataToChildForm1(IOT_Tags_1 Datain);
        public SendDataToChildForm1 SetPLCData1;

        public delegate void SendDataToChildForm2(IOT_Tags_1 Datain);
        public SendDataToChildForm2 SetPLCData2;

        public delegate void SendDataToChildForm3(IOT_Tags_1 Datain);
        public SendDataToChildForm3 SetPLCData3;

        public delegate void SendDataToChildForm4(IOT_Tags_1 Datain);
        public SendDataToChildForm4 SetPLCData4;

        public delegate void SendDataToChildForm5(IOT_Tags_1 Datain);
        public SendDataToChildForm5 SetPLCData5;

        public delegate void SendDataGraph1(List<double> Graphic1_series_Y, List<double> Graphic1_series_X);
        public SendDataGraph1 SetDataGraph1;


        public delegate void SendDataGraph2(List<double> Graphic2_series_Y, List<double> Graphic2_series_X);
        public SendDataGraph2 SetDataGraph2;

        public delegate void SendDataGraph3(List<double> Graphic3_series_Y, List<double> Graphic33_series_X);
        public SendDataGraph3 SetDataGraph3;
        string Domain = Environment.UserDomainName;
        string HostName = Dns.GetHostName();
        int sendreport = 0,cyclefromsending;
        String Hour = DateTime.Now.ToString("HH");
        string Minutes = DateTime.Now.ToString("mm");
        string Seconds = DateTime.Now.ToString("ss");
        String DateHHMM = DateTime.Now.ToString("H:mm");
        String DateDDMMYY = DateTime.Now.ToString("MM/dd/yy");
        //Graphics1_Data PLC = new Graphics1_Data();

     
        bool cn=false;
        public DataForm1 ChildForm1 = new DataForm1();
        public DataForm2 ChildForm2 = new DataForm2();
        public Graphics1 ChildForm3 = new Graphics1();
        public DataForm3 ChildForm4 = new DataForm3();
        public Center_Data_1 ChildForm5 = new Center_Data_1();
        

        List<double> Graphic1_series_Y = new List<double>();
        List<double> Graphic1_series_X = new List<double>();

        List<double> Graphic2_series_Y = new List<double>();
        List<double> Graphic2_series_X = new List<double>();

        List<double> Graphic3_series_Y = new List<double>();
        List<double> Graphic3_series_X = new List<double>();
        int total;
        int plchour, plcmin, plcsec, machineselected = 0, databaseconnection = 0, stepemailing = 0, hrsave = 0, minsave = 0, hrsave2 = 0, minsave2 = 0, messagebox1 = 0, msg2mem;
      
        bool connectiondone=false,timesaved=false, readytosave;
        EmailController e_mail = new EmailController();
        NotepadController Notepad = new NotepadController();
        PLC_settings PLC1_Settings = new PLC_settings();
        PLC_settings PLC2_Settings = new PLC_settings();

        DialogResult result;
        bool connectiondone1=false;

        AB_PLCController PLC1;//MainLine PLC1
        FX5_PLCController PLCFX5;//MainLine PLC1
        bool[] savedone;
        int cycle;
        IPAddress PLC1_ip;

       DBController dBController = new DBController();

        List<String> emails = new List<string>();
        string CurrentDirectory = Environment.CurrentDirectory,teststring;
        DB_IOT_Tags_Model_1 DB_IOT_Tags_1 = new DB_IOT_Tags_Model_1();
       
        IOT_Tags_1 PLC = new IOT_Tags_1();

        DialogResult resok;
        MessageBoxButtons button = MessageBoxButtons.OK;

        List<IOT_Tags_1> Machines = new List<IOT_Tags_1>();
        List<IOT_Tags_1>[] Machines_historial = new List<IOT_Tags_1>[10];
        List<PLC_settings> PLCsSettings = new List<PLC_settings>();
        public FormMain()
        {
            InitializeComponent();
            menuStrip1.Visible = false;

            Machines_historial[0] = new List<IOT_Tags_1>();
            Machines_historial[1] = new List<IOT_Tags_1>();
            Machines_historial[2] = new List<IOT_Tags_1>();
            Machines_historial[3] = new List<IOT_Tags_1>();
            Machines_historial[4] = new List<IOT_Tags_1>();
            Machines_historial[5] = new List<IOT_Tags_1>();
            Machines_historial[6] = new List<IOT_Tags_1>();
         
            var temp1 = Notepad.Read_Notepad("PLC1_Settings");
            PLC1_Settings.PLC_enabled = temp1[0];
            PLC1_Settings.Machine_Name = temp1[1];
            PLC1_Settings.Machine_ID = temp1[2];
            PLC1_Settings.Ip_Address = temp1[3];
            PLC1_Settings.Server_enabled = temp1[4];
            PLC1_Settings.Servername = temp1[5];
            PLC1_Settings.Database = temp1[6];
            PLC1_Settings.Table = temp1[7];
            PLC1_Settings.only_server_mode = temp1[8];
            PLC1_Settings.webservermode = temp1[9];
            PLC1_Settings.PLCType = Convert.ToInt32(temp1[10]);

            var temp2 = Notepad.Read_Notepad("PLC2_Settings");
            PLC2_Settings.PLC_enabled = temp2[0];
            PLC2_Settings.Machine_Name = temp2[1];
            PLC2_Settings.Machine_ID = temp2[2];
            PLC2_Settings.Ip_Address = temp2[3];
            PLC2_Settings.Server_enabled = temp2[4];
            PLC2_Settings.Servername = temp2[5];
            PLC2_Settings.Database = temp2[6];
            PLC2_Settings.Table = temp2[7];
            PLC2_Settings.only_server_mode = temp2[8];
            PLC2_Settings.webservermode = temp2[9];
            PLC2_Settings.PLCType = Convert.ToInt32(temp2[10]);

            dBController.PLC1_Settings = PLC1_Settings;
            dBController.PLC2_Settings = PLC2_Settings;

            e_mail.PLC1_Settings = PLC1_Settings;
            e_mail.PLC2_Settings = PLC2_Settings;

            Notepad.PLC1_Settings = PLC1_Settings;
            Notepad.PLC2_Settings = PLC2_Settings;



           

            //if (PLC1_Settings.PLC_enabled == "1" && ipaddress_validation(PLC1_Settings.Ip_Address))
            if (PLC1_Settings.PLC_enabled == "1" )
            {
                switch(PLC1_Settings.PLCType)
                {
                   
                    case 1:
                        PLC1 = new AB_PLCController(PLC1_Settings.PLC_enabled, PLC1_Settings.Ip_Address, "1,0", "IOT_Tags_1", "IOT_Tags_1", 1);//MainLine PLC1
                        PLC1.PLC1_Settings = PLC1_Settings;
                        PLC1.PLC2_Settings = PLC2_Settings;
                        break;
                    case 2:
                        PLCFX5 = new FX5_PLCController(PLC1_Settings.PLC_enabled, PLC1_Settings.Ip_Address, "1,0", "IOT_Tags_1", "IOT_Tags_1", 1);//MainLine PLC1
                        PLCFX5.PLC1_Settings = PLC1_Settings;
                        PLCFX5.PLC2_Settings = PLC2_Settings;
                        break;


                }



                
                Open_Graphics_PLC1();//graphics
                Open_DataForm_PLC5();//cneterdata
                Open_DataForm_PLC4();//data plc 1 v2
               
            }
            else
            {
                Open_Graphics_PLC1();//graphics
                Open_DataForm_PLC5();//cneterdata
                Open_DataForm_PLC4();//data plc 2 v2
       
                   
                
            }

            

            tmr_update.Interval = Convert.ToBoolean(Convert.ToInt32(PLC1_Settings.only_server_mode)) == true ? 1000 : 500;
            tmr_update.Start();
                    
           


           
        }

       

        private void tmr_update_Tick(object sender, EventArgs e)
        {

            
          
            //plastikon image button
            if (ChildForm5.changesmachine > 0)
            {             
            }
          if (PLC1_Settings.only_server_mode == "1")
            {
                if (PLC1_Settings.webservermode == "1")
                {
                    if (dBController.CheckWebServerConnection() == true)
                    {
                        Machines = dBController.select_IOTTags1_table();


                        ChildForm4.machinelimit = Machines.Count - 1;
                        machineselected = ChildForm4.machineselected;


                        PLC = Convert.ToBoolean(Convert.ToInt32(PLC1_Settings.Server_enabled)) == true ? Machines[machineselected] : PLC = null;

                    }
                    else
                    {
                      
                        if (msg2mem == 0)
                        {
                            msg2mem = 1;
                            resok= MessageBox.Show("No connection to Web Server", "Check internet connection or check setting", button);
                           
                        }
                        else
                        {
                            if (resok == DialogResult.OK)
                            {

                                Form_PLC_Setup myNewForm = new Form_PLC_Setup(1);
                                myNewForm.Visible = true;
                                myNewForm.TopMost = true;
                                myNewForm.StartPosition = FormStartPosition.CenterScreen;
                                DialogResult novalid= new DialogResult();
                                resok = novalid;
                            }
                        }
                       
                    }
                }
                else
                {
                    if (cn = dBController.CheckLocalServerConnection() && dBController.forcewebserver == false && (result != DialogResult.Yes))
                    {
                        Machines = dBController.select_IOTTags1_table();

                  
                       

                        ChildForm4.machinelimit = Machines.Count - 1;
                        machineselected = ChildForm4.machineselected;

                        if (connectiondone1 == false) savedone = new bool[Machines.Count];
                        connectiondone1 = true;
                        PLC = Convert.ToBoolean(Convert.ToInt32(PLC1_Settings.Server_enabled)) == true ? Machines[machineselected] : PLC = null;

                        if (HostName == "DT-CA-00105")
                        {
                            
                            for (int i = 0; i < Machines.Count; i++)
                            {
                                updateDB_webserver(Machines[i], (i + 1));

                            }

                        }
                    }
                    else
                    {


                        MessageBoxButtons buttons = MessageBoxButtons.YesNo;


                        if (messagebox1 == 0)
                        {
                            messagebox1 = 1;
                            result = MessageBox.Show("Database Server Not Connection,\n Do you want to activate Web Server", $"Not Connection to {PLC1_Settings.Servername}", buttons);

                        }


                        if (result == DialogResult.Yes)
                        {

                            dBController.forcewebserver = true;

                            if (dBController.CheckWebServerConnection() == true)
                            {
                                Machines = dBController.select_IOTTags1_table();


                                ChildForm4.machinelimit = Machines.Count - 1;
                                machineselected = ChildForm4.machineselected;


                                PLC = Convert.ToBoolean(Convert.ToInt32(PLC1_Settings.Server_enabled)) == true ? Machines[machineselected] : PLC = null;

                            }
                            

                        }
                       
                    }
                }
               


                



            }
            
            else
            {

                //send data to server
                switch (PLC1_Settings.PLCType)
                {
                    case 1:
                        PLC = Convert.ToBoolean(Convert.ToInt32(PLC1_Settings.PLC_enabled)) == true ? PLC1.Datareaded_out : null;
                        break;
                    case 2:
                        PLC = Convert.ToBoolean(Convert.ToInt32(PLC1_Settings.PLC_enabled)) == true ? PLCFX5.Datareaded_out : null;
                        break;
                    default:
                        PLC = null;
                        break;
                }
                 if ( PLC != null) if(PLC.Heartbeat == 1 ) connectiondone = true;


                if (connectiondone==true)
                {
                    var res = Convert.ToBoolean((Convert.ToInt32(PLC1_Settings.Server_enabled))) == true && (Convert.ToBoolean(Convert.ToInt32(PLC1_Settings.PLC_enabled))) == true ? updateDB(PLC) : updateDB(null);
                    
                    
                
                }
              
            }

            

            //plc data send to other forms
            if (PLC != null)
            {
                
                SetPLCData3(PLC);
                SetPLCData4(PLC);
                SetPLCData5(PLC);

                plchour = PLC.PLC_Datetime[3];
                plcmin = PLC.PLC_Datetime[4];
                plcsec = PLC.PLC_Datetime[5];
                reporting();

                if ((HostName == "LT-CA-00175" || HostName == "DT-CA-00105") && PLC1_Settings.only_server_mode == "1")
                {
                    //savehistorial();
                    var pp = Machines_historial;
                    //status_msg_app.Text = $"true logic {HostName}";



                }


            }
            //status bar

            //status_label_errorapp.Text = $" SQL {PLC1_Settings.Ip_Address}: " + (PLC1.pinging_ip1 == true ? $" Connected" : $" No Connected");

            #region //datetime
            Seconds = DateTime.Now.ToString("ss");
            Hour = DateTime.Now.ToString("HH");
            Minutes = DateTime.Now.ToString("mm");
            DateHHMM = DateTime.Now.ToString("H:mm");
            DateDDMMYY = DateTime.Now.ToString("MM/dd/yy");


            #endregion
            if (sendreport == 1)
            {
                menuStrip1.Visible = false;
                statusStrip1.Visible = false;
                sendreport = 2;
                cyclefromsending = cycle < 57 ? (cycle + 3) : ((cycle + 3) - 60);
            }
            if (sendreport == 2 && cyclefromsending==cycle)
            {
                shift_production_report();
                sendreport = 0;
              
            }
            cycle = cycle > 60 ? 0 : cycle + 1;
        }

        private void savehistorial()
        {

            int hour = 8;
            int min = 41;
            int sec = 57;
            for (int i = 0; i < Machines.Count; i++)
            {

               // hour = i >= 2 ? 20 : 21;
                if ((Machines[i].PLC_Datetime[3] == hour) && (Machines[i].PLC_Datetime[4] == min) && (Machines[i].PLC_Datetime[5] > sec && (savedone[i] == false)))
                {
                    Machines_historial[i].Add(Machines[i]);
                    savedone[i] = true;
                    MessageBox.Show("savedone"+savedone[i], "savedone" + savedone[i]+" i:"+i);
                }

                if (total <= Machines.Count)
                {
                    if (savedone[i] == true && total < Machines.Count) total++;
                    else total = 0;
                }
            }
            var save1 = savedone[0];



            status_msg_app.Text = $"resul: {savedone[0]}+{savedone[1]}+{savedone[2]}+{savedone[3]}+{savedone[4]}+{savedone[5]}+{savedone[6]}";
            if (stepemailing == 0 && ((total == Machines.Count ) || (DateTime.Now.Hour==hour&& DateTime.Now.Minute == (min+ 4))))
            {
                stepemailing = 1;
                hrsave = DateTime.Now.Hour;
                minsave = DateTime.Now.Minute;
                timesaved = true;
                total = 0;

            }
            if (stepemailing == 1 && timesaved == true)
            {
                stepemailing = 2;

                for (int i = 0; i < Machines.Count; i++)
                {
                    e_mail.Machines.Add(Machines_historial[i][0]);
                }
                emails = Notepad.Read_Notepad("emails");

                e_mail.Emailsender_fromserver(emails, "P3 Today's Production Report ");

                hrsave2 = DateTime.Now.Hour;
                minsave2 = DateTime.Now.Minute;
            }
            if (stepemailing == 2 && (hrsave2 == DateTime.Now.Hour) && (DateTime.Now.Minute) == (minsave2 + 1))
            {
                stepemailing = 0;
                hrsave = 0;
                minsave = 0;
                for (int i = 0; i < savedone.Length; i++)
                {
                    savedone[i] = false;
                }


                timesaved = false;
                total = 0;


            }





        }



        private bool updateDB(IOT_Tags_1 Data_in)
        {
            bool res = false;
            if (Data_in != null && pinging(PLC1_Settings.Ip_Address))
            {
                DB_IOT_Tags_1.ID = Convert.ToInt32(PLC1_Settings.Machine_ID);
                DB_IOT_Tags_1.Machine = PLC1_Settings.Machine_Name;
                DB_IOT_Tags_1.PartNumber = "NA";
                DB_IOT_Tags_1.PartStatus = 0;
                DB_IOT_Tags_1.DateTime = DateTime.Now;
                DB_IOT_Tags_1.PLCDateTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, Data_in.PLC_Datetime[3], Data_in.PLC_Datetime[4], Data_in.PLC_Datetime[5]);
                DB_IOT_Tags_1.PLCHour = Data_in.PLC_Datetime[3];
                DB_IOT_Tags_1.PLCMin = Data_in.PLC_Datetime[4];
                DB_IOT_Tags_1.PLCSec = Data_in.PLC_Datetime[5];
                DB_IOT_Tags_1.TotalCount = Data_in.Todays_Total;
                DB_IOT_Tags_1.TotalGood = Data_in.Hourly_Counter[DB_IOT_Tags_1.PLCHour];
                DB_IOT_Tags_1.TotalBad = 00;
                DB_IOT_Tags_1.RunTime = Data_in.Uptime_msec[DB_IOT_Tags_1.PLCHour];
                DB_IOT_Tags_1.PlannedTime = 60;
                DB_IOT_Tags_1.StopTime = Data_in.Downtime_msec[DB_IOT_Tags_1.PLCHour];
                DB_IOT_Tags_1.BreakdownCount = Data_in.SpareDINT[1];
                DB_IOT_Tags_1.OEE = Data_in.OEE_Day;
                DB_IOT_Tags_1.MTBF = Data_in.SpareDINT[2];
                DB_IOT_Tags_1.MTTR = Data_in.SpareDINT[3];
                DB_IOT_Tags_1.CurrentCT = Data_in.Current_Takt_time_msec;
                DB_IOT_Tags_1.LastCT = Data_in.Last_Takt_Time_msec;
                DB_IOT_Tags_1.AvgCT = Data_in.Avg_Takt_Time_msec;
                DB_IOT_Tags_1.Heartbeat = Data_in.Heartbeat;
                DB_IOT_Tags_1.SequenceStep = Data_in.Sequence_Step_Num;
                DB_IOT_Tags_1.SequenceMsg = Data_in.Sequence_Step_msg;
                DB_IOT_Tags_1.AlarmNum = Data_in.Alarm_Code;
                DB_IOT_Tags_1.AlarmMsg = Data_in.Alarm_msg;
                DB_IOT_Tags_1.Remotereset = Data_in.Remotereset;
                DB_IOT_Tags_1.TodayCount = Data_in.Todays_Total;

                for (int i = 0; i < 24; i++)
                {
                    DB_IOT_Tags_1.HourlyCount[i] = Data_in.Hourly_Counter[i];
                }

                DB_IOT_Tags_1.ShiftCount[0] = Data_in.Todays_Shifts[0];
                DB_IOT_Tags_1.ShiftCount[1] = Data_in.Todays_Shifts[1];
                DB_IOT_Tags_1.ShiftCount[2] = Data_in.Todays_Shifts[2];
                DB_IOT_Tags_1.YdayCount = Data_in.Ydays_Total;
                DB_IOT_Tags_1.YdayShiftCount[0] = Data_in.Ydays_Shifts[0];
                DB_IOT_Tags_1.YdayShiftCount[1] = Data_in.Ydays_Shifts[1];
                DB_IOT_Tags_1.YdayShiftCount[2] = Data_in.Ydays_Shifts[2];
                DB_IOT_Tags_1.OEEShift[0] = Data_in.OEE_Shift[0];
                DB_IOT_Tags_1.OEEShift[1] = Data_in.OEE_Shift[1];
                DB_IOT_Tags_1.OEEShift[2] = Data_in.OEE_Shift[2];
                DB_IOT_Tags_1.ShiftRecord = Data_in.Linerecord;

                




                res =  dBController.update_IOTTags1(DB_IOT_Tags_1);
            }
            
            
            return res;
        }
        private bool updateDB_webserver(IOT_Tags_1 Data_in,int id)
        {
            bool res = false;
            if (Data_in != null )
            {
                DB_IOT_Tags_1.ID = id;
                DB_IOT_Tags_1.Machine = Data_in.Machine_Name;
                DB_IOT_Tags_1.PartNumber = "NA";
                DB_IOT_Tags_1.PartStatus = 0;
                DB_IOT_Tags_1.DateTime = DateTime.Now;
                DB_IOT_Tags_1.PLCDateTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, Data_in.PLC_Datetime[3], Data_in.PLC_Datetime[4], Data_in.PLC_Datetime[5]);
                DB_IOT_Tags_1.PLCHour = Data_in.PLC_Datetime[3];
                DB_IOT_Tags_1.PLCMin = Data_in.PLC_Datetime[4];
                DB_IOT_Tags_1.PLCSec = Data_in.PLC_Datetime[5];
                DB_IOT_Tags_1.TotalCount = Data_in.Todays_Total;
                DB_IOT_Tags_1.TotalGood = Data_in.Hourly_Counter[DB_IOT_Tags_1.PLCHour];
                DB_IOT_Tags_1.TotalBad = 00;
                DB_IOT_Tags_1.RunTime = Data_in.Uptime_msec[DB_IOT_Tags_1.PLCHour];
                DB_IOT_Tags_1.PlannedTime = 60;
                DB_IOT_Tags_1.StopTime = Data_in.Downtime_msec[DB_IOT_Tags_1.PLCHour];
                DB_IOT_Tags_1.BreakdownCount = Data_in.SpareDINT[1];
                DB_IOT_Tags_1.OEE = Data_in.OEE_Day;
                DB_IOT_Tags_1.MTBF = Data_in.SpareDINT[2];
                DB_IOT_Tags_1.MTTR = Data_in.SpareDINT[3];
                DB_IOT_Tags_1.CurrentCT = Data_in.Current_Takt_time_msec;
                DB_IOT_Tags_1.LastCT = Data_in.Last_Takt_Time_msec;
                DB_IOT_Tags_1.AvgCT = Data_in.Avg_Takt_Time_msec;
                DB_IOT_Tags_1.Heartbeat = Data_in.Heartbeat;
                DB_IOT_Tags_1.SequenceStep = Data_in.Sequence_Step_Num;
                DB_IOT_Tags_1.SequenceMsg = Data_in.Sequence_Step_msg;
                DB_IOT_Tags_1.AlarmNum = Data_in.Alarm_Code;
                DB_IOT_Tags_1.AlarmMsg = Data_in.Alarm_msg;
                DB_IOT_Tags_1.Remotereset = Data_in.Remotereset;
                DB_IOT_Tags_1.TodayCount = Data_in.Todays_Total;

                for (int i = 0; i < 24; i++)
                {
                    DB_IOT_Tags_1.HourlyCount[i] = Data_in.Hourly_Counter[i];
                }

                DB_IOT_Tags_1.ShiftCount[0] = Data_in.Todays_Shifts[0];
                DB_IOT_Tags_1.ShiftCount[1] = Data_in.Todays_Shifts[1];
                DB_IOT_Tags_1.ShiftCount[2] = Data_in.Todays_Shifts[2];
                DB_IOT_Tags_1.YdayCount = Data_in.Ydays_Total;
                DB_IOT_Tags_1.YdayShiftCount[0] = Data_in.Ydays_Shifts[0];
                DB_IOT_Tags_1.YdayShiftCount[1] = Data_in.Ydays_Shifts[1];
                DB_IOT_Tags_1.YdayShiftCount[2] = Data_in.Ydays_Shifts[2];
                DB_IOT_Tags_1.OEEShift[0] = Data_in.OEE_Shift[0];
                DB_IOT_Tags_1.OEEShift[1] = Data_in.OEE_Shift[1];
                DB_IOT_Tags_1.OEEShift[2] = Data_in.OEE_Shift[2];
                DB_IOT_Tags_1.ShiftRecord = Data_in.Linerecord;






                res = dBController.update_IOTTags1_WebServer(DB_IOT_Tags_1);
            }


            return res;
        }
        bool ipaddress_validation(string ipaddress)
        {
            bool ValidateIP = false;

            IPAddress ip;
            
            
            ValidateIP = IPAddress.TryParse(ipaddress, out ip);

            return ValidateIP;

        }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == (Keys.Alt | Keys.Menu))
            {
                if (!this.menuStrip1.Visible)
                {
                    this.menuStrip1.Visible = true;
                    var OnMenuKey = menuStrip1.GetType().GetMethod("OnMenuKey",
                        System.Reflection.BindingFlags.NonPublic |
                        System.Reflection.BindingFlags.Instance);
                    OnMenuKey.Invoke(this.menuStrip1, null);

                    this.statusStrip1.Visible = true;
                   // var OnStatusKey = statusStrip1.GetType().GetMethod("OnStatusKey",
                    //    System.Reflection.BindingFlags.NonPublic |
                    //    System.Reflection.BindingFlags.Instance);
                    //OnStatusKey.Invoke(this.statusStrip1, null);
                }
                else
                {
                    this.menuStrip1.Visible = false;
                    this.statusStrip1.Visible = false;
                }
                return true;
            }

            if (keyData == Keys.Right)
            {

                return true;

            }
            if (keyData == Keys.Left)
            {
               
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }
      
        private void menuStrip1_MenuDeactivate(object sender, EventArgs e)
        {
            this.BeginInvoke(new Action(() => { this.menuStrip1.Visible = false; }));
        }

        private void Open_DataForm_PLC1()
        {
            
            Form activeform = null;         

            activeform = ChildForm1;

            ChildForm1.TopLevel = false;
            ChildForm1.FormBorderStyle = FormBorderStyle.None;
            ChildForm1.Dock = DockStyle.Fill;
            pnl_PLC1.Controls.Add(ChildForm1);
            pnl_PLC1.Tag = ChildForm1;

            this.SetPLCData1 += new SendDataToChildForm1(ChildForm1.Data_Refresh);
           
             ChildForm1.BringToFront();
            ChildForm1.Show();


        }

        private void picbx_logo_Click(object sender, EventArgs e)
        {
            
               ;
            
        }

        private void Open_DataForm_PLC2()
        {

            Form activeform = null;
            if (activeform != null)
                activeform.Close();

            activeform = ChildForm2;



            ChildForm2.TopLevel = false;
            ChildForm2.FormBorderStyle = FormBorderStyle.None;
            ChildForm2.Dock = DockStyle.Fill;
            pnl_PLC2.Controls.Add(ChildForm2);
            pnl_PLC2.Tag = ChildForm2;
            ChildForm2.BringToFront();
            this.SetPLCData2 += new SendDataToChildForm2(ChildForm2.Data_Refresh);

            ChildForm2.Show();


        }
        private void Open_DataForm_PLC3()
        {

            Form activeform = null;

            activeform = ChildForm3;

            ChildForm3.TopLevel = false;
            ChildForm3.FormBorderStyle = FormBorderStyle.None;
            ChildForm3.Dock = DockStyle.Fill;
            pnl_PLC1.Controls.Add(ChildForm3);
            pnl_PLC1.Tag = ChildForm3;

            this.SetPLCData4 += new SendDataToChildForm4(ChildForm3.Data_Refresh);

            ChildForm3.BringToFront();
            ChildForm3.Show();


        }
        private void Open_DataForm_PLC4()
        {

            Form activeform = null;

            activeform = ChildForm4;

            ChildForm4.TopLevel = false;
            ChildForm4.FormBorderStyle = FormBorderStyle.None;
            ChildForm4.Dock = DockStyle.Fill;
            pnl_PLC1.Controls.Add(ChildForm4);
            pnl_PLC1.Tag = ChildForm4;

            this.SetPLCData4 += new SendDataToChildForm4(ChildForm4.Data_Refresh);

            ChildForm4.BringToFront();
            ChildForm4.Show();


        }

        private void Open_DataForm_PLC5()
        {

            Form activeform = null;

            activeform = ChildForm5;

            ChildForm5.TopLevel = false;
            ChildForm5.FormBorderStyle = FormBorderStyle.None;
            ChildForm5.Dock = DockStyle.Fill;
            pnl_Center.Controls.Add(ChildForm5);
            pnl_Center.Tag = ChildForm5;

            this.SetPLCData5 += new SendDataToChildForm5(ChildForm5.Data_Refresh);

            ChildForm5.BringToFront();
            ChildForm5.Show();


        }
        private void Open_Graphics_PLC1()
        {

            Form activeform = null;
            if (activeform != null)
                activeform.Close();

            activeform = ChildForm3;



            ChildForm3.TopLevel = false;
            ChildForm3.FormBorderStyle = FormBorderStyle.None;
            ChildForm3.Dock = DockStyle.Fill;
            pnl_PLC2.Controls.Add(ChildForm3);
            pnl_PLC2.Tag = ChildForm3;
            ChildForm3.BringToFront();
      

            this.SetPLCData3 += new SendDataToChildForm3(ChildForm3.Data_Refresh);

            ChildForm3.Show();

            
        }
       
        private void FormMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            e_mail.SimpleEmailSender($"{PLC1_Settings.Machine_Name} IOT: Closing App ", "");
        }

        private void toolStrip_MachinesInfo_Click(object sender, EventArgs e)
        {
            FormMachinesSettings myNewForm = new FormMachinesSettings();
            myNewForm.Visible = true;
            //myNewForm.TopMost = true;
            myNewForm.StartPosition = FormStartPosition.CenterScreen;
        }

        private void FormMain_Load(object sender, EventArgs e)
        {
            
          

            e_mail.SimpleEmailSender($"{PLC1_Settings.Machine_Name} IOT: Starting App ", "");

            if (PLC1_Settings.PLC_enabled=="1" )
            {
                this.Text = PLC1_Settings.Machine_Name;
            }
            else
            {
                if (PLC1_Settings.PLC_enabled == "1" )
                {
                    this.Text = PLC1_Settings.Machine_Name ;
                }
                else
                {
                    


                }

            }

            //PLCsSettings = dBController.select_Machineinfo_table_all();
            this.statusStrip1.Visible = false;

         
             
            
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void Setup_PLC1_Click(object sender, EventArgs e)
        {
            Form_PLC_Setup myNewForm = new Form_PLC_Setup(1);
            myNewForm.Visible = true;
            myNewForm.TopMost = true;
            myNewForm.StartPosition = FormStartPosition.CenterScreen;

        }

        private void btn_validate_data_Click(object sender, EventArgs e)
        {
            var temp1 = Notepad.Read_Notepad("PLC1_Settings");
            PLC1_Settings.PLC_enabled = temp1[0];
            PLC1_Settings.Machine_Name = temp1[1];
            PLC1_Settings.Machine_ID = temp1[2];
            PLC1_Settings.Ip_Address = temp1[3];
            PLC1_Settings.Server_enabled = temp1[4];
            PLC1_Settings.Servername = temp1[5];
            PLC1_Settings.Database = temp1[6];
            PLC1_Settings.Table = temp1[7];


            var r = 0;

            bool ipvalid = ipaddress_validation(PLC1_Settings.Ip_Address);
            if (ipvalid && PLC1_Settings.PLC_enabled=="1")
            {
                string CurrentDirectory = Environment.CurrentDirectory;
                System.Diagnostics.Process.Start(@$"{CurrentDirectory}\PLK_IOT_V2.exe");
                Environment.Exit(0);
                //PLC1 = new PLCController(PLC1_Settings.PLC_enabled, PLC1_Settings.Ip_Address, "1,0", "IOT_Tags_1", "IOT_Tags_1", 1);//MainLine PLC1
                //Open_DataForm_PLC1();
                //Open_Graphics_PLC1();
            }
            else
            {
                btn_validate_data1.Visible = true;
                if (PLC1_Settings.PLC_enabled == "0")
                {
                    string message = "PLC is not enabled, get able and try again";
                    string title = "PLC not enabled";
                    MessageBox.Show(message, title);
                }
                if (ipvalid == false)
                {
                    string message = "IP address no valid or no set, try again";
                    string title = "No IP address";
                    MessageBox.Show(message, title);
                }
            }
           
        }


        private void toolStripMenuItem1_edit_emails_Click(object sender, EventArgs e)
        {
            Form_Editemails myNewForm = new Form_Editemails();
            myNewForm.Visible = true;
            myNewForm.TopMost = true;
            myNewForm.StartPosition = FormStartPosition.CenterScreen;
        }

        private void Edit_Send_Report_Click(object sender, EventArgs e)
        {

            
            e_mail.Machines = Machines;
            emails = Notepad.Read_Notepad("emails");
            e_mail.Emailsender_fromserver(emails,"P3 Today's Production Report ");
            
            //shift_production_report();

        }

        private void TSEditSendCurrent_Click(object sender, EventArgs e)
        {
            sendreport =1;
            //shift_production_report();
        }





        void reporting()
        {
            //var hrs = DateTime.Now.Hour;
            //var min = DateTime.Now.Minute;
            //var sec = DateTime.Now.Second;
            //var currentshift = PLC.Current_Shift;
            //var mintosend = 59;
            //int[] hrs_report = new int[3];

            //if (PLC.SpareDINT[0] == 6)
            //{
            //    hrs_report[0] = 13;
            //    hrs_report[1] = 21;
            //    hrs_report[2] = 5;



            //}
            //else
            //{
            //    hrs_report[0] = 12;
            //    hrs_report[1] = 20;
            //    hrs_report[2] = 4;
            //}





            //if (PLC.SpareDINT[0] == 6 || PLC.SpareDINT[0] == 5 || PLC.SpareDINT[0] == 0)
            //{
            //    if (min == mintosend && sec > 58 && hrs == hrs_report[currentshift] && reportdone == false)
            //    {

            //        reportdone = true;
            //        e_mail.Machines = Machines;
            //        e_mail.Emailsender_fromserver("P3 Today's Production Report ");





            //    }
            //    else
            //    {
            //        if (min != mintosend && reportdone == true)
            //        {

            //            reportdone = false;
            //        }
            //    }



            //}









        }
        void shift_production_report()
        {
          
            CaptureMyScreen(PLC.Current_Shift + 1);

            emails = Notepad.Read_Notepad("emails");
      
            var subjectname = PLC1_Settings.only_server_mode == "1" ? PLC.Machine_Name : PLC1_Settings.Machine_Name;

            e_mail.Emailsender(emails, subjectname + $" Production Report Shift ", PLC, null);
       
        }
        private void CaptureMyScreen(int CurrentShift)

        {
   
            int shift = CurrentShift;

            String Daystr = DateTime.Now.ToString("dd");
            int Day = Convert.ToInt32(Daystr);

            String Monthstr = DateTime.Now.ToString("MM");
            int Month = Convert.ToInt32(Monthstr);

            String Yearstr = DateTime.Now.ToString("yy");
            int Year = Convert.ToInt32(Yearstr);

            string CurrentDirectory = Environment.CurrentDirectory;
            string imagedirectory = CurrentDirectory + $"\\Captures\\{Month}{Day}{Year}_Shift_{shift}.png";
            e_mail.CaptureDirectory = imagedirectory;
            DeleteFile(imagedirectory);

            try

            {

                Bitmap bitmap = new Bitmap(Screen.PrimaryScreen.Bounds.Width,
                                    Screen.PrimaryScreen.Bounds.Height);
                Graphics graphics = Graphics.FromImage(bitmap as Image);
                graphics.CopyFromScreen(0, 0, 0, 0, bitmap.Size);
                bitmap.Save(imagedirectory, ImageFormat.Png);

                //Displaying the Successfull Result

                //MessageBox.Show("Screen Captured");

            }

            catch (Exception ex)

            {
                //MessageBox.Show(ex.Message);
            }

        }
        public static void DeleteFile(string path)
        {
            if (!System.IO.File.Exists(path))
            {
                return;
            }

            bool isDeleted = false;
            while (!isDeleted)
            {
                try
                {
                    System.IO.File.Delete(path);
                    isDeleted = true;
                }
                catch (Exception e)
                {
                }

            }
        }
        public bool pinging(string ip)
        {
            bool plc_connected = false;
            try
            {
                Ping myPing = new Ping();
                PingReply reply = myPing.Send(ip, 1000);
                if (reply.Status == IPStatus.Success)
                {
                    Console.WriteLine("Status :  " + reply.Status + " \n Time : " + reply.RoundtripTime.ToString() + " \n Address : " + reply.Address);
                    //Console.WriteLine(reply.ToString());
                    //string message = "Status :  " + reply.Status + " \n Time : " + reply.RoundtripTime.ToString() + " \n Address : " + reply.Address;
                    //string title = $"Message: PLC {ip} Connected";
                    //MessageBox.Show(message, title);
                    plc_connected = true;


                }
                else
                {


                    string message = "No Pinging, PLC has been disconnected";
                    string title = $"Error: PLC Address {ip} Not Connected";
                    //MessageBoxButtons buttons = MessageBoxButtons.OK;
                    //MessageBox.Show(message, title, buttons, MessageBoxIcon.Warning);
                    plc_connected = false;

                }
            }
            catch (Exception e)
            {

                Console.WriteLine("Exception: " + e.Message);
                string message = e.Message;
                string title = $"Error: PLC Address {ip} has been disconnected";
                //MessageBoxButtons buttons = MessageBoxButtons.OK;
                //MessageBox.Show(message, title, buttons, MessageBoxIcon.Warning);
                plc_connected = false;




            }
            return plc_connected;

        }



    }




}


#region
//select data from server

//PLC = Convert.ToBoolean(Convert.ToInt32(PLC1_Settings.Server_enabled)) == false ? dBController.select_IOTTags1(Convert.ToInt32(PLC1_Settings.Machine_ID)) : PLC1.Datareaded_out;            
//var t = 0;
//update data from plc controller

#endregion