﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using PLK_IIOT_V2.Controllers;
using PLK_IIOT_V2.Models;

namespace PLK_IIOT_V2
{
    public partial class Form_Editemails : Form
    {
        NotepadController Notepad = new NotepadController();
        List<String> emails = new List<string>();
        bool validation = false;
        public Form_Editemails()
        {
            InitializeComponent();
        }

        private void Form_Editemails_Load(object sender, EventArgs e)
        {


            var t = Notepad.Read_Notepad("emails");
            for (int i = 0; i < 5; i++)
            {
                if (t.Count > 0 && t.Count >i)
                {
                    emails.Add(t[i]);
                }
                else
                {
                    emails.Add ("");
                }
            }

            txtb_cc1.Text = emails[0];
            txtb_cc2.Text = emails[1];
            txtb_cc3.Text = emails[2];
            txtb_cc3.Text = emails[3];
            txtb_cc3.Text = emails[4];

        }
        private bool ValidateEmail(string emailtovalidate)
        {
            bool validate_result = false;

            string email = emailtovalidate;
            Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
            Match match = regex.Match(email);
            if (match.Success)
                validate_result = true;
            else
                validate_result = false;

            return validate_result;
        }

        private void btn_close_Click(object sender, EventArgs e)
        {

            this.Close();
            
            //FormMain myNewForm = new FormMain();

            //myNewForm.Show();

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            emails[0] = txtb_cc1.Text;
            emails[1] = txtb_cc2.Text;
            emails[2] = txtb_cc3.Text;
            emails[3] = txtb_cc4.Text;
            emails[4] = txtb_cc5.Text;

           


          

            for (int i = 0; i < 5; i++)
            {
                if (ValidateEmail(emails[i]) == false && emails[i].Length>0)
                {
                    MessageBox.Show($"{emails[i]} is not valid ", "Email validation error");
                    validation = false;
                    break;
                }
                else
                {
                    validation = true;
                }


            }

            if (validation==true)
            {
                Notepad.Write_Notepad(emails, "emails");
            
                MessageBox.Show($"Emails have been successfully saved ", "Email validation Ok");

            }
        }
    }
}
