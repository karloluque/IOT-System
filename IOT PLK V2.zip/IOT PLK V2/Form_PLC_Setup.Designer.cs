﻿
namespace PLK_IIOT_V2
{
    partial class Form_PLC_Setup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.cbx_PLCtype = new System.Windows.Forms.ComboBox();
            this.lbl_PLC_type = new System.Windows.Forms.Label();
            this.chbwebserveronly = new System.Windows.Forms.CheckBox();
            this.chb_onlyservermode = new System.Windows.Forms.CheckBox();
            this.lbl_machineid = new System.Windows.Forms.Label();
            this.txtb_machineid = new System.Windows.Forms.TextBox();
            this.chbx_server_enabled = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lbl_database = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtb_table = new System.Windows.Forms.TextBox();
            this.txtxb_DataBase = new System.Windows.Forms.TextBox();
            this.txtbx_Server = new System.Windows.Forms.TextBox();
            this.btn_close = new System.Windows.Forms.Button();
            this.lbl_save = new System.Windows.Forms.Button();
            this.lbl_ipaddress = new System.Windows.Forms.Label();
            this.txtb_ip_address = new System.Windows.Forms.TextBox();
            this.lbl_machinename = new System.Windows.Forms.Label();
            this.txtb_machine_name = new System.Windows.Forms.TextBox();
            this.lbl_currentplc = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.chbx_enabled = new System.Windows.Forms.CheckBox();
            this.lbl_plc = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.cbx_PLCtype);
            this.panel1.Controls.Add(this.lbl_PLC_type);
            this.panel1.Controls.Add(this.chbwebserveronly);
            this.panel1.Controls.Add(this.chb_onlyservermode);
            this.panel1.Controls.Add(this.lbl_machineid);
            this.panel1.Controls.Add(this.txtb_machineid);
            this.panel1.Controls.Add(this.chbx_server_enabled);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.lbl_database);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.txtb_table);
            this.panel1.Controls.Add(this.txtxb_DataBase);
            this.panel1.Controls.Add(this.txtbx_Server);
            this.panel1.Controls.Add(this.btn_close);
            this.panel1.Controls.Add(this.lbl_save);
            this.panel1.Controls.Add(this.lbl_ipaddress);
            this.panel1.Controls.Add(this.txtb_ip_address);
            this.panel1.Controls.Add(this.lbl_machinename);
            this.panel1.Controls.Add(this.txtb_machine_name);
            this.panel1.Controls.Add(this.lbl_currentplc);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.chbx_enabled);
            this.panel1.Controls.Add(this.lbl_plc);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(418, 523);
            this.panel1.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(98, 137);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(240, 13);
            this.label4.TabIndex = 20;
            this.label4.Text = "Note: for FX5 or Q series, Port Shold be 10000";
            // 
            // cbx_PLCtype
            // 
            this.cbx_PLCtype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbx_PLCtype.FormattingEnabled = true;
            this.cbx_PLCtype.Items.AddRange(new object[] {
            "Void",
            "AB Ethenet",
            "FX5 Ethernet",
            "Q Series Ethenet"});
            this.cbx_PLCtype.Location = new System.Drawing.Point(134, 111);
            this.cbx_PLCtype.Name = "cbx_PLCtype";
            this.cbx_PLCtype.Size = new System.Drawing.Size(181, 23);
            this.cbx_PLCtype.TabIndex = 19;
            // 
            // lbl_PLC_type
            // 
            this.lbl_PLC_type.AutoSize = true;
            this.lbl_PLC_type.Location = new System.Drawing.Point(57, 111);
            this.lbl_PLC_type.Name = "lbl_PLC_type";
            this.lbl_PLC_type.Size = new System.Drawing.Size(55, 15);
            this.lbl_PLC_type.TabIndex = 18;
            this.lbl_PLC_type.Text = "PLC Type";
            // 
            // chbwebserveronly
            // 
            this.chbwebserveronly.AutoSize = true;
            this.chbwebserveronly.Location = new System.Drawing.Point(229, 419);
            this.chbwebserveronly.Name = "chbwebserveronly";
            this.chbwebserveronly.Size = new System.Drawing.Size(85, 19);
            this.chbwebserveronly.TabIndex = 16;
            this.chbwebserveronly.Text = "Web Server";
            this.chbwebserveronly.UseVisualStyleBackColor = true;
            this.chbwebserveronly.CheckedChanged += new System.EventHandler(this.chbwebserveronly_CheckedChanged);
            // 
            // chb_onlyservermode
            // 
            this.chb_onlyservermode.AutoSize = true;
            this.chb_onlyservermode.Location = new System.Drawing.Point(134, 419);
            this.chb_onlyservermode.Name = "chb_onlyservermode";
            this.chb_onlyservermode.Size = new System.Drawing.Size(89, 19);
            this.chb_onlyservermode.TabIndex = 15;
            this.chb_onlyservermode.Text = "Local Server";
            this.chb_onlyservermode.UseVisualStyleBackColor = true;
            this.chb_onlyservermode.CheckedChanged += new System.EventHandler(this.chb_onlyservermode_CheckedChanged);
            // 
            // lbl_machineid
            // 
            this.lbl_machineid.AutoSize = true;
            this.lbl_machineid.Location = new System.Drawing.Point(42, 155);
            this.lbl_machineid.Name = "lbl_machineid";
            this.lbl_machineid.Size = new System.Drawing.Size(67, 15);
            this.lbl_machineid.TabIndex = 14;
            this.lbl_machineid.Text = "Machine ID";
            // 
            // txtb_machineid
            // 
            this.txtb_machineid.Location = new System.Drawing.Point(134, 152);
            this.txtb_machineid.Name = "txtb_machineid";
            this.txtb_machineid.Size = new System.Drawing.Size(181, 23);
            this.txtb_machineid.TabIndex = 13;
            // 
            // chbx_server_enabled
            // 
            this.chbx_server_enabled.AutoSize = true;
            this.chbx_server_enabled.Location = new System.Drawing.Point(134, 262);
            this.chbx_server_enabled.Name = "chbx_server_enabled";
            this.chbx_server_enabled.Size = new System.Drawing.Size(127, 19);
            this.chbx_server_enabled.TabIndex = 12;
            this.chbx_server_enabled.Text = "SQL Server Enabled";
            this.chbx_server_enabled.UseVisualStyleBackColor = true;
            this.chbx_server_enabled.CheckedChanged += new System.EventHandler(this.chbx_server_enabled_CheckedChanged);
            this.chbx_server_enabled.CheckStateChanged += new System.EventHandler(this.chbx_server_enabled_CheckStateChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(66, 379);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 15);
            this.label3.TabIndex = 11;
            this.label3.Text = "Table";
            // 
            // lbl_database
            // 
            this.lbl_database.AutoSize = true;
            this.lbl_database.Location = new System.Drawing.Point(66, 340);
            this.lbl_database.Name = "lbl_database";
            this.lbl_database.Size = new System.Drawing.Size(58, 15);
            this.lbl_database.TabIndex = 11;
            this.lbl_database.Text = "Data Base";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(66, 299);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 15);
            this.label2.TabIndex = 11;
            this.label2.Text = "Server";
            // 
            // txtb_table
            // 
            this.txtb_table.Location = new System.Drawing.Point(134, 376);
            this.txtb_table.Name = "txtb_table";
            this.txtb_table.Size = new System.Drawing.Size(181, 23);
            this.txtb_table.TabIndex = 10;
            // 
            // txtxb_DataBase
            // 
            this.txtxb_DataBase.Location = new System.Drawing.Point(134, 337);
            this.txtxb_DataBase.Name = "txtxb_DataBase";
            this.txtxb_DataBase.Size = new System.Drawing.Size(181, 23);
            this.txtxb_DataBase.TabIndex = 10;
            // 
            // txtbx_Server
            // 
            this.txtbx_Server.Location = new System.Drawing.Point(134, 296);
            this.txtbx_Server.Name = "txtbx_Server";
            this.txtbx_Server.Size = new System.Drawing.Size(181, 23);
            this.txtbx_Server.TabIndex = 10;
            // 
            // btn_close
            // 
            this.btn_close.Location = new System.Drawing.Point(206, 461);
            this.btn_close.Name = "btn_close";
            this.btn_close.Size = new System.Drawing.Size(132, 38);
            this.btn_close.TabIndex = 9;
            this.btn_close.Text = "Close";
            this.btn_close.UseVisualStyleBackColor = true;
            this.btn_close.Click += new System.EventHandler(this.btn_close_Click);
            // 
            // lbl_save
            // 
            this.lbl_save.Location = new System.Drawing.Point(68, 461);
            this.lbl_save.Name = "lbl_save";
            this.lbl_save.Size = new System.Drawing.Size(132, 38);
            this.lbl_save.TabIndex = 8;
            this.lbl_save.Text = "Save";
            this.lbl_save.UseVisualStyleBackColor = true;
            this.lbl_save.Click += new System.EventHandler(this.lbl_save_Click);
            // 
            // lbl_ipaddress
            // 
            this.lbl_ipaddress.AutoSize = true;
            this.lbl_ipaddress.Location = new System.Drawing.Point(66, 224);
            this.lbl_ipaddress.Name = "lbl_ipaddress";
            this.lbl_ipaddress.Size = new System.Drawing.Size(62, 15);
            this.lbl_ipaddress.TabIndex = 7;
            this.lbl_ipaddress.Text = "IP Address";
            // 
            // txtb_ip_address
            // 
            this.txtb_ip_address.Location = new System.Drawing.Point(134, 221);
            this.txtb_ip_address.Name = "txtb_ip_address";
            this.txtb_ip_address.Size = new System.Drawing.Size(181, 23);
            this.txtb_ip_address.TabIndex = 6;
            this.txtb_ip_address.TextChanged += new System.EventHandler(this.txtb_ip_address_TextChanged);
            // 
            // lbl_machinename
            // 
            this.lbl_machinename.AutoSize = true;
            this.lbl_machinename.Location = new System.Drawing.Point(42, 186);
            this.lbl_machinename.Name = "lbl_machinename";
            this.lbl_machinename.Size = new System.Drawing.Size(86, 15);
            this.lbl_machinename.TabIndex = 5;
            this.lbl_machinename.Text = "Machine name";
            // 
            // txtb_machine_name
            // 
            this.txtb_machine_name.Location = new System.Drawing.Point(134, 183);
            this.txtb_machine_name.Name = "txtb_machine_name";
            this.txtb_machine_name.Size = new System.Drawing.Size(181, 23);
            this.txtb_machine_name.TabIndex = 4;
            // 
            // lbl_currentplc
            // 
            this.lbl_currentplc.AutoSize = true;
            this.lbl_currentplc.Font = new System.Drawing.Font("Segoe UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lbl_currentplc.Location = new System.Drawing.Point(96, 40);
            this.lbl_currentplc.Name = "lbl_currentplc";
            this.lbl_currentplc.Size = new System.Drawing.Size(182, 21);
            this.lbl_currentplc.TabIndex = 3;
            this.lbl_currentplc.Text = "PLC 1 has been selected";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(98, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(182, 21);
            this.label1.TabIndex = 3;
            this.label1.Text = "PLC 1 has been selected";
            // 
            // chbx_enabled
            // 
            this.chbx_enabled.AutoSize = true;
            this.chbx_enabled.Location = new System.Drawing.Point(134, 86);
            this.chbx_enabled.Name = "chbx_enabled";
            this.chbx_enabled.Size = new System.Drawing.Size(101, 19);
            this.chbx_enabled.TabIndex = 2;
            this.chbx_enabled.Text = "PLC 1 Enabled";
            this.chbx_enabled.UseVisualStyleBackColor = true;
            this.chbx_enabled.CheckedChanged += new System.EventHandler(this.chbx_enabled_CheckedChanged);
            // 
            // lbl_plc
            // 
            this.lbl_plc.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl_plc.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_plc.Location = new System.Drawing.Point(0, 0);
            this.lbl_plc.Name = "lbl_plc";
            this.lbl_plc.Size = new System.Drawing.Size(418, 35);
            this.lbl_plc.TabIndex = 0;
            this.lbl_plc.Text = "PLC Setting ";
            this.lbl_plc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form_PLC_Setup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(418, 523);
            this.Controls.Add(this.panel1);
            this.Name = "Form_PLC_Setup";
            this.Text = "Form_PLC_Setup";
            this.Load += new System.EventHandler(this.Form_PLC_Setup_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button lbl_save;
        private System.Windows.Forms.Label lbl_ipaddress;
        private System.Windows.Forms.TextBox txtb_ip_address;
        private System.Windows.Forms.Label lbl_machinename;
        private System.Windows.Forms.TextBox txtb_machine_name;
        private System.Windows.Forms.Label lbl_currentplc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox chbx_enabled;
        private System.Windows.Forms.Label lbl_plc;
        private System.Windows.Forms.Button btn_close;
        private System.Windows.Forms.CheckBox chbx_server_enabled;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbl_database;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtb_table;
        private System.Windows.Forms.TextBox txtxb_DataBase;
        private System.Windows.Forms.TextBox txtbx_Server;
        private System.Windows.Forms.Label lbl_machineid;
        private System.Windows.Forms.TextBox txtb_machineid;
        private System.Windows.Forms.CheckBox chb_onlyservermode;
        private System.Windows.Forms.CheckBox chbwebserveronly;
        private System.Windows.Forms.Label lbl_PLC_type;
        private System.Windows.Forms.ComboBox cbx_PLCtype;
        private System.Windows.Forms.Label label4;
    }
}