﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Net;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using PLK_IIOT_V2.Controllers;
using PLK_IIOT_V2.Models;

namespace PLK_IIOT_V2
{
    public partial class Form_PLC_Setup : Form
    {
        string connectionString = " ";
        NotepadController Notepad = new NotepadController();
        //List<string> setting_description= new List<string>();
        List<string> setting_values = new List<string>();
        //List<string> complete_values = new List<string>();
        int plcnum = new int();
        bool checkboxchange = false, ipchanged = false;
        DBController SQLQuery_Controller = new DBController();
        bool sqlconection;
        PLC_settings PLC1_Settings = new PLC_settings();
        PLC_settings PLC2_Settings = new PLC_settings();
        public Form_PLC_Setup(int plcnum)
        {
            InitializeComponent();
            this.plcnum = plcnum;

            if (plcnum == 1)
            {

                Read_PLC_settings("PLC1_Settings");
                chbx_enabled.Text = "PLC Enabled";
                lbl_currentplc.Text = "PLC 1 has been selected";
            }
            else
            if (plcnum == 2)
            {
                lbl_currentplc.Text = "PLC 2 has been selected";
                chbx_enabled.Text = "PLC Enabled";
                Read_PLC_settings("PLC2_Settings");

            }





        }
        void Read_PLC_settings(string namenotepad)
        {



            setting_values = Notepad.Read_Notepad(namenotepad);



            if (setting_values.Count > 0)
            {
                
                chbx_enabled.Checked = Convert.ToBoolean(Convert.ToInt32(setting_values[0])) == true ? true : false;
                txtb_machine_name.Text = setting_values[1];
                txtb_machineid.Text = setting_values[2];
                txtb_ip_address.Text = setting_values[3];
                chbx_server_enabled.Checked = Convert.ToBoolean(Convert.ToInt32(setting_values[4]))==true? true:false;
               
                txtbx_Server.Text = setting_values[5];
                txtxb_DataBase.Text = setting_values[6];
                txtb_table.Text = setting_values[7];
                chb_onlyservermode.Checked = Convert.ToBoolean(Convert.ToInt32(setting_values[8])) == true ? true : false;
                chb_onlyservermode.Checked = Convert.ToBoolean(Convert.ToInt32(setting_values[8])) == true ? true : false;
                chbwebserveronly.Checked = Convert.ToBoolean(Convert.ToInt32(setting_values[9])) == true ? true : false;
                chbwebserveronly.Checked = Convert.ToBoolean(Convert.ToInt32(setting_values[9])) == true ? true : false;
                ///aqui se agrega nuevos settings
                cbx_PLCtype.SelectedIndex = Convert.ToInt32(setting_values[10]);

             

                txtbx_Server.Enabled = chbx_server_enabled.Checked == true ? true : false;
                txtb_table.Enabled = chbx_server_enabled.Checked == true ? true : false;
                txtxb_DataBase.Enabled = chbx_server_enabled.Checked == true ? true : false;

                chbx_enabled.Enabled = chb_onlyservermode.Checked == true ? false : true;
                txtb_machine_name.Enabled = chb_onlyservermode.Checked == true ? false : true;
                txtb_ip_address.Enabled = chb_onlyservermode.Checked == true ? false : true;
                txtb_machineid.Enabled = chb_onlyservermode.Checked == true ? false : true;
               
                ///

            }

           


           


        }









        private void lbl_save_Click(object sender, EventArgs e)
        {

            if (ipaddress_validation(txtb_ip_address.Text) == true)
            {

                setting_values.Clear();



                if (chbx_enabled.Checked == true) setting_values.Insert(0, "1");
                if (chbx_enabled.Checked == false) setting_values.Insert(0, "0");
                setting_values.Insert(1, txtb_machine_name.Text);
                setting_values.Insert(2, txtb_machineid.Text);
                setting_values.Insert(3, txtb_ip_address.Text);
                if (chbx_server_enabled.Checked == true) setting_values.Insert(4, "1");
                if (chbx_server_enabled.Checked == false) setting_values.Insert(4, "0");
                setting_values.Insert(5, txtbx_Server.Text);
                setting_values.Insert(6, txtxb_DataBase.Text);
                setting_values.Insert(7, txtb_table.Text);
                if (chb_onlyservermode.Checked == true) setting_values.Insert(8, "1");
                if (chb_onlyservermode.Checked == false) setting_values.Insert(8, "0");

                 if (chbwebserveronly.Checked == true) setting_values.Insert(9, "1");
                if (chbwebserveronly.Checked == false) setting_values.Insert(9, "0");
                ///aqui se agrega nuevos settings
                setting_values.Insert(10, cbx_PLCtype.SelectedIndex.ToString());


                //string connectionString11 = $"Data Source =10.30.40.26,49170\\SQLEXPRESS; User Id=iot;Password=Plastikon2022!; Initial Catalog=P3_IOT_PLK1;";
                
                if (chbwebserveronly.Checked == true)
                {
                    connectionString = $"Data Source =sql.bsite.net\\MSSQL2016; User Id=controlsplastikon_;Password=Plastikon2022!; Initial Catalog=controlsplastikon_";
                }
                else
                {
                     connectionString = $"Data Source ={txtbx_Server.Text}\\SQLEXPRESS; User Id=iot;Password=Plastikon2022!; Initial Catalog={txtxb_DataBase.Text};";
                }
               
                
                
                if (chbx_server_enabled.Checked == true)
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        try
                        {
                            connection.Open();
                            sqlconection = true;


                        }
                        catch (SqlException)
                        {
                            sqlconection = false;

                        }
                    }
                    if (sqlconection == true)
                    {
                        if (plcnum == 1) Notepad.Write_Notepad(setting_values, "PLC1_Settings");
                        if (plcnum == 2) Notepad.Write_Notepad(setting_values, "PLC2_Settings");

                        string message = $"Server Connection ok \n {connectionString.Substring(0, 36)}";
                        string title = $"Server Connection ok ";
                        MessageBox.Show(message, title);
                    }
                    else
                    {
                        string message = $"Server Connection nok \n check name or database\n {connectionString.Substring(0, 36)}";
                        string title = $"Server Connection nok";
                        MessageBox.Show(message, title);
                    }
                }
                else
                {
                    if (plcnum == 1) Notepad.Write_Notepad(setting_values, "PLC1_Settings");
                    if (plcnum == 2) Notepad.Write_Notepad(setting_values, "PLC2_Settings");
                }





            }
            else
            {
                string message = "IP address no valid, try again";
                string title = "IP address no valid";
                MessageBox.Show(message, title);
            }





        }

        private void btn_close_Click(object sender, EventArgs e)
        {
            this.Close();

            if (checkboxchange == true || ipchanged == true)
            {
                string CurrentDirectory = Environment.CurrentDirectory;
                System.Diagnostics.Process.Start(@$"{CurrentDirectory}\PLK_IIOT_V2.exe");
                Environment.Exit(0);
            }



        }

        private void Form_PLC_Setup_Load(object sender, EventArgs e)
        {

        }
        bool ipaddress_validation(string ipaddress)
        {
            bool ValidateIP = false;

            IPAddress ip;


            ValidateIP = IPAddress.TryParse(ipaddress, out ip);

            return ValidateIP;

        }

        private void chbx_enabled_CheckedChanged(object sender, EventArgs e)
        {
            checkboxchange = true;
            lbl_PLC_type.Enabled=checkboxchange;
        }

        private void chbx_server_enabled_CheckedChanged(object sender, EventArgs e)
        {
            //chbx_enabled.Checked = !chbx_enabled.Checked;

        }

        private void chbx_server_enabled_CheckStateChanged(object sender, EventArgs e)
        {
            var v = chbx_server_enabled.Checked;
            var f = v;
            if (v == true)
            {
                txtbx_Server.Enabled = true;
                txtb_table.Enabled = true;
                txtxb_DataBase.Enabled = true;
            }
            else
            {
                txtbx_Server.Enabled = false;
                txtb_table.Enabled = false;
                txtxb_DataBase.Enabled = false;

            }

        }

        private void chb_onlyservermode_CheckedChanged(object sender, EventArgs e)
        {

            chbx_enabled.Enabled = chb_onlyservermode.Checked == true ? false : true;
            txtb_machine_name.Enabled = chb_onlyservermode.Checked == true ? false : true;
            txtb_ip_address.Enabled = chb_onlyservermode.Checked == true ? false : true;
            txtb_machineid.Enabled = chb_onlyservermode.Checked == true ? false : true;

        }

        private void chbwebserveronly_CheckedChanged(object sender, EventArgs e)
        {
            chbx_enabled.Enabled = chbwebserveronly.Checked == true ? false : true;
            txtb_machine_name.Enabled = chbwebserveronly.Checked == true ? false : true;
            txtb_ip_address.Enabled = chbwebserveronly.Checked == true ? false : true;
            txtb_machineid.Enabled = chbwebserveronly.Checked == true ? false : true;
            chbx_server_enabled.Enabled = chbwebserveronly.Checked == true ? false : true;
            txtbx_Server.Enabled = chbwebserveronly.Checked == true ? false : true;
            txtb_table.Enabled = chbwebserveronly.Checked == true ? false : true;
            txtxb_DataBase.Enabled = chbwebserveronly.Checked == true ? false : true;
            chb_onlyservermode.Enabled = chbwebserveronly.Checked == true ? false : true;
        }

        private void lb_PLCtype_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtb_ip_address_TextChanged(object sender, EventArgs e)
        {
            ipchanged = true;
        }
    }
}
