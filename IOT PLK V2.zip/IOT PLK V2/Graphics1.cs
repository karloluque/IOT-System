﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using PLK_IIOT_V2.Controllers;
using PLK_IIOT_V2.Models;
using ScottPlot;
using Color = System.Windows.Media.Color;
using LiveCharts;
using System.Windows.Media;
using LiveCharts.Wpf;
using System.Windows;


namespace PLK_IIOT_V2
{
    
    public partial class Graphics1 : Form
    {

        double[] Todays_Shifts = new double[3];
        int last_hour,currentline,currentvaluehour=40,hour=5,graphlines1,sec=0;
        public IOT_Tags_1 PLC = new IOT_Tags_1();
        NotepadController Notepad = new NotepadController();
        int last_day;
        double[] Shift1_D= new double[7];
        double[] Shift2_D = new double[7];
        double[] Shift3_D = new double[7];

        double[] Y_Data= new double[240];
        double[] Y_Data2 = new double[240];
        bool firstscan = false;
        double[] xPositions = new double[168];
        string[] xLabels = { " Mon \n  H1  S1  ", "Mon \n  H2  S1  ", "Mon \n  H3  S1  ", "Mon \n  H4  S1  ", "Mon \n  H5  S1  ", "Mon \n  H6  S1  ", "Mon \n  H7  S1  ", "Mon \n  H8  S1  ", "Mon \n  H1  S2  ", "Mon \n  H2  S2  ", "Mon \n  H3  S2  ", "Mon \n  H4  S2  ", "Mon \n  H5  S2  ", "Mon \n  H6  S2  ", "Mon \n  H7  S2  ", "Mon \n  H8  S2  ", "Mon \n  H1  S3  ", "Mon \n  H2  S3  ", "Mon \n  H3  S3  ", "Mon \n  H4  S3  ", "Mon \n  H5  S3  ", "Mon \n  H6  S3  ", "Mon \n  H7  S3  ", "Mon \n  H8  S3  ", "Tue \n  H1  S1  ", "Tue \n  H2  S1  ", "Tue \n  H3  S1  ", "Tue \n  H4  S1  ", "Tue \n  H5  S1  ", "Tue \n  H6  S1  ", "Tue \n  H7  S1  ", "Tue \n  H8  S1  ", "Tue \n  H1  S2  ", "Tue \n  H2  S2  ", "Tue \n  H3  S2  ", "Tue \n  H4  S2  ", "Tue \n  H5  S2  ", "Tue \n  H6  S2  ", "Tue \n  H7  S2  ", "Tue \n  H8  S2  ", "Tue \n  H1  S3  ", "Tue \n  H2  S3  ", "Tue \n  H3  S3  ", "Tue \n  H4  S3  ", "Tue \n  H5  S3  ", "Tue \n  H6  S3  ", "Tue \n  H7  S3  ", "Tue \n  H8  S3  ", "Wed \n  H1  S1  ", "Wed \n  H2  S1  ", "Wed \n  H3  S1  ", "Wed \n  H4  S1  ", "Wed \n  H5  S1  ", "Wed \n  H6  S1  ", "Wed \n  H7  S1  ", "Wed \n  H8  S1  ", "Wed \n  H1  S2  ", "Wed \n  H2  S2  ", "Wed \n  H3  S2  ", "Wed \n  H4  S2  ", "Wed \n  H5  S2  ", "Wed \n  H6  S2  ", "Wed \n  H7  S2  ", "Wed \n  H8  S2  ", "Wed \n  H1  S3  ", "Wed \n  H2  S3  ", "Wed \n  H3  S3  ", "Wed \n  H4  S3  ", "Wed \n  H5  S3  ", "Wed \n  H6  S3  ", "Wed \n  H7  S3  ", "Wed \n  H8  S3  ", "Thu \n  H1  S1  ", "Thu \n  H2  S1  ", "Thu \n  H3  S1  ", "Thu \n  H4  S1  ", "Thu \n  H5  S1  ", "Thu \n  H6  S1  ", "Thu \n  H7  S1  ", "Thu \n  H8  S1  ", "Thu \n  H1  S2  ", "Thu \n  H2  S2  ", "Thu \n  H3  S2  ", "Thu \n  H4  S2  ", "Thu \n  H5  S2  ", "Thu \n  H6  S2  ", "Thu \n  H7  S2  ", "Thu \n  H8  S2  ", "Thu \n  H1  S3  ", "Thu \n  H2  S3  ", "Thu \n  H3  S3  ", "Thu \n  H4  S3  ", "Thu \n  H5  S3  ", "Thu \n  H6  S3  ", "Thu \n  H7  S3  ", "Thu \n  H8  S3  ", "Fri \n  H1  S1  ", "Fri \n  H2  S1  ", "Fri \n  H3  S1  ", "Fri \n  H4  S1  ", "Fri \n  H5  S1  ", "Fri \n  H6  S1  ", "Fri \n  H7  S1  ", "Fri \n  H8  S1  ", "Fri \n  H1  S2  ", "Fri \n  H2  S2  ", "Fri \n  H3  S2  ", "Fri \n  H4  S2  ", "Fri \n  H5  S2  ", "Fri \n  H6  S2  ", "Fri \n  H7  S2  ", "Fri \n  H8  S2  ", "Fri \n  H1  S3  ", "Fri \n  H2  S3  ", "Fri \n  H3  S3  ", "Fri \n  H4  S3  ", "Fri \n  H5  S3  ", "Fri \n  H6  S3  ", "Fri \n  H7  S3  ", "Fri \n  H8  S3  ", "Sat \n  H1  S1  ", "Sat \n  H2  S1  ", "Sat \n  H3  S1  ", "Sat \n  H4  S1  ", "Sat \n  H5  S1  ", "Sat \n  H6  S1  ", "Sat \n  H7  S1  ", "Sat \n  H8  S1  ", "Sat \n  H1  S2  ", "Sat \n  H2  S2  ", "Sat \n  H3  S2  ", "Sat \n  H4  S2  ", "Sat \n  H5  S2  ", "Sat \n  H6  S2  ", "Sat \n  H7  S2  ", "Sat \n  H8  S2  ", "Sat \n  H1  S3  ", "Sat \n  H2  S3  ", "Sat \n  H3  S3  ", "Sat \n  H4  S3  ", "Sat \n  H5  S3  ", "Sat \n  H6  S3  ", "Sat \n  H7  S3  ", "Sat \n  H8  S3  ", "Sun \n  H1  S1  ", "Sun \n  H2  S1  ", "Sun \n  H3  S1  ", "Sun \n  H4  S1  ", "Sun \n  H5  S1  ", "Sun \n  H6  S1  ", "Sun \n  H7  S1  ", "Sun \n  H8  S1  ", "Sun \n  H1  S2  ", "Sun \n  H2  S2  ", "Sun \n  H3  S2  ", "Sun \n  H4  S2  ", "Sun \n  H5  S2  ", "Sun \n  H6  S2  ", "Sun \n  H7  S2  ", "Sun \n  H8  S2  ", "Sun \n  H1  S3  ", "Sun \n  H2  S3  ", "Sun \n  H3  S3  ", "Sun \n  H4  S3  ", "Sun \n  H5  S3  ", "Sun \n  H6  S3  ", "Sun \n  H7  S3  ", "Sun \n  H8  S3  " };
        int t, plot2count, plot3count;
        int refresh_cycletime = 0,currenthour,temphour;
        private void Graphics1_Load(object sender, EventArgs e)
        {
            //currentline = Notepad.readlines("Graphics1X");

            //Graphic1_series_Y = Notepad.Read_Notepad("Graphics1Y");
            //Graphic1_series_X = Notepad.Read_Notepad("Graphics1X");
        }

        private void tmr_update_Tick(object sender, EventArgs e)
        {
           
               


        }

        private void tableLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        public Graphics1()
        {
            
            InitializeComponent();

            for (int i = 0; i < 168; i++)
            {
                xPositions[i] = i + 1;
            }

            bar_plot_refresh( Shift1_D, Shift2_D, Shift3_D);

            //plot4_refresh(,,);
            





           
        }
        public void Data_Refresh(IOT_Tags_1 data_in)
        {
            
            PLC = data_in;
            lbl_oee_s1.Text = $"OEE Shift 3: {Decimal.Round(Convert.ToDecimal(PLC.OEE_Shift[2]) , 2).ToString()} %";
            lbl_oee_s2.Text = $"OEE Shift 1: {Decimal.Round(Convert.ToDecimal(PLC.OEE_Shift[0]) , 2).ToString()} %";
            lbl_oee_s3.Text = $"OEE Shift 2: {Decimal.Round(Convert.ToDecimal(PLC.OEE_Shift[1]) , 2).ToString()} %";


            changefontcolor(lbl_oee_s1, PLC.OEE_Shift[2]);
            changefontcolor(lbl_oee_s2, PLC.OEE_Shift[0]);
            changefontcolor(lbl_oee_s3, PLC.OEE_Shift[1]);




            currenthour =PLC.PLC_Datetime[3];            
            var lastCTchange=PLC.Last_Takt_Time_msec;
            if (lastCTchange != refresh_cycletime || firstscan==false)
            {
                bar_plot_refresh(Shift1_D, Shift2_D, Shift3_D);
                refresh_cycletime = lastCTchange;
            }

            //Random random = new Random(0);

            //PLC.Weekly_Count_S1 = DataGen.RandomInts(random, 7, 375, 25);
            //PLC.Weekly_Count_S2 = DataGen.RandomInts(random, 7, 375, 25);
            //PLC.Weekly_Count_S3 = DataGen.RandomInts(random, 7, 375, 25);

            //Shift1_D = PLC.Weekly_Count_S1.Select(x => (double)x).ToArray();
            //Shift2_D = PLC.Weekly_Count_S2.Select(x => (double)x).ToArray();
            //Shift3_D = PLC.Weekly_Count_S3.Select(x => (double)x).ToArray();
            for (int i = 0; i < 7; i++)
            {
                Shift1_D[i] = (double)PLC.Weekly_Count_S1[i];
                Shift2_D[i] = (double)PLC.Weekly_Count_S2[i];
                Shift3_D[i] = (double)PLC.Weekly_Count_S3[i];
            }

           
          
            //formsPlot1.Plot.Render();
            //formsPlot1.Plot.AxisAuto();




            plot2count = 0;
          
            if (PLC.Weekly_Count_Hours.Where(x => Y_Data.Contains(x)).Count() != Y_Data.Length ? true : false)
            {
                for (int i = 0; i < PLC.Weekly_Count_Hours.Length; i++)
                {
                    Y_Data[i] = (double)PLC.Weekly_Count_Hours[i];
                    if (Y_Data[i] > 0) plot2count=i+1;
                   
                    
                }
                double[] d1 = new double[plot2count];
                for (int i = 0; i < plot2count; i++)
                {
                    d1[i] = Y_Data[i];
                }
                
                plot2_refresh(d1);
            }
            else
            {

            }
           
            plot3count = 0;
          
            if (PLC.Weekly_Count_OEE.Where(x => Y_Data2.Contains(x)).Count() != Y_Data2.Length ? true : false)
            {
                for (int i = 0; i < PLC.Weekly_Count_OEE.Length; i++)
                {
                    Y_Data2[i] = (double)PLC.Weekly_Count_OEE[i];

                    if (Y_Data2[i] > 0) plot3count = i + 1;


                }
                double[] d2 = new double[plot3count];
                for (int i = 0; i < plot3count; i++)
                {
                    d2[i] = Y_Data2[i];
                }
                
                plot3_refresh(d2);
            }
            else
            {

            }






            //plot3_refresh(Y_Data2);
            if (currenthour != temphour)
            {
                //plot4_refresh(PLC.OEE_Shift, PLC.OEE_Day);

                
                temphour = currenthour;

            }
            plot5_refresh(PLC.OEE_Day);



            firstscan = true;
        }
       
        public void changefontcolor(Label lbl,float comparevalue)
        {
            if (comparevalue < 50)
            {
                lbl.ForeColor = System.Drawing.Color.Red;

            }
            else
            {
                if (comparevalue > 50 && PLC.OEE_Shift[2] < 75)
                {
                    lbl.ForeColor = System.Drawing.Color.Yellow;
                }
                else
                {
                    lbl.ForeColor = System.Drawing.Color.Green;
                }

            }
        }
        public void bar_plot_refresh(double[] Shift1, double[] Shift2, double[] Shift3)
        {
            int CurrentDay;
           

            DayOfWeek wk = DateTime.Today.DayOfWeek;

            CurrentDay = (int)wk;
            //declaration
            var Plot = new ScottPlot.Plot(600, 400);
            Random rand = new Random(0);
            int DayCount = 7;

            // group all data together
            string[] Groupnames_data = { "Monday", "Tuesday", "Wednesday", "Thursday", "friday", "Saturday", "Sunday", };

            //Shift1[0] =400;
            //Shift1[1] =400;
            //Shift1[2] =400;
            //Shift1[3] =400;
            //Shift1[4] =400;
            //Shift1[5] =400;
            //Shift1[6] =400;

            //Shift2[0] = 400;
            //Shift2[1] = 400;
            //Shift2[2] = 400;
            //Shift2[3] = 400;
            //Shift2[4] = 400;
            //Shift2[5] = 400;
            //Shift2[6] = 400;



            //Shift3[0] = 400;
            //Shift3[1] = 400;
            //Shift3[2] = 400;
            //Shift3[3] = 400;
            //Shift3[4] = 400;
            //Shift3[5] = 400;
            //Shift3[6] = 400;

            string[] groupNames = new string[DayCount];
            double[] errors1 = DataGen.RandomNormal(rand, DayCount, 0, 0);
            double[] errors2 = DataGen.RandomNormal(rand, DayCount, 0, 0);
            double[] errors3 = DataGen.RandomNormal(rand, DayCount, 0, 0);

            string[] seriesNames = { "Shift 1", "Shift 2", "Shift 3" };
            double[][] valuesBySeries = { Shift1, Shift2, Shift3 };
            double[][] errorsBySeries = { errors1, errors2, errors3 };

            if (CurrentDay > 7)
            {
                CurrentDay = 0;
                for (int i = 0; i < 7; i++)
                {
                    valuesBySeries[0][i] = 0;
                    valuesBySeries[1][i] = 0;
                    valuesBySeries[2][i] = 0;

                }
            }

            for (int i = 0; i < DayCount; i++)
            {
                groupNames[i] = Groupnames_data[i];
            }

            formsPlot1.Reset();
            //if (CurrentDay > 0)
            //{
            //    Shift1[CurrentDay - 1] = Todays_Shifts[0];
            //    Shift2[CurrentDay - 1] = Todays_Shifts[1];
            //    Shift3[CurrentDay - 1] = Todays_Shifts[2];
            //}
           

 
            


      

            // add the grouped bar plots and show a legend

            formsPlot1.Plot.AddBarGroups(groupNames, seriesNames, valuesBySeries, errorsBySeries);

            formsPlot1.Plot.Legend(location: Alignment.UpperRight);

            // adjust axis limits so there is no padding below the bar graph
            formsPlot1.Plot.SetAxisLimits(yMin: 0);
            formsPlot1.Plot.AxisAuto();



            formsPlot1.Plot.Style(ScottPlot.Style.Light2);
            formsPlot1.Plot.Title("Weekly Production");
            formsPlot1.Plot.XLabel("Days of the week");
            formsPlot1.Plot.YLabel("Finish Good Parts");
            formsPlot1.Render();

            formsPlot1.Refresh();
            formsPlot1.Plot.AxisAuto();
        }




        public void plot2_refresh(double[] Y_Data)
        {
            formsPlot2.Reset();
            var Plot = new ScottPlot.Plot(600, 400);
            Random rand = new Random(0);
            if (Y_Data.Length > 0)
            {
                formsPlot2.Plot.AddSignal(Y_Data);
            }
            // plot sample data
           
          

            // manually define X axis tick positions and labels


            double[] xPositions = this.xPositions;
            
            string[] xLabels = { " Mon \n  H1  S1  ", "Mon \n  H2  S1  ", "Mon \n  H3  S1  ", "Mon \n  H4  S1  ", "Mon \n  H5  S1  ", "Mon \n  H6  S1  ", "Mon \n  H7  S1  ", "Mon \n  H8  S1  ", "Mon \n  H1  S2  ", "Mon \n  H2  S2  ", "Mon \n  H3  S2  ", "Mon \n  H4  S2  ", "Mon \n  H5  S2  ", "Mon \n  H6  S2  ", "Mon \n  H7  S2  ", "Mon \n  H8  S2  ", "Mon \n  H1  S3  ", "Mon \n  H2  S3  ", "Mon \n  H3  S3  ", "Mon \n  H4  S3  ", "Mon \n  H5  S3  ", "Mon \n  H6  S3  ", "Mon \n  H7  S3  ", "Mon \n  H8  S3  ", "Tue \n  H1  S1  ", "Tue \n  H2  S1  ", "Tue \n  H3  S1  ", "Tue \n  H4  S1  ", "Tue \n  H5  S1  ", "Tue \n  H6  S1  ", "Tue \n  H7  S1  ", "Tue \n  H8  S1  ", "Tue \n  H1  S2  ", "Tue \n  H2  S2  ", "Tue \n  H3  S2  ", "Tue \n  H4  S2  ", "Tue \n  H5  S2  ", "Tue \n  H6  S2  ", "Tue \n  H7  S2  ", "Tue \n  H8  S2  ", "Tue \n  H1  S3  ", "Tue \n  H2  S3  ", "Tue \n  H3  S3  ", "Tue \n  H4  S3  ", "Tue \n  H5  S3  ", "Tue \n  H6  S3  ", "Tue \n  H7  S3  ", "Tue \n  H8  S3  ", "Wed \n  H1  S1  ", "Wed \n  H2  S1  ", "Wed \n  H3  S1  ", "Wed \n  H4  S1  ", "Wed \n  H5  S1  ", "Wed \n  H6  S1  ", "Wed \n  H7  S1  ", "Wed \n  H8  S1  ", "Wed \n  H1  S2  ", "Wed \n  H2  S2  ", "Wed \n  H3  S2  ", "Wed \n  H4  S2  ", "Wed \n  H5  S2  ", "Wed \n  H6  S2  ", "Wed \n  H7  S2  ", "Wed \n  H8  S2  ", "Wed \n  H1  S3  ", "Wed \n  H2  S3  ", "Wed \n  H3  S3  ", "Wed \n  H4  S3  ", "Wed \n  H5  S3  ", "Wed \n  H6  S3  ", "Wed \n  H7  S3  ", "Wed \n  H8  S3  ", "Thu \n  H1  S1  ", "Thu \n  H2  S1  ", "Thu \n  H3  S1  ", "Thu \n  H4  S1  ", "Thu \n  H5  S1  ", "Thu \n  H6  S1  ", "Thu \n  H7  S1  ", "Thu \n  H8  S1  ", "Thu \n  H1  S2  ", "Thu \n  H2  S2  ", "Thu \n  H3  S2  ", "Thu \n  H4  S2  ", "Thu \n  H5  S2  ", "Thu \n  H6  S2  ", "Thu \n  H7  S2  ", "Thu \n  H8  S2  ", "Thu \n  H1  S3  ", "Thu \n  H2  S3  ", "Thu \n  H3  S3  ", "Thu \n  H4  S3  ", "Thu \n  H5  S3  ", "Thu \n  H6  S3  ", "Thu \n  H7  S3  ", "Thu \n  H8  S3  ", "Fri \n  H1  S1  ", "Fri \n  H2  S1  ", "Fri \n  H3  S1  ", "Fri \n  H4  S1  ", "Fri \n  H5  S1  ", "Fri \n  H6  S1  ", "Fri \n  H7  S1  ", "Fri \n  H8  S1  ", "Fri \n  H1  S2  ", "Fri \n  H2  S2  ", "Fri \n  H3  S2  ", "Fri \n  H4  S2  ", "Fri \n  H5  S2  ", "Fri \n  H6  S2  ", "Fri \n  H7  S2  ", "Fri \n  H8  S2  ", "Fri \n  H1  S3  ", "Fri \n  H2  S3  ", "Fri \n  H3  S3  ", "Fri \n  H4  S3  ", "Fri \n  H5  S3  ", "Fri \n  H6  S3  ", "Fri \n  H7  S3  ", "Fri \n  H8  S3  ", "Sat \n  H1  S1  ", "Sat \n  H2  S1  ", "Sat \n  H3  S1  ", "Sat \n  H4  S1  ", "Sat \n  H5  S1  ", "Sat \n  H6  S1  ", "Sat \n  H7  S1  ", "Sat \n  H8  S1  ", "Sat \n  H1  S2  ", "Sat \n  H2  S2  ", "Sat \n  H3  S2  ", "Sat \n  H4  S2  ", "Sat \n  H5  S2  ", "Sat \n  H6  S2  ", "Sat \n  H7  S2  ", "Sat \n  H8  S2  ", "Sat \n  H1  S3  ", "Sat \n  H2  S3  ", "Sat \n  H3  S3  ", "Sat \n  H4  S3  ", "Sat \n  H5  S3  ", "Sat \n  H6  S3  ", "Sat \n  H7  S3  ", "Sat \n  H8  S3  ", "Sun \n  H1  S1  ", "Sun \n  H2  S1  ", "Sun \n  H3  S1  ", "Sun \n  H4  S1  ", "Sun \n  H5  S1  ", "Sun \n  H6  S1  ", "Sun \n  H7  S1  ", "Sun \n  H8  S1  ", "Sun \n  H1  S2  ", "Sun \n  H2  S2  ", "Sun \n  H3  S2  ", "Sun \n  H4  S2  ", "Sun \n  H5  S2  ", "Sun \n  H6  S2  ", "Sun \n  H7  S2  ", "Sun \n  H8  S2  ", "Sun \n  H1  S3  ", "Sun \n  H2  S3  ", "Sun \n  H3  S3  ", "Sun \n  H4  S3  ", "Sun \n  H5  S3  ", "Sun \n  H6  S3  ", "Sun \n  H7  S3  ", "Sun \n  H8  S3  " };

            var x = xLabels.Length;

            formsPlot2.Plot.XAxis.ManualTickPositions(xPositions, xLabels);

            // manually define Y axis tick positions and labels
            //double[] yPositions = {1,2,3,4,5,6,7,8, 1, 2, 3, 4, 5, 6, 7, 8, 1, 2, 3, 4, 5, 6, 7, 8, 1, 2, 3, 4, 5, 6, 7, 8, 1, 2, 3, 4, 5, 6, 7, 8, 1, 2, 3, 4, 5, 6, 7, 8, 1, 2, 3, 4, 5, 6, 7, 8 };
            //string[] yLabels = { "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", };
            //formsPlot1.Plot.YAxis.ManualTickPositions(yPositions, yLabels);
            // Set axis limits to control the view
            if (plot2count > 24)
            {
                formsPlot2.Plot.SetAxisLimits(plot2count-23, plot2count, 0, 60);
            }
            else
            {
                formsPlot2.Plot.SetAxisLimits(1, plot2count, 0, 60);
            }
           
           
            formsPlot2.Plot.Style(ScottPlot.Style.Light2);
            formsPlot2.Plot.Title("Weekly Production (Per Hour)");
            formsPlot2.Plot.XLabel("Hours");
            formsPlot2.Plot.YLabel("Finish Good Parts");
           
            formsPlot2.Render();
            //formsPlot2.Plot.AxisAuto();
            formsPlot2.Refresh();
            formsPlot2.Plot.AxisAuto();

        }
        public void plot3_refresh(double[] Y_Data)
        {
            formsPlot3.Reset();
            var Plot = new ScottPlot.Plot(600, 400);
            Random rand = new Random(0);
            if (Y_Data.Length > 0)
            {
                formsPlot3.Plot.AddSignal(Y_Data);
            }

                // plot sample data
               
            //formsPlot1.Plot.AddSignal(DataGen.Cos(56));

            // manually define X axis tick positions and labels
           
           

            // manually define Y axis tick positions and labels
            double[] xPositions = this.xPositions;

            string[] xLabels = { " Mon \n  H1  S1  ", "Mon \n  H2  S1  ", "Mon \n  H3  S1  ", "Mon \n  H4  S1  ", "Mon \n  H5  S1  ", "Mon \n  H6  S1  ", "Mon \n  H7  S1  ", "Mon \n  H8  S1  ", "Mon \n  H1  S2  ", "Mon \n  H2  S2  ", "Mon \n  H3  S2  ", "Mon \n  H4  S2  ", "Mon \n  H5  S2  ", "Mon \n  H6  S2  ", "Mon \n  H7  S2  ", "Mon \n  H8  S2  ", "Mon \n  H1  S3  ", "Mon \n  H2  S3  ", "Mon \n  H3  S3  ", "Mon \n  H4  S3  ", "Mon \n  H5  S3  ", "Mon \n  H6  S3  ", "Mon \n  H7  S3  ", "Mon \n  H8  S3  ", "Tue \n  H1  S1  ", "Tue \n  H2  S1  ", "Tue \n  H3  S1  ", "Tue \n  H4  S1  ", "Tue \n  H5  S1  ", "Tue \n  H6  S1  ", "Tue \n  H7  S1  ", "Tue \n  H8  S1  ", "Tue \n  H1  S2  ", "Tue \n  H2  S2  ", "Tue \n  H3  S2  ", "Tue \n  H4  S2  ", "Tue \n  H5  S2  ", "Tue \n  H6  S2  ", "Tue \n  H7  S2  ", "Tue \n  H8  S2  ", "Tue \n  H1  S3  ", "Tue \n  H2  S3  ", "Tue \n  H3  S3  ", "Tue \n  H4  S3  ", "Tue \n  H5  S3  ", "Tue \n  H6  S3  ", "Tue \n  H7  S3  ", "Tue \n  H8  S3  ", "Wed \n  H1  S1  ", "Wed \n  H2  S1  ", "Wed \n  H3  S1  ", "Wed \n  H4  S1  ", "Wed \n  H5  S1  ", "Wed \n  H6  S1  ", "Wed \n  H7  S1  ", "Wed \n  H8  S1  ", "Wed \n  H1  S2  ", "Wed \n  H2  S2  ", "Wed \n  H3  S2  ", "Wed \n  H4  S2  ", "Wed \n  H5  S2  ", "Wed \n  H6  S2  ", "Wed \n  H7  S2  ", "Wed \n  H8  S2  ", "Wed \n  H1  S3  ", "Wed \n  H2  S3  ", "Wed \n  H3  S3  ", "Wed \n  H4  S3  ", "Wed \n  H5  S3  ", "Wed \n  H6  S3  ", "Wed \n  H7  S3  ", "Wed \n  H8  S3  ", "Thu \n  H1  S1  ", "Thu \n  H2  S1  ", "Thu \n  H3  S1  ", "Thu \n  H4  S1  ", "Thu \n  H5  S1  ", "Thu \n  H6  S1  ", "Thu \n  H7  S1  ", "Thu \n  H8  S1  ", "Thu \n  H1  S2  ", "Thu \n  H2  S2  ", "Thu \n  H3  S2  ", "Thu \n  H4  S2  ", "Thu \n  H5  S2  ", "Thu \n  H6  S2  ", "Thu \n  H7  S2  ", "Thu \n  H8  S2  ", "Thu \n  H1  S3  ", "Thu \n  H2  S3  ", "Thu \n  H3  S3  ", "Thu \n  H4  S3  ", "Thu \n  H5  S3  ", "Thu \n  H6  S3  ", "Thu \n  H7  S3  ", "Thu \n  H8  S3  ", "Fri \n  H1  S1  ", "Fri \n  H2  S1  ", "Fri \n  H3  S1  ", "Fri \n  H4  S1  ", "Fri \n  H5  S1  ", "Fri \n  H6  S1  ", "Fri \n  H7  S1  ", "Fri \n  H8  S1  ", "Fri \n  H1  S2  ", "Fri \n  H2  S2  ", "Fri \n  H3  S2  ", "Fri \n  H4  S2  ", "Fri \n  H5  S2  ", "Fri \n  H6  S2  ", "Fri \n  H7  S2  ", "Fri \n  H8  S2  ", "Fri \n  H1  S3  ", "Fri \n  H2  S3  ", "Fri \n  H3  S3  ", "Fri \n  H4  S3  ", "Fri \n  H5  S3  ", "Fri \n  H6  S3  ", "Fri \n  H7  S3  ", "Fri \n  H8  S3  ", "Sat \n  H1  S1  ", "Sat \n  H2  S1  ", "Sat \n  H3  S1  ", "Sat \n  H4  S1  ", "Sat \n  H5  S1  ", "Sat \n  H6  S1  ", "Sat \n  H7  S1  ", "Sat \n  H8  S1  ", "Sat \n  H1  S2  ", "Sat \n  H2  S2  ", "Sat \n  H3  S2  ", "Sat \n  H4  S2  ", "Sat \n  H5  S2  ", "Sat \n  H6  S2  ", "Sat \n  H7  S2  ", "Sat \n  H8  S2  ", "Sat \n  H1  S3  ", "Sat \n  H2  S3  ", "Sat \n  H3  S3  ", "Sat \n  H4  S3  ", "Sat \n  H5  S3  ", "Sat \n  H6  S3  ", "Sat \n  H7  S3  ", "Sat \n  H8  S3  ", "Sun \n  H1  S1  ", "Sun \n  H2  S1  ", "Sun \n  H3  S1  ", "Sun \n  H4  S1  ", "Sun \n  H5  S1  ", "Sun \n  H6  S1  ", "Sun \n  H7  S1  ", "Sun \n  H8  S1  ", "Sun \n  H1  S2  ", "Sun \n  H2  S2  ", "Sun \n  H3  S2  ", "Sun \n  H4  S2  ", "Sun \n  H5  S2  ", "Sun \n  H6  S2  ", "Sun \n  H7  S2  ", "Sun \n  H8  S2  ", "Sun \n  H1  S3  ", "Sun \n  H2  S3  ", "Sun \n  H3  S3  ", "Sun \n  H4  S3  ", "Sun \n  H5  S3  ", "Sun \n  H6  S3  ", "Sun \n  H7  S3  ", "Sun \n  H8  S3  " };
            //formsPlot1.Plot.YAxis.ManualTickPositions(yPositions, yLabels);
            // Set axis limits to control the view
            formsPlot3.Plot.XAxis.ManualTickPositions(xPositions, xLabels);

            if (plot3count > 24)
            {
                formsPlot3.Plot.SetAxisLimits(plot3count - 23, plot3count, 0, 100);
            }
            else
            {
                formsPlot3.Plot.SetAxisLimits(1, plot3count, 0, 100);
            }
            formsPlot3.Plot.Style(ScottPlot.Style.Light2);
            formsPlot3.Plot.Title("OEE Trend");
            //formsPlot3.Plot.XLabel("Days of the week");
            formsPlot3.Plot.YLabel("OEE (Percentage %)");

            formsPlot3.Render();

            formsPlot3.Refresh();
            formsPlot3.Plot.AxisAuto();

        }
        public void plot4_refresh(float[] OEE_Shift, float OEE_Day)
        {
            //formsPlot4.Reset();
           
            ////double[] values = { 70,90,80,99};
            //double[]  values= new double[4];
            //values[0] = (double)OEE_Shift[0]; 
            //values[1] = (double)OEE_Shift[1];
            //values[2] = (double)OEE_Shift[2];
            //values[3] = (double)OEE_Day;

            //var gauges = formsPlot4.Plot.AddRadialGauge(values);


            //var Plot = new ScottPlot.Plot(400, 600);

            //formsPlot4.Plot.Palette = ScottPlot.Drawing.Palette.Nord;
            ////gauges.GaugeMode = ScottPlot.RadialGaugeMode.SingleGauge;
            //gauges.CircularBackground = false;
            //gauges.MaximumAngle = 180;
            //gauges.StartingAngle = 180;
            ////gauges.SpaceFraction = .05;
            ////gauges.StartCap = System.Drawing.Drawing2D.LineCap.Flat;
            ////gauges.EndCap = System.Drawing.Drawing2D.LineCap.;
            //gauges.Labels = new string[] { "OEE Shift 1", "OEE Shift 2", "OEE Shift 3", "Current Day" };
            //formsPlot4.Plot.XLabel(label: "OEE                       ");
            //formsPlot4.Plot.Legend(true);


            //formsPlot4.Render();

            //formsPlot4.Refresh();

        }
        public void plot5_refresh(double value)
        {
            solidGauge1.Value = (double)decimal.Round(Convert.ToDecimal(value), 2);
            solidGauge1.From = 0;
            solidGauge1.To = 100;
            solidGauge1.Base.Foreground = new SolidColorBrush(Color.FromRgb(255, 255, 255));
            solidGauge1.HighFontSize = 60;
            solidGauge1.FontSize = 30;
            //solidGauge1.FontStyle();
            solidGauge1.Tag = "Today OEE";
            //solidGauge1.Base.GaugeActiveFill = new LinearGradientBrush
            //{
            //    GradientStops = new GradientStopCollection
            //    {
            //        new GradientStop(Colors.Red, 0),
            //        new GradientStop(Colors.Yellow, .25),
            //        new GradientStop(Colors.Green, .75)
            //    }
            //};

            solidGauge1.FromColor = Colors.Yellow;
            solidGauge1.ToColor = Colors.Green;

        }


    }

    


}
