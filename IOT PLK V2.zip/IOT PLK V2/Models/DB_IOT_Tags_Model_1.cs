﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PLK_IIOT_V2.Models
{
    [Serializable]
    class DB_IOT_Tags_Model_1
    {
        public int ID { get; set; }
        public string Machine { get; set; }
        public string PartNumber { get; set; }
        public int PartStatus { get; set; }
        public DateTime DateTime { get; set; }
        public DateTime PLCDateTime { get; set; }
        public int PLCHour { get; set; }
        public int PLCMin { get; set; }
        public int PLCSec { get; set; }
        public int TotalCount { get; set; }
        public int TotalGood { get; set; }
        public int TotalBad { get; set; }
        public float RunTime { get; set; }
        public float PlannedTime { get; set; }
        public float StopTime { get; set; }
        public int BreakdownCount { get; set; }
        public float OEE { get; set; }
        public float MTBF { get; set; }
        public float MTTR { get; set; }
        public float CurrentCT { get; set; }   
        public float LastCT { get; set; }   
        public float AvgCT { get; set; }   
        public int Heartbeat { get; set; }
        public int SequenceStep { get; set; }
        public string SequenceMsg { get; set; }
        public int AlarmNum { get; set; }
        public string AlarmMsg { get; set; }
        public int Remotereset { get; set; }
        public int TodayCount { get; set; }
        public int[] HourlyCount  { get; set; } = new int[24];
        public int[] ShiftCount  { get; set; } = new int[3];
        public int YdayCount { get; set; }
        public int[] YdayShiftCount  { get; set; } = new int[3];
        public float[] OEEShift { get; set; } = new float[3];
        public int ShiftRecord { get; set; } 
    }
}
