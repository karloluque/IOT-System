﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PLK_IIOT_V2.Models
{
    [Serializable]
    public class IOT_Tags_1
    {
        /// added 
        public string Machine_Name { get; set; }
        public string Ip_Address { get; set; }
        public int Sequence_Step_Num { get; set; }
        public string Sequence_Step_msg { get; set; } 
        public int Alarm_Code { get; set; }
        public string Alarm_msg { get; set; }
        public int Current_Shift { get; set; }
        public int Daily_Target { get; set; }
        public int[] Downtime_msec { get; set; } = new int[24];
        public int[] Downtime_Shifts_msec { get; set; } = new int[4];
        public int Down_Total_msec { get; set; }
        public int[] Uptime_msec { get; set; } = new int[24];
        public int[] Uptime_Shifts_msec { get; set; } = new int[4];
        public int Up_Total_msec { get; set; }
        public int[] PLC_Datetime { get; set; } = new int[8];
        public int Weekly_Hour_Counter { get; set; }
        public int Day_of_Week { get; set; }          
        public int[] Hourly_Counter { get; set; } = new int[24];
        public int[] Todays_Shifts { get; set; } = new int[3];
        public int Todays_Total { get; set; }
        public int[] Ydays_Shifts { get; set; } = new int[3];
        public int Ydays_Total { get; set; }
        public int Current_Takt_time_msec { get; set; }
        public int Avg_Takt_Time_msec { get; set; }
        public int Last_Takt_Time_msec { get; set; }
        public float OR { get; set; }
        public float OEE_Day { get; set; }
        public float[] OEE_Shift { get; set; } = new float[4]; 
        public int[] Weekly_Count_S1 { get; set; } = new int[8];
        public int[] Weekly_Count_S2 { get; set; } = new int[8];
        public int[] Weekly_Count_S3 { get; set; } = new int[8];
        public int[] Weekly_Count_Hours { get; set; } = new int[240];
        public int[] Weekly_Count_OEE { get; set; } = new int[240];
        public int Heartbeat { get; set; }
        public int Remotereset { get; set; }
        public int Linerecord { get; set; }
        public int[] SpareDINT { get; set; } = new int[20];



      













    }
}
