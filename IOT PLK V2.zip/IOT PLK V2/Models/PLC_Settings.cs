﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PLK_IIOT_V2.Models
{
    [Serializable]
    public class PLC_settings
    {
        /// added 
        /// 
        public string ID { get; set; }
        public string Building { get; set; }
        public string PLC_enabled { get; set; }
        public string Machine_Name { get; set; }
        public string Machine_ID { get; set; }
        public string Ip_Address { get; set; }
        public string Server_enabled { get; set; }
        public string Servername { get; set; }
        public string Database { get; set; }
        public string Table { get; set; }
        public string only_server_mode { get; set; }
        public string webservermode { get; set; }
        public int TargetPerHour { get; set; }
        public float IdealCT { get; set; }
        public int Shift1StartHr { get; set; }
        public int Shift1EndHr { get; set; }
        public int Shift2StartHr { get; set; }
        public int Shift2EndHr { get; set; }
        public int Shift3StartHr { get; set; }
        public int Shift3EndHr { get; set; }
        public int PLCType { get; set; }

       



    }
}
